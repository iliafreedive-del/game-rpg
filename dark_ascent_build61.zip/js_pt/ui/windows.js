// Modal windows. All fit the viewport with internal scrolling; the game pauses while one is open.
import { runFpsTest } from './fpstest.js';
import { SETS, bonusText } from '../data/sets.js';
import { setCounts } from '../game/stats.js';
import { G, bus, inCombat } from '../game/ctx.js';
import { $, el, esc, fmt, ICO } from '../core/util.js';
import { SLOTS, SLOT_NAMES, RARITY, WEAPONS, BASE, CLASSES, RARITY_SHORT } from '../data/items.js';
import { SKILLS, BRANCHES, classSkillOrder, unlockLevel } from '../data/skills.js';
import { STORY, REPEATABLE, DIALOG, CHAPTER, chapterOf } from '../data/quests.js';
import { stats, compare, usefulness, meetsReq, xpToNext, effRank } from '../game/stats.js';
import { iconOf, affixText, epicOf, sellValue, upgradeCost, reforgeCost, MAX_UPG, itemPower, kindPerkText, upgMult, heroPower } from '../game/items.js';
import * as CH from '../game/character.js';
import * as EC from '../game/economy.js';
import * as Q from '../game/quests.js';
import { iconURL, skillCanvas, branchImg } from './icons.js';
import { ART, artTag, artHead } from './art.js';
import { drawMap, seen, seenKey } from './hud.js';
import { offers, buy, restorePurchases, dailyStatus, claimDaily, chestStatus, chestSkip, openOrderChest, DAILY, LOGIN_DAYS, watchRewarded, offerToken, blessing, blessLeft, BLESS_MIN, BLESS_CAP, BLESS_DAY, blessToday } from '../platform/monetize.js';
import { PRODUCTS, platform } from '../platform/platform.js';
import { wallOffer, markShown, streakHelp, helpGiven, shopGearToday } from '../platform/offers.js';
import { inCinema } from './cinema.js';
import { revive, saveNow, loadZone, depthsUnlocked, MAX_REVIVES, inPrologue } from '../game/game.js';
import { generateFloor, isBossFloor, floorLevel } from '../world/floorgen.js';
import { REALMS, WILD_QUESTS, wildLevel, isWildBoss, isWildFort, locationName, wildReqLevel, FIELDS_PER_FORT } from '../data/wild.js';
import { wildState, questProgress, claimQuest } from '../game/wild.js';
import { nemState, displayName, TRAITS, WEAK } from '../game/nemesis.js';
import { nextGoal } from '../game/wildhints.js';
import * as DQ from '../game/daily.js';
import * as CS from '../game/castle.js';
import { openHeroPath } from './herospath.js';
import { adButton } from './adbtn.js';
import { openWheel, wheelReady } from './wheel.js';
import * as SV from '../game/survival.js';
import * as SE from '../game/season.js';
import * as HU from '../game/hunts.js';
import { huntReward } from '../data/hunts.js';
import { MEMORIES, SEALS } from '../data/story.js';
import { BOONS, BOON_IDS } from '../data/boons.js';
import { FLOOR_MODS, FLOOR_MOD_IDS, modReward } from '../data/floormods.js';
import { stats as calcStats } from '../game/stats.js';
import { particles, effect } from '../game/combat.js';
import { maybeInterstitial, offerPreview } from '../platform/monetize.js';
import { petsOf, meetCaravan, petInfo } from '../game/pets.js';
import { PETS, TIERS, PET_MAX } from '../data/pets.js';
import { earlyLock, firstLessonCost, POTION_RESERVE, wildDepthGate } from '../game/progress.js';
import { platform as PF } from '../platform/platform.js';
import { wipeLocal, cloudBundle } from '../game/save.js';
import { setVolumes } from '../core/audio.js';
import { resize } from '../render/index.js';
import { zoomRange, zoomNow, setZoom } from '../core/camzoom.js';
import { hintLog, hintsOn, setHints, MILESTONES, milestones } from './tutorial.js';

// С26: доступность на этом устройстве: fs — масштаб текста окон/панелей/тостов, rm — меньше движения (по умолчанию — как в системе)
function a11y() { let A = null; try { A = JSON.parse(localStorage.getItem('da_a11y') || 'null'); } catch { } return A || { fs: 1, rm: matchMedia('(prefers-reduced-motion: reduce)').matches }; }
function setA11y(o) { const A = { ...a11y(), ...o }; try { localStorage.setItem('da_a11y', JSON.stringify(A)); } catch { } applyA11y(A); }
function applyA11y(A) { document.documentElement.style.setProperty('--fs', A.fs || 1); document.documentElement.classList.toggle('rm', !!A.rm); }
applyA11y(a11y());
let cur = null;   // {name, bg, render}
// сборка 47: окно с lock (первый меч, смерть в Жатве) закрывается только своей кнопкой — closeModal(true).
// Окна от событий (глава, осколок памяти, босс, итог похода) не вышибают открытое окно, а ждут в очереди.
const winQ = [];
export function closeModal(force) { if (!cur || (cur.lock && force !== true)) return; cur.bg.remove(); const oc = cur.onClose; cur = null; if (oc) oc(); G.atMerchant = false; G.modalOpen = false; G.paused = false; bus.emit('sfx', 'click'); bus.emit('hud'); if (winQ.length) setTimeout(pumpWin, 350); }
function pumpWin() { if (busy() || !winQ.length) return; winQ.shift()(); }
// П11: «занято» — открыто окно, Летопись, панель NPC или облёт камеры; тогда окно от события ждёт (pumpRewards достаёт его, когда освободится)
const busy = () => !!cur || !!G.cinema || !!G.hwOpen || $('ui').classList.contains('panel-open');   // Летопись (G.hwOpen) — тоже «занято»: окно не всплывает под ней
const later = fn => (...a) => { if (busy()) winQ.push(() => fn(...a)); else fn(...a); };
bus.on('closeModal', () => closeModal());
// М2: на любом окне с прокруткой видно, что его можно листать: яркая полоса прокрутки и стрелки ▲/▼ у края, пока есть что листать
export function scrollHints(sc, host) {
  const up = el('div', 'sc-hint up', '▲'), dn = el('div', 'sc-hint dn', '▼'); host.classList.add('sc-host'); host.append(up, dn);
  const upd = () => { const more = sc.scrollHeight - sc.clientHeight > 6; up.classList.toggle('on', more && sc.scrollTop > 6); dn.classList.toggle('on', more && sc.scrollTop < sc.scrollHeight - sc.clientHeight - 6); };
  up.onclick = () => sc.scrollBy({ top: -sc.clientHeight * 0.7, behavior: 'smooth' }); dn.onclick = () => sc.scrollBy({ top: sc.clientHeight * 0.7, behavior: 'smooth' });
  sc.addEventListener('scroll', upd, { passive: true }); new ResizeObserver(upd).observe(sc); new MutationObserver(upd).observe(sc, { childList: true, subtree: true }); setTimeout(upd, 60);
}
function modal(title, size, render, opts = {}) {
  if (G.cinema) { winQ.push(() => modal(title, size, render, opts)); return { bg: document.createElement('div'), body: null }; }   // М31: окно не открывается под облётом камеры — ждёт его конца
  if (cur && cur.lock) { winQ.unshift(() => modal(title, size, render, opts)); return { bg: document.createElement('div'), body: null }; }
  if (cur) { cur.bg.remove(); if (cur.onClose) cur.onClose(); } G.atMerchant = false;
  const bg = el('div', 'modal-bg'); const m = el('div', 'modal ' + (size || ''));
  const h = el('div', 'mh', `<h2>${esc(title)}</h2>`); const x = el('button', 'mx', '✕'); x.onclick = () => closeModal(); if (!opts.lock) h.appendChild(x);
  const b = el('div', 'mb'); m.append(h, b); bg.appendChild(m);
  // П11: тап, начатый ещё по прежнему окну или панели NPC, не закрывает только что всплывшее окно (первые 0,7 с фон не закрывает)
  const born = performance.now();
  // правки мамы (М1): в горизонтальном виде окно по центру, а по бокам — затемнённый фон. Палец, ведущий по фону сбоку, тоже листает окно;
  // поэтому фон закрывает окно не касанием, а коротким нажатием без сдвига (раньше свайп сбоку просто закрывал окно)
  let drag = null;
  bg.addEventListener('pointerdown', e => { if (e.target === bg) drag = { id: e.pointerId, y: e.clientY, y0: e.clientY, moved: false }; });
  bg.addEventListener('pointermove', e => { if (!drag || e.pointerId !== drag.id) return; const dy = e.clientY - drag.y; drag.y = e.clientY;
    if (Math.abs(e.clientY - drag.y0) > 8) drag.moved = true; if (drag.moved) b.scrollTop -= dy * 1.4; });
  bg.addEventListener('pointerup', e => { const d = drag; drag = null; if (!d || e.pointerId !== d.id || d.moved || e.target !== bg) return; if (!opts.sticky && !opts.lock && performance.now() - born > 700) closeModal(); });
  bg.addEventListener('pointercancel', () => { drag = null; });
  document.body.appendChild(bg);
  scrollHints(b, m);
  // сборка 47: render сохраняет и прокрутку списков внутри окна (путь сезона не прыгает в начало после «Забрать»)
  cur = { lock: !!opts.lock, bg, body: b, render: () => { const st = b.scrollTop, inner = [...b.querySelectorAll('*')].filter(x => x.scrollTop > 0 && x.className).map(x => [x.className, x.scrollTop]); b.innerHTML = ''; render(b); b.scrollTop = st; for (const [c, t] of inner) { const x = b.getElementsByClassName(c)[0]; if (x) x.scrollTop = t; } }, title: h.querySelector('h2') };
  G.modalOpen = true; G.paused = true; cur.render(); return cur;
}
const rerender = () => cur && cur.render();
bus.on('statsChanged', () => { if (cur && cur.live) rerender(); });

const TOWN_ONLY = { character: 1, skills: 1, shrine: 1, herospath: 1 };
import { BADGES } from './hud.js';
export function openWindow(name, arg) {
  bus.emit('sfx', 'click');
  if (TOWN_ONLY[name] && G.zoneId !== 'town') { bus.emit('toast', { text: 'Disponível na vila', sub: 'Evolua seu herói com o Mentor Elvin', kind: 'warn' }); return; }
  if (name === 'herospath') { openHeroPath(); return; }
  const f = W[name]; if (f) { f(arg); if (cur && !cur.reopen) cur.reopen = () => W[name](arg); }
}
bus.on('openNPC', id => { if (id === 'fortune') { openWheel(modal, closeModal); return; } W['npc_' + id](); });
bus.on('openBoard', () => W.board()); bus.on('openWheel', () => openWheel(modal, closeModal)); bus.on('openHeroPath', () => openHeroPath()); bus.on('openDepths', () => W.depths()); bus.on('openWild', r => W.wild(r)); bus.on('wildCleared', later(r => W.wildResult(r)));
bus.on('floorResult', later(r => floorResult(r)));   // П11: окна от событий ждут, пока закроют открытое
bus.on('boonChoice', later(() => boonChoice()));
bus.on('openSurvival', () => W.survival()); bus.on('survLevel', () => survLevel()); bus.on('survEnd', r => survEnd(r)); bus.on('openShrine', () => { W.shrine(); if (cur) cur.reopen = () => W.shrine(); });
bus.on('showDeath', () => showDeath());
bus.on('survDeath', () => modal('Você caiu', 'sm', b => {
  b.appendChild(el('p', '', 'O Abismo o venceu. Você pode voltar ao combate uma vez por partida — ou sair e ficar com o ouro.'));
  const row = el('div', 'row'); row.style.justifyContent = 'center';
  const ad = adButton('▶ Reviver por anúncio', 'revive', 0, () => { closeModal(true); SV.revive(true); });
  const out = el('button', 'btn', 'Sair com a recompensa'); out.onclick = () => { closeModal(true); SV.revive(false); };
  row.append(ad, out); b.appendChild(row);
}, { sticky: true, lock: true }));
bus.on('bossDefeated', later(k => bossReward(k)));
bus.on('chapterDone', later(n => chapterDone(n)));
bus.on('memory', later(id => showMemory(id)));
bus.on('wallOffer', () => showWallOffer());
// П65/П22: подмога Ордена после трёх поражений подряд — теперь внутри экрана гибели (раньше отдельное окно всплывало за 1 с до экрана гибели,
// пряталось под ним и вылезало уже в деревне). Здесь только запоминаем, что её пора предложить
let helpWhere = null;
bus.on('deathAt', where => { helpWhere = streakHelp(where) ? where : null; });
const rewardQ = [];
bus.on('reward', r => {   // now — сразу, даже после боя (награда за рекламу)
  // правки мамы (М22): награда за рекламу или дар дня из открытого окна (Источник силы) показывается сразу поверх него, «Забрать» возвращает в то окно
  if (r.now && cur && !cur.lock && !G.hwOpen) { r.back = cur.reopen; showReward(r); return; }
  if (r.now) rewardQ.unshift(r); else rewardQ.push(r); });
export function pumpRewards() {
  // П11: окно награды ждёт, пока игрок не закроет панель NPC (покупки у Элвина, Миры) и не кончится облёт камеры — не всплывает поверх
  if (busy() || G.player.dead || !G.zoneReady) return;
  if (winQ.length) { pumpWin(); return; }
  if (!rewardQ.length || (inCombat() && !rewardQ[0].now)) return;
  showReward(rewardQ.shift());
}
function showReward(r) {
  bus.emit('sfx', r.items.some(i => i.item.rarity >= 3) ? 'epicDrop' : 'levelup');
  // сборка 47: первый меч от старосты — окно не закрыть, пока не нажато «Надеть»
  const must = r.title === 'Fale com o Ancião' && r.items.some(en => en.bagged && en.item.slot === 'weapon');
  let okBtn = null;
  const m = modal(r.sub || 'Recompensa', 'sm reward', b => {
    const top = r.items.reduce((a, i) => Math.max(a, i.item.rarity), 0);
    const head = el('div', 'rw-head', `<div class="rw-rays r${top}"></div><div class="rw-t">${esc(r.title)}</div>`);
    b.appendChild(head);
    const box = el('div', 'rw-items');
    for (const en of r.items) {
      const it = en.item;
      const c = el('div', 'rw-card r' + it.rarity, `<div class="slot r${it.rarity}"><img src="${iconURL(iconOf(it))}"></div><div><div class="it-name" style="color:${RARITY[it.rarity].color}">${esc(it.name)}</div><div class="it-type">${RARITY[it.rarity].name} · ${it.wt ? WEAPONS[it.wt].name : SLOT_NAMES[it.slot]}</div>${it.dmg ? `<div class="it-stat">Dano ${it.dmg[0]}–${it.dmg[1]}</div>` : it.armor ? `<div class="it-stat">Defesa ${it.armor}</div>` : ''}${it.affixes.slice(0, 3).map(a => `<div class="it-aff">${esc(affixText(a))}</div>`).join('')}${epicOf(it) ? `<div class="it-epic">★ ${esc(epicOf(it).desc)}</div>` : ''}</div>`);
      if (en.equipped) c.appendChild(el('div', 'rw-eq good', '✔ Equipado'));
      else if (en.bagged) {
        const rows = (en.cmp || []).map(r => `<div class="cmp ${r.delta > 0 ? 'up' : r.delta < 0 ? 'dn' : ''}"><span>${esc(r.label)}</span><b>${r.before}${r.suf} → ${r.after}${r.suf} ${r.delta > 0 ? '▲' : r.delta < 0 ? '▼' : ''}</b></div>`).join('');
        c.appendChild(el('div', 'rw-eq', `<div class="muted" style="margin:4px 0">Equipado agora: "${esc(en.old ? en.old.name : '—')}"</div>${rows}`));
        const br = el('div', 'row'); br.style.cssText = 'justify-content:center;margin-top:6px';
        const wear = el('button', 'btn gold sm', 'Equipar'); wear.onclick = () => { if (CH.equipFromBag(it)) { br.replaceWith(el('div', 'rw-eq good', '✔ Equipado · item antigo na bolsa')); if (must && okBtn) { okBtn.disabled = false; cur.lock = false; } } };
        const keep = el('button', 'btn sm', 'Para a bolsa'); keep.onclick = () => br.replaceWith(el('div', 'rw-eq muted', 'Está na bolsa — compare e venda quando precisar'));
        if (must) { br.append(wear); c.appendChild(el('div', 'rw-eq goldc', '☝ Toque em "Equipar" — a nova espada é mais forte')); } else br.append(wear, keep); c.appendChild(br);
      } else c.appendChild(el('div', 'rw-eq muted', `Bolsa cheia — item vendido por ${en.sold} ouro`));
      box.appendChild(c);
    }
    if (r.items.length) b.appendChild(box);
    if (r.skill && SKILLS[r.skill]) {   // сборка 60 (П3): первое умение — подарок старосты, показываем его в той же награде
      const sk = SKILLS[r.skill], c = el('div', 'rw-card r2 rw-skill', `<div><div class="it-name goldc">✦ Nova habilidade: ${esc(sk.name)}</div><div class="it-type">${esc(sk.desc(1))}</div><div class="it-stat good">O botão da habilidade fica no canto inferior direito${matchMedia('(pointer: coarse)').matches ? '' : ' (tecla 1)'}. No combate automático, o herói a usa sozinho.</div></div>`);
      c.prepend(skillCanvas(r.skill, 64)); b.appendChild(c);
    }
    const loot = [r.gold && `<span class="goldc">+${fmt(r.gold)} de ouro</span>`, r.xp && `<span style="color:#b8e3ff">+${r.xp} de XP</span>`, r.potions && `<span style="color:#ff9a9a">+${r.potions} poções de vida</span>`, r.mp && `<span style="color:#9cc0ff">+${r.mp} poções de mana</span>`, r.scrolls && `<span>+${r.scrolls} pergaminhos de retorno</span>`, r.skillPts && `<span class="good">+${r.skillPts} ponto de habilidade</span>`, r.shards && `<span class="c-shard">+${r.shards}◆ fragmentos</span>`].filter(Boolean);
    if (r.shards) b.appendChild(el('div', 'rw-pile', ICO.pile));   // П44: горсть осколков — видно, что за награда
    if (loot.length) b.appendChild(el('div', 'rw-loot', loot.join(' · ')));
    const q = Q.current(); if (q) b.appendChild(el('p', 'muted', `Próxima missão: <b class="goldc">${esc(q.title)}</b>`));
    const row = el('div', 'row'); row.style.justifyContent = 'center'; const ok = el('button', 'btn gold', 'Pegar'); ok.onclick = () => { closeModal(); if (r.back) r.back(); }; okBtn = ok; if (must) ok.disabled = true; row.appendChild(ok); b.appendChild(row);
  }, { lock: must });
  m.bg.classList.add('rw-bg');
}

// ---------------------------------------------------------------- item rendering helpers
function slotEl(it, ph, cls = '') {
  const d = el('div', 'slot ' + cls + (it ? ' r' + it.rarity : ''));
  if (it) {
    d.innerHTML = `<img alt="" src="${iconURL(iconOf(it))}">${it.upg ? `<span class="up">+${it.upg}</span>` : ''}${it.isNew ? '<span class="new"></span>' : ''}`;
    if (!meetsReq(G.profile, it, G.stats)) d.classList.add('req');
  } else d.innerHTML = `<span class="ph">${esc(ph || '')}</span>`;
  return d;
}
// сет в карточке: название, сколько надето, бонусы (работающие — зелёные)
function setHTML(x) { if (!x || !x.set || !SETS[x.set]) return ''; const S = SETS[x.set], c = setCounts(G.profile.gear)[x.set] || 0;
  return `<div class="it-set" style="color:#7ee0a8">◈ Conjunto "${esc(S.name)}" · equipado ${c}/3</div><div class="${c >= 2 ? 'good' : 'muted'}" style="font-size:12px">2 peças: ${esc(bonusText(x.set, S.b2))}</div><div class="${c >= 3 ? 'good' : 'muted'}" style="font-size:12px">3 peças: ${esc(bonusText(x.set, S.b3))}</div>`; }
// П47/П52: почему вещь сливается или нет — те же правила, что у кузнеца (EC.mergeGroups): тот же слот + та же редкость, не надета, не 🔒,
// оружие своего класса, а следующая редкость слиянием открыта уровнем героя. Вид и название вещи не важны.
function mergeNote(it) {
  if (!it || it.rarity >= 4) return null;
  const P = G.profile, what = `${['cinzas', 'verdes', 'azuis', 'dourados'][it.rarity]} · ${(SLOT_NAMES[it.slot] || '').toLowerCase()}`;
  if (Object.values(P.gear).includes(it)) return ['muted', 'Itens equipados não entram na fusão'];
  if (it.locked) return ['muted', '🔒 Travado — fora da fusão'];
  const g = EC.mergeGroups().find(x => x.slot === it.slot && x.rarity === it.rarity);
  if (!g || !g.list.includes(it)) return ['muted', 'Não é da sua classe — não funde'];
  if (g.capLvl) return ['bad', `3 ${what} → 1 ${RARITY_SHORT[it.rarity + 1]}: o ferreiro funde a partir do nível ${g.capLvl} do herói (você tem ${g.n})`];
  if (g.can) return ['good', `Pode fundir com o ferreiro: 3 ${what} quaisquer → 1 ${RARITY_SHORT[it.rarity + 1]} (você tem ${g.n})`];
  return ['muted', `Fusão: 3 ${what} quaisquer → 1 ${RARITY_SHORT[it.rarity + 1]}. Você tem ${g.n}, faltam ${3 - g.n % 3}`];
}
function itemHTML(it, S) {
  const b = BASE[it.base], r = RARITY[it.rarity];
  let h = `<div class="it-name" style="color:${r.color}">${esc(it.name)}${it.upg ? ` <span class="good">+${it.upg}</span>` : ''}<span class="it-pow">⚔ ${itemPower(it)}</span></div>`;
  h += `<div class="it-type">${r.name} · ${it.wt ? WEAPONS[it.wt].name : SLOT_NAMES[it.slot === 'ring' ? 'ring1' : it.slot]} · Nv. do item ${it.ilvl}</div>`;
  const um = upgMult(it);
  if (it.dmg) h += `<div class="it-stat">Dano: <b>${Math.round(it.dmg[0] * um)}–${Math.round(it.dmg[1] * um)}</b> · DPS: <b>${Math.round((it.dmg[0] + it.dmg[1]) / 2 * um * WEAPONS[it.wt].aps * 10) / 10}</b> · Velocidade: ${WEAPONS[it.wt].aps} golpes/s · Alcance: ${WEAPONS[it.wt].range} m</div><div class="it-stat muted" style="font-size:12px">${WEAPONS[it.wt].note}</div>`;
  if (it.armor) h += `<div class="it-stat">Defesa: <b>${Math.round(it.armor * um)}</b></div>`;
  if (it.block) h += `<div class="it-stat">Chance de bloqueio: ${Math.round(it.block * 100)}%</div>`;
  for (const a of it.affixes) h += a.kp ? `<div class="it-aff kp">◇ ${esc(kindPerkText(it))}: ${esc(affixText(a))}</div>` : `<div class="it-aff">${esc(affixText(a))}</div>`;
  { const mn = mergeNote(it); if (mn) h += `<div class="it-stat ${mn[0]}" style="font-size:12px">⚒ ${mn[1]}</div>`; }
  const ep = epicOf(it); if (ep) h += `<div class="it-epic">★ ${esc(ep.desc)}</div>`;
  h += setHTML(it);
  if (it.req) { const ok = meetsReq(G.profile, it, S); h += `<div class="it-stat ${ok ? 'muted' : 'bad'}">Requer: ${Object.entries(it.req).map(([k, v]) => `${CH.ATTR_NAMES[k]} ${v}`).join(', ')}</div>`; }
  h += originHTML(it);
  h += `<div class="it-stat muted" style="font-size:12px">Preço de venda: ${sellValue(it)} ouro</div>`;
  return h;
}
// сборка 49: у вещи есть история — откуда она (ценность вещи: польза, вид и происхождение)
export function originHTML(it) {
  const f = it && it.from; if (!f) return '';
  const d = f.t ? new Date(f.t).toLocaleDateString('pt-BR', { day: 'numeric', month: 'short' }) : '';
  return `<div class="it-stat origin${f.nem ? ' nem' : ''}">${f.nem ? '☠ Troféu de nêmesis: ' : 'Obtido de: '}${esc(f.who || '')}${f.where ? ' · ' + esc(f.where) : ''}${d ? ' · ' + d : ''}</div>`;
}
// правки мамы (М23): «запас прочности» было непонятно — пояснение под сравнением и в окне героя
const EHP_SHORT = '"Vida efetiva" — quanto dano o herói aguenta antes de cair: a vida considerando a defesa. Quanto mais, melhor.';
const EHP_NOTE = EHP_SHORT + ' ' + '▲ verde — melhor que o equipado, ▼ vermelho — pior';
function cmpTable(it, slot) {
  const rows = compare(G.profile, it, slot);
  return `<table class="cmpt"><tr><td class="muted">Atributo</td><td class="muted">Agora</td><td class="muted">Com este</td><td></td></tr>` + rows.map(r => {
    const cls = typeof r.delta === 'number' && r.delta !== 0 ? (r.delta > 0 ? 'good' : 'bad') : '';
    const dv = typeof r.delta === 'number' && r.delta !== 0 ? (r.inv ? (r.delta > 0 ? '−' : '+') + Math.abs(r.delta) : (r.delta > 0 ? '+' : '') + (Math.round(r.delta * 100) / 100) + r.suf) : '';
    return `<tr><td>${r.label}</td><td>${r.before}${r.suf}</td><td>${r.after}${r.suf}</td><td class="d ${cls}">${dv}</td></tr>`;
  }).join('') + '</table>' + (rows.some(r => r.label === 'Vida efetiva') ? `<p class="muted"><small>${EHP_NOTE}</small></p>` : '');
}
const SORTS = { type: (a, b) => a.slot.localeCompare(b.slot) || b.ilvl - a.ilvl, level: (a, b) => b.ilvl - a.ilvl, rarity: (a, b) => b.rarity - a.rarity || b.ilvl - a.ilvl, use: (a, b) => usefulness(G.profile, b) - usefulness(G.profile, a) };

// ---------------------------------------------------------------- windows
const W = {};
const ARW = { up: ['good', '▲'], dn: ['bad', '▼'], eq: ['muted', '='], x: ['muted', '✕'] };
W.inventory = (arg = {}) => {
  const P = G.profile; let filter = W._invFilter || 'all';
  const FILTERS = [['all', 'Tudo'], ['weapon', 'Arma'], ['head', 'Elmo'], ['chest', 'Armadura'], ['amulet', 'Amuleto']];
  const m = modal('Herói', 'md', b => {
    const S = G.stats, C = CLASSES[P.cls || 'warrior'];
    const mrg = new Set(EC.mergeGroups().filter(g => g.can).flatMap(g => g.list));   // П47: что можно слить — значок ⚒
    const cell = (it, slot, arrow) => {
      const d = el('button', 'eq-slot r' + (it ? it.rarity : 'x'), it ? `<img src="${iconURL(iconOf(it))}"><span class="eq-lv">${it.ilvl}</span>${it.upg ? `<span class="eq-up">+${it.upg}</span>` : ''}${arrow ? `<span class="eq-ar ${ARW[arrow][0]}">${ARW[arrow][1]}</span>` : ''}${it.isNew ? '<span class="eq-new">NOVO</span>' : ''}${mrg && mrg.has(it) ? '<span class="eq-mrg" title="Pode fundir com o ferreiro">⚒</span>' : ''}` : `<span class="ph">${esc(SLOT_NAMES[slot] || '')}</span>`);
      if (it) d.onclick = () => itemCard(it, slot); return d;
    };
    // ---- кукла героя: четыре ячейки вокруг портрета, подписи под ними
    const wrap = el('div', 'eq-wrap'), left = el('div', 'eq-left'), right = el('div', 'eq-right'); wrap.append(left, right); b.appendChild(wrap);
    const doll = el('div', 'eq-doll');
    const side = (slot, cls) => { const w = el('div', 'eq-w ' + cls); w.append(cell(P.gear[slot], slot), el('small', '', SLOT_NAMES[slot])); return w; };
    doll.append(side('weapon', 'a'), side('head', 'b'), el('div', 'eq-pt', `<div class="iv-pt" style="background-image:url(assets/sprites/${(P.cls || 'warrior') === 'warrior' ? 'portrait' : 'portrait_' + P.cls}.png)"></div><b>${esc(C.name)}<br><span class="it-pow" style="float:none">⚔ poder ${heroPower(P)}</span></b><small>Nível ${P.level}</small>`), side('chest', 'c'), side('amulet', 'd'));
    left.appendChild(doll);
    left.appendChild(el('div', 'iv-stats', `<span class="st-atk">⚔ DPS <b>${S.dps}</b></span><span class="st-hp">♥ Vida <b>${S.maxHP}</b></span><span class="st-def">🛡 Defesa <b>${S.armor}</b></span>`));
    // ---- сумка
    const full = P.bag.length >= P.bagSize;
    const gray = P.bag.filter(it => it.rarity === 0 && !it.locked);
    right.appendChild(el('div', 'eq-bagh', `<b>Bolsa</b><span class="${full ? 'bad' : 'muted'}">${P.bag.length} / ${P.bagSize}</span>`));
    const tabs = el('div', 'eq-tabs');
    for (const [id, name] of FILTERS) { const t = el('button', 'eq-tab' + (filter === id ? ' on' : ''), name); t.onclick = () => { filter = W._invFilter = id; rerender(); }; tabs.appendChild(t); }
    right.appendChild(tabs);
    const score = new Map(P.bag.map(it => [it, it.slot === 'weapon' && !CH.canEquip(it).ok ? -999 : usefulness(P, it)]));
    const list = P.bag.filter(it => filter === 'all' || it.slot === filter).sort((x, y) => (score.get(y) > 0.5) - (score.get(x) > 0.5) || y.rarity - x.rarity || score.get(y) - score.get(x));
    if (!list.length) right.appendChild(el('p', 'muted iv-hint', P.bag.length ? 'Esta aba está vazia.' : 'Sua bolsa está vazia. Itens caem de inimigos fortes e baús — cada um faz diferença.'));
    // П33: стрелка у каждой вещи, которую можно надеть (▲ лучше, ▼ хуже, = то же); ✕ — не для вашего класса/уровня
    else { const g = el('div', 'eq-grid'); for (const it of list) { const sc = score.get(it); g.appendChild(cell(it, null, sc === -999 ? 'x' : sc > 0.05 ? 'up' : sc < -0.05 ? 'dn' : 'eq')); } right.appendChild(g); }
    if (gray.length) { const v = gray.reduce((a, it) => a + sellValue(it), 0); const sb = el('button', 'btn eq-sellgray', `Vender cinzas: ${gray.length} un. · +${fmt(v)} ouro`); sb.onclick = () => { EC.sellAllCommon(); rerender(); }; right.appendChild(sb); }
    right.appendChild(el('p', 'muted iv-hint', '<b class="good">▲</b> melhor que o equipado · <b class="bad">▼</b> pior · = igual · ✕ não serve · <span class="eq-new inl">NOVO</span> item novo · ⚒ pode fundir com o ferreiro. Toque num item para comparar.'));
    if (arg.select) { const it = P.bag.find(x => x.id === arg.select); arg.select = null; if (it) setTimeout(() => itemCard(it, null), 50); }
  });
  m.live = true; m.onClose = () => { for (const it of P.bag) it.isNew = false; bus.emit('hud'); }; setTimeout(() => bus.emit('invOpened'), 60);   // сборка 60 (П32)   // П33: «НОВ» — до первого просмотра сумки
  function itemCard(it, slot) {
    const inBag = !slot, tslot = CH.slotFor(it), eq = inBag ? P.gear[tslot] : null;
    const ov = el('div', 'ic-ov'); const box = el('div', 'ic-box r' + it.rarity);
    const um = x => 1 + (x.upg || 0) * 0.1;
    const lines = x => !x ? '<div class="muted">— vazio —</div>' : `${x.dmg ? `<div>Dano <b>${Math.round(x.dmg[0] * um(x))}–${Math.round(x.dmg[1] * um(x))}</b></div><div>DPS <b>${Math.round((x.dmg[0] + x.dmg[1]) / 2 * um(x) * WEAPONS[x.wt].aps * 10) / 10}</b></div>` : ''}${x.armor ? `<div>Defesa <b>${Math.round(x.armor * um(x))}</b></div>` : ''}${x.block ? `<div>Bloqueio <b>${Math.round(x.block * 100)}%</b></div>` : ''}${x.affixes.map(a => `<div class="it-aff">${esc(affixText(a))}</div>`).join('')}${epicOf(x) ? `<div class="it-epic">★ ${esc(epicOf(x).desc)}</div>` : ''}${setHTML(x)}${originHTML(x)}`;
    const head = (x, tag) => `<div class="cc-h">${tag ? `<small class="muted">${tag}</small>` : ''}<div class="cc-n" style="color:${RARITY[x.rarity].color}">${esc(x.name)}${x.upg ? ` <span class="good">+${x.upg}</span>` : ''}</div><small>${RARITY[x.rarity].name} · Nv. ${x.ilvl}</small></div>`;
    const rows = inBag ? compare(P, it, tslot).filter(r => typeof r.delta === 'number' && r.delta !== 0).slice(0, 6) : [];
    const ok = inBag ? CH.canEquip(it) : { ok: true };
    box.innerHTML = `<div class="ic-top"><button class="ic-x" aria-label="Fechar">✕</button></div><div class="cc ${eq ? 'two' : ''}">
      <div class="cc-col">${head(it, inBag ? 'Este item' : '')}<div class="iv-slot big r${it.rarity}"><img src="${iconURL(iconOf(it))}"></div><div class="ic-stats">${lines(it)}</div></div>
      ${eq ? `<div class="cc-col dim">${head(eq, 'Equipado agora')}<div class="ic-stats">${lines(eq)}</div></div>` : ''}</div>
      ${rows.length ? `<div class="ic-cmp"><b>Se equipar:</b>${rows.map(r => `<span class="${r.delta > 0 ? 'good' : 'bad'}">${r.delta > 0 ? '▲' : '▼'} ${r.label} ${r.inv ? `${r.before} → ${r.after}` : `${r.delta > 0 ? '+' : ''}${Math.round(r.delta * 100) / 100}${r.suf}`}</span>`).join('')}</div>` : ''}
      ${!ok.ok ? `<div class="bad ic-why">${esc(ok.why)}</div>` : ''}${inBag && mergeNote(it) ? `<div class="${mergeNote(it)[0]} ic-why" style="font-size:12px">⚒ ${mergeNote(it)[1]}</div>` : ''}`;
    const btns = el('div', 'ic-btns');
    if (inBag) { const eqb = el('button', 'btn gold', ok.ok ? 'Equipar' : 'Não pode equipar'); eqb.disabled = !ok.ok; eqb.onclick = () => { CH.equip(it.id); ov.remove(); rerender(); }; btns.appendChild(eqb);
      const sell = el('button', 'btn', `Vender · ${fmt(sellValue(it))} ouro`); sell.onclick = () => { EC.sellItem(it.id); ov.remove(); rerender(); }; btns.appendChild(sell); }
    else { const un = el('button', 'btn', 'Remover'); un.onclick = () => { CH.unequip(slot); ov.remove(); rerender(); }; btns.appendChild(un); }
    box.appendChild(btns);
    // крестик закрывал карточку на pointerup, и следом «click» того же касания попадал в слот под ним (амулет, доспех) — открывалась
    // другая вещь, будто крестик не работает. Теперь карточка сперва гаснет, но ещё ~0,4 с ловит касание сама, и только потом убирается
    const close = () => { if (ov.dataset.gone) return; ov.dataset.gone = 1; ov.style.opacity = '0'; setTimeout(() => ov.remove(), 400); };
    const xb = box.querySelector('.ic-x'); const shut = e => { e.preventDefault(); e.stopPropagation(); close(); };
    xb.addEventListener('pointerup', shut); xb.addEventListener('click', shut); xb.addEventListener('pointerdown', e => e.stopPropagation());
    ov.addEventListener('pointerdown', e => { if (e.target === ov) close(); });
    ov.addEventListener('click', e => { if (ov.dataset.gone) { e.preventDefault(); e.stopPropagation(); } }, true);
    ov.appendChild(box); cur.bg.appendChild(ov);
  }
};

W.character = (arg = {}) => {
  const edit = !!arg.npc;
  const m = modal(edit ? 'Mentor: Atributos' : 'Personagem', 'md', b => {
    const P = G.profile, S = G.stats;
    b.appendChild(el('div', 'row', `<b class="goldc" style="font:600 17px Georgia">${CLASSES[P.cls || 'warrior'].name} · nível ${P.level} · ⚔ poder ${heroPower(P)}</b><span class="muted">XP ${fmt(P.xp)} / ${fmt(xpToNext(P.level))}</span>`));
    b.appendChild(el('h3', '', `Atributos <span class="c-gold" style="float:right">💰 ${fmt(P.gold)} ouro</span>`));
    b.appendChild(el('p', 'muted', 'Crescem sozinhos a cada nível — não há pontos para gastar.'));
    const hints = { str: 'dano de espada e machado', dex: 'dano de arco, crítico, defesa', int: 'poder mágico, mana', vit: 'vida e regeneração' };
    for (const k of ['str', 'dex', 'int', 'vit']) b.appendChild(el('div', 'attr', `<b>${CH.ATTR_NAMES[k]}<br><span class="muted" style="font:12px sans-serif">${hints[k]}</span></b><span class="v">${S[k]}</span>`));
    b.appendChild(el('h3', '', 'Atributos de Combate'));
    const st = [['Dano físico', `${S.dmgMin}–${S.dmgMax}`], ['Dano por segundo', S.dps], ['Velocidade de ataque', S.aps + ' golpes/s'], ['Chance crítica', Math.round(S.critChance * 100) + '%'], ['Dano crítico', Math.round(S.critMult * 100) + '%'],
      ['Poder Mágico', Math.round(S.spellPower * 100) + '%'], ['Dano de Fogo / Gelo / Raio', `${Math.round(S.elem.fire * 100)}% / ${Math.round(S.elem.cold * 100)}% / ${Math.round(S.elem.light * 100)}%`],
      ['Defesa', `${S.armor} (−${Math.round(S.armor / (S.armor + 50 + 10 * P.level) * 100)}% de dano)`], ['Chance de bloqueio', Math.round(S.block * 100) + '%'],
      ['Vida', S.maxHP], ['Vida efetiva', S.ehp], ['Mana', S.maxMP], ['Regen. de mana', S.mpRegen.toFixed(1) + '/s'], ['Vida por golpe', S.leech], ['Achado de Ouro', '+' + S.goldFind + '%']];
    const core = ['Dano por segundo', 'Vida', 'Defesa', 'Vida efetiva'], mainRows = st.filter(r => core.includes(r[0])), moreRows = st.filter(r => !core.includes(r[0]));
    b.appendChild(el('div', 'stats', mainRows.map(([a, v]) => `<div><span>${a}</span><b>${v}</b></div>`).join('')));
    b.appendChild(el('p', 'muted', `<small>${EHP_SHORT}</small>`));
    b.appendChild(el('details', 'more', `<summary class="muted" style="cursor:pointer;margin:6px 0">Atributos detalhados</summary><div class="stats">${moreRows.map(([a, v]) => `<div><span>${a}</span><b>${v}</b></div>`).join('')}</div>`));
    const s = P.stats;
    b.appendChild(el('h3', '', 'Crônica'));
    b.appendChild(el('div', 'stats', [['Monstros abatidos', s.kills], ['Elites', s.elites], ['Chefes', s.bossKills], ['Baús', s.chests], ['Distância percorrida', Math.round(s.meters) + ' m'], ['Ouro coletado', fmt(s.gold)], ['Mortes', s.deaths], ['Tempo de jogo', Math.round(s.playTime / 60) + ' min']].map(([a, v]) => `<div><span>${a}</span><b>${v}</b></div>`).join('')));
    if (P.fallen && P.fallen.length) {   // сборка 49: «Зал павших» — смерти не пропадают бесследно, злейший враг виден
      const cnt = {}; for (const f of P.fallen) cnt[f.who] = (cnt[f.who] || 0) + 1; const [foe, fn] = Object.entries(cnt).sort((a, b) => b[1] - a[1])[0];
      b.appendChild(el('details', 'more fallen', `<summary class="muted" style="cursor:pointer;margin:6px 0">☠ Salão dos Caídos (${P.fallen.length})</summary>${fn > 1 ? `<p class="bad">Pior inimigo: <b>${esc(foe)}</b> — ${fn}×</p>` : ''}<div class="stats">${P.fallen.slice(0, 10).map(f => `<div><span>${esc(f.where || '—')} · Nv. ${f.lvl}</span><b>${esc(f.who)}</b></div>`).join('')}</div>`));
    }
  });
  m.live = true;
};

// Skills: talent tree like WoW — one branch per class: active skill → two passives → next active … (4 actives for 4 buttons).
// Every node needs the previous one and a hero level. Tap an icon → card with description, requirements and «Изучить» (at the trainer).
const TC = 54, TGX = 26, TGY = 22;   // icon size and gaps in the tree grid (px)
W.skills = (arg = {}) => {
  const edit = !!arg.npc; if (edit) setTimeout(() => bus.emit('skillsOpened'), 50); const cls = G.profile.cls || 'warrior'; const ids = classSkillOrder(cls);
  let sel = ids.includes(W._skillSel) ? W._skillSel : null;
  if (!sel || edit) sel = ids.find(id => CH.canLearn(id).ok) || sel || ids[0];
  const m = modal(edit ? 'Mentor: Habilidades' : 'Habilidades', 'lg', b => {
    const P = G.profile;
    b.appendChild(el('div', 'sp-row', `<b class="${P.skillPts ? 'good' : 'muted'}">Pontos de habilidade: ${P.skillPts}</b><span class="muted sp-hint">+1 ponto por nível</span><b class="c-gold">💰 ${fmt(P.gold)} ouro</b>${edit ? '' : '<span class="muted">Aprenda habilidades com o Mentor Elvin na vila.</span>'}`));
    // сборка 38: без большой подсказки «Начните с верхнего умения» — на доступном узле и так «+»; дерево и карточка — в обёртке
    // (на телефоне горизонтально они встают рядом: дерево слева, карточка справа)
    // сборка 49 («одно новое за раз»): пока не изучено ни одного умения, видно только то, что можно изучить сейчас
    const first = hintsOn() && !Object.values(P.skills || {}).some(Boolean) && ids.some(id => CH.canLearn(id).ok);
    const wrap = el('div', 'tal-wrap' + (first ? ' tal-first' : '')), trees = el('div', 'tal-trees');
    if (first) b.appendChild(el('p', 'muted tal-first-note', 'Aprenda sua primeira habilidade — as demais liberam depois, uma a uma.'));
    trees.appendChild(talentBranch(cls, ids, P, id => { sel = W._skillSel = id; rerender(); }, sel));
    wrap.appendChild(trees);
    if (sel) wrap.appendChild(talentInfo(sel, P, edit));
    b.appendChild(wrap);
  });
  m.live = true;
};
// snake layout: active in the middle column, the two passives after it side by side in the next row
const talPos = (i, n) => { if (!i) return [1, 0]; const k = Math.floor((i - 1) / 3), g = (i - 1) % 3; return g === 2 ? [1, 2 * k + 2] : i === n - 1 ? [1, 2 * k + 1] : [g * 2, 2 * k + 1]; };
function talentBranch(cls, ids, P, onPick, sel) {
  const cell = {}; ids.forEach((id, i) => cell[id] = talPos(i, ids.length));
  const rows = Math.max(...ids.map(id => cell[id][1])) + 1;
  const W0 = 3 * TC + 2 * TGX, H0 = rows * TC + (rows - 1) * TGY;
  const pos = id => [cell[id][0] * (TC + TGX), cell[id][1] * (TC + TGY)];
  const pts = ids.reduce((a, id) => a + (P.skills[id] || 0), 0);
  const panel = el('div', 'tal-branch tb-' + cls, `<div class="tal-h"><span>${esc(CLASSES[cls].name)}</span> <b>${pts}</b></div>`);
  const grid = el('div', 'tal-grid'); grid.style.width = W0 + 'px'; grid.style.height = H0 + 'px';
  // arrows: from the previous node to the one it opens; gold when the previous node is learned
  let svg = `<svg class="tal-arrows" width="${W0}" height="${H0}" viewBox="0 0 ${W0} ${H0}">`;
  for (let i = 1; i < ids.length; i++) {
    const k = ids[i - 1], [x1, y1] = pos(k), [x2, y2] = pos(ids[i]); const ok = (P.skills[k] || 0) >= 1; const c = ok ? '#ffd24a' : '#6a6460';
    let d, head;
    if (y1 === y2) { const ax = x1 + TC, ay = y1 + TC / 2, bx = x2 - 4; d = `M${ax},${ay} L${bx},${ay}`; head = `M${bx - 7},${ay - 7} L${bx + 2},${ay} L${bx - 7},${ay + 7}`; }
    else { const ax = x1 + TC / 2, ay = y1 + TC, bx = x2 + TC / 2, by = y2 - 4, my = ay + (by - ay) / 2; d = ax === bx ? `M${ax},${ay} L${bx},${by}` : `M${ax},${ay} L${ax},${my} L${bx},${my} L${bx},${by}`; head = `M${bx - 7},${by - 7} L${bx},${by + 2} L${bx + 7},${by - 7}`; }
    svg += `<path d="${d}" fill="none" stroke="${c}" stroke-width="${ok ? 5 : 4}" stroke-linejoin="round"${ok ? ' class="lit"' : ''}/><path d="${head}" fill="${c}"/>`;
  }
  grid.innerHTML = svg + '</svg>';
  for (const id of ids) {
    const sk = SKILLS[id], r = P.skills[id] || 0, can = CH.canLearn(id), open = CH.reqsMet(id), lv = unlockLevel(cls, id);
    const st = r >= sk.max ? 'max' : r ? 'have' : can.ok ? 'can' : open ? 'open' : 'locked';
    const [x, y] = pos(id);
    const n = el('button', `tal tal-${st}${sk.kind === 'active' ? ' act' : ''}${sel === id ? ' sel' : ''}`); n.style.left = x + 'px'; n.style.top = y + 'px';
    n.title = sk.name; n.appendChild(skillCanvas(id, 96, !r && !can.ok));
    n.appendChild(el('span', 'tal-r', `${r}/${sk.max}`));
    if (sk.kind === 'active') n.appendChild(el('span', 'tal-a', '⚔'));
    if (can.ok) n.appendChild(el('span', 'tal-plus', '+'));
    else if (!r && P.level < lv) n.appendChild(el('span', 'tal-lv', `Nv. ${lv}`));
    n.onclick = () => { bus.emit('sfx', 'click'); onPick(id); };
    grid.appendChild(n);
  }
  panel.appendChild(grid); return panel;
}
function talentInfo(id, P, edit) {
  const sk = SKILLS[id], r = P.skills[id] || 0, er = effRank(P, id), can = CH.canLearn(id), br = BRANCHES.find(x => x.id === sk.b);
  const box = el('div', 'tal-info node');
  box.appendChild(skillCanvas(id, 96, !r && !can.ok));
  const reqs = CH.skillReqs(id);
  const t = el('div', 'ti-body', `<div class="ti-n">${esc(sk.name)} <span class="ti-k ${sk.kind}">${sk.kind === 'active' ? '⚔ habilidade ativa' : 'passiva'}</span></div>
    <div class="ti-sub">${branchImg(br.id)}<span style="color:${br.color}">${esc(br.name)}</span> · grau ${r}/${sk.max}${er > r ? ` <span class="good">(+${er - r} dos itens)</span>` : ''}</div>
    ${r ? `<div class="ti-d"><b>Agora:</b> ${esc(sk.desc(er))}</div>` : ''}
    ${r < sk.max ? `<div class="ti-d ${r ? 'next' : ''}"><b>${r ? 'Próximo grau:' : 'Grau 1:'}</b> ${esc(sk.desc(Math.max(1, er + 1)))}</div>` : '<div class="ti-d good">Aprendida por completo</div>'}
    ${r < sk.max ? `<ul class="ti-req">${reqs.map(q => `<li class="${q.ok ? 'ok' : 'no'}">${q.ok ? '✔' : '✖'} ${esc(q.text)}</li>`).join('')}</ul>` : ''}`);
  box.appendChild(t);
  if (edit && r < sk.max) {
    const cost = CH.skillCost(id); const bt = el('button', 'learn tal-learn' + (can.ok ? ' ok' : ''), `${r ? 'Subir grau' : 'Aprender'}<small>${cost ? fmt(cost) + ' ouro' : 'grátis'}</small>`); bt.disabled = !can.ok;
    bt.onclick = e => { e.stopPropagation(); if (CH.learn(id, true)) rerender(); }; t.appendChild(bt);
    if (!can.ok) t.appendChild(el('div', 'bad', `<small>${esc(can.why)}</small>`));
    else if (P.gold < cost) { bt.classList.remove('ok'); t.appendChild(el('div', 'bad', `<small>Faltam ${fmt(cost - P.gold)} de ouro (você tem ${fmt(P.gold)}). O ponto de habilidade não se perde — volte com ouro da masmorra ou da Crônica</small>`)); }   // М5
  } else if (!edit && r < sk.max && can.ok) t.appendChild(el('div', 'muted', '<small>Pode ser aprendida com o Mentor Elvin na vila.</small>'));
  if (r && sk.kind === 'active') {
    const sr = el('div', 'slots4');
    { const bb = el('button', 'btn sm' + (P.bigSkill === id ? ' gold' : ''), '★'); bb.title = 'No botão grande'; bb.onclick = e => { e.stopPropagation(); P.bigSkill = P.bigSkill === id ? null : id; bus.emit('toast', { text: P.bigSkill ? `"${sk.name}" — no botão grande` : 'Habilidade removida do botão grande', kind: 'good' }); bus.emit('statsChanged'); rerender(); }; sr.appendChild(bb); }
    for (let i = 0; i < 4; i++) { const sb = el('button', 'btn sm' + (P.slots[i] === id ? ' gold' : ''), String(i + 1)); sb.title = 'Botão ' + (i + 1); sb.onclick = e => { e.stopPropagation(); CH.setSlot(i, id); bus.emit('toast', { text: `"${sk.name}" — botão ${i + 1}`, kind: 'good' }); rerender(); }; sr.appendChild(sb); }
    t.appendChild(el('div', 'muted', '<small>Botão de combate:</small>')); t.appendChild(sr);
  }
  return box;
}

// Quests: tabs like mobile hits — Story / Daily / Weekly / Contracts, with reward chips and clear buttons
W.journal = (arg = {}) => {
  let tab = arg.tab || W._qtab || 'story'; W._qtab = tab;
  const m = modal('Missões', 'md', b => {
    const P = G.profile, st = P.story.stage;
    const dq = DQ.dailyQuests(), wq = DQ.weeklyQuests();
    const cnt = { hunt: HU.current() ? 1 : 0, daily: dq.filter(q => q.done && !q.claimed).length, weekly: wq.filter(q => q.done && !q.claimed).length, contracts: REPEATABLE.filter(r => Q.repState(r).done).length };
    const tabs = el('div', 'q-tabs');
    for (const [id, name] of [['story', 'História'], ['hunt', 'Caçada'], ['daily', 'Diárias'], ['weekly', 'Semanais'], ['contracts', 'Contratos']]) {
      const t = el('button', 'q-tab' + (tab === id ? ' on' : ''), `${name}${cnt[id] ? `<i>${cnt[id]}</i>` : ''}`); t.onclick = () => { tab = W._qtab = id; rerender(); }; tabs.appendChild(t);
    }
    b.appendChild(tabs);
    const chips = r => `<div class="q-rw">${r.gold ? `<span class="chip g">💰 ${fmt(r.gold)}</span>` : ''}${r.shards ? `<span class="chip s">◆ ${r.shards}</span>` : ''}${r.potions ? `<span class="chip p">❤ ${r.potions}</span>` : ''}${r.xp ? `<span class="chip x">✦ ${r.xp} de XP</span>` : ''}${r.item ? `<span class="chip i">★ item</span>` : ''}${r.skillPts ? `<span class="chip k">+${r.skillPts} habilidade</span>` : ''}</div>`;
    const card = (title, cur, max, rw, state, onClaim) => {
      const d = el('div', 'q-card' + (state === 'done' ? ' hot' : state === 'claimed' ? ' claimed' : ''), `<div class="q-t">${esc(title)}</div><div class="q-prog"><div class="pbar"><i style="width:${Math.min(100, cur / max * 100)}%"></i></div><span>${cur}/${max}</span></div>${chips(rw)}`);
      const btn = el('button', 'btn sm ' + (state === 'done' ? 'gold' : ''), state === 'done' ? 'Pegar' : state === 'claimed' ? '✔ Resgatado' : 'Ir');
      btn.disabled = state === 'claimed'; btn.onclick = () => { if (state === 'done') { onClaim(); rerender(); } else closeModal(); };
      d.appendChild(btn); return d;
    };
    if (tab === 'story') {
      { const cq = STORY[Math.min(st, STORY.length - 1)], ch = cq.chapter || 1, inCh = STORY.filter(x => (x.chapter || 1) === ch), k = st >= STORY.length ? inCh.length : inCh.indexOf(cq); b.appendChild(el('div', 'q-ch', esc(chapterOf(cq)) + `<div class="pbar"><i style="width:${k / inCh.length * 100}%"></i></div>`)); }
      const q = STORY[st];
      if (q) { const pr = Q.progressOf(q); const it = el('div', 'q-card cur', `<div class="q-t">➤ ${esc(q.title)}</div><div class="muted">${esc(q.text)}</div>${pr ? `<div class="q-prog"><div class="pbar"><i style="width:${pr.cur / pr.max * 100}%"></i></div><span>${pr.cur}/${pr.max}</span></div>` : ''}${chips({ gold: q.reward && q.reward.gold, xp: q.reward && q.reward.xp, item: q.reward && q.reward.items && q.reward.items.length, skillPts: q.reward && q.reward.skillPts, potions: q.reward && q.reward.potions })}`);
        const go = el('button', 'btn sm gold', 'Mostrar caminho'); go.onclick = () => { closeModal(); bus.emit('toast', { text: 'Siga as setas douradas', kind: 'quest' }); }; it.appendChild(go); b.appendChild(it); }
      for (let i = st - 1; i >= Math.max(0, st - 3); i--) b.appendChild(el('div', 'q-card claimed', `<div class="q-t">✔ ${esc(STORY[i].title)}</div>`));
    } else if (tab === 'hunt') {
      const cur = HU.current(), hs = HU.state();
      if (!HU.unlocked()) b.appendChild(el('div', 'q-card', '<div class="q-t">A caçada ainda não começou</div><div class="muted">Desça às Catacumbas pelo portal da Ordem — depois disso, a cada 15 minutos chegarão rumores alarmantes de monstros.</div>'));
      else if (cur && cur.slain) {
        const H = HU.defOf(cur), B = HU.bossOf(cur), r = huntReward(cur.lvl);
        const c = el('div', 'q-card hot', `<div class="q-t">✔ ${esc(H.title)}</div><div>O monstro <span style="color:#ff9a84">${esc(B.name)}</span> foi abatido.</div><ol class="hunt-steps"><li>Volte à vila (portal ou pergaminho de retorno).</li><li>Entregue a caçada ao Ancião Edric — ele está na praça junto à igreja, com um "?" acima dele.</li></ol>${chips({ gold: r.gold, xp: r.xp, shards: r.shards, potions: r.potions, item: 1 })}`);
        const go = el('button', 'btn sm gold', 'Mostrar caminho'); go.onclick = () => { closeModal(); bus.emit('toast', { text: 'Siga as setas vermelhas até o Ancião', kind: 'quest' }); }; c.appendChild(go); b.appendChild(c);
        b.appendChild(el('p', 'muted', '<small>Um novo alarme chega 15 minutos após você entregar esta caçada.</small>'));
      } else if (cur) {
        const H = HU.defOf(cur), B = HU.bossOf(cur), r = huntReward(cur.lvl);
        const c = el('div', 'q-card hunt', `<div class="q-t">⚠ ${esc(H.title)}</div><div class="muted"><i>«${esc(H.rumor)}»</i></div>
          <div style="margin-top:6px"><b>Monstro:</b> <span style="color:#ff9a84">${esc(B.name)}</span> · Nv. ${cur.lvl}</div><div class="muted"><small>${esc(B.desc)}</small></div>
          <div style="margin-top:6px"><b>Onde:</b> ${esc(HU.whereText(cur))}</div><ol class="hunt-steps">${HU.steps(cur).map(t => `<li>${esc(t)}</li>`).join('')}<li>Derrote o monstro.</li><li>Volte ao Ancião Edric e entregue a caçada — a recompensa está com ele.</li></ol>
          ${chips({ gold: r.gold, xp: r.xp, shards: r.shards, potions: r.potions, item: 1 })}`);
        const go = el('button', 'btn sm gold', 'Mostrar caminho'); go.onclick = () => { closeModal(); bus.emit('toast', { text: 'Siga as setas vermelhas', sub: HU.whereText(cur), kind: 'quest' }); }; c.appendChild(go); b.appendChild(c);
        const ab = el('button', 'btn sm', 'Abandonar caçada'); ab.disabled = !HU.canAbandon(); ab.title = ab.disabled ? 'Não enquanto o monstro luta com você' : 'Um novo alarme chega em 15 minutos';
        ab.onclick = () => { if (confirm('Abandonar? Uma nova caçada só aparecerá em 15 minutos.')) { HU.abandon(); rerender(); } }; b.appendChild(ab);
        b.appendChild(el('p', 'muted', '<small>Enquanto esta caçada não terminar, nenhum alarme novo chega — o timer está pausado.</small>'));
      } else {
        const t = el('div', 'hunt-timer', ''); const upd = () => { const ms = HU.msLeft(), s = Math.ceil(ms / 1000); t.textContent = `Próximo alarme em ${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`; };
        upd(); const iv = setInterval(() => { if (!t.isConnected) clearInterval(iv); else upd(); }, 1000);
        b.appendChild(el('div', 'q-card', '<div class="q-t">Tudo calmo por enquanto…</div><div class="muted">A cada 15 minutos um monstro aparece em algum lugar: no bosque perto da vila, no cemitério, nos salões das Catacumbas ou num andar das Profundezas. Esses minichefes aparecem <b>só</b> em caçadas.</div>'));
        b.appendChild(t);
      }
      if (hs.done) b.appendChild(el('p', 'muted', `<small>Caçadas concluídas: ${hs.done}</small>`));
      b.appendChild(el('p', 'muted', `<small>O timer fica no canto superior direito, sob o ouro. Recompensa: ouro, XP, fragmentos do Abismo ◆ e um troféu nomeado.</small>`));
    } else if (tab === 'daily') {
      const r = DQ.dqReward(); for (const q of dq) b.appendChild(card(q.title, q.cur, q.n, { gold: r.gold, potions: r.potions }, q.claimed ? 'claimed' : q.done ? 'done' : 'go', () => DQ.claimDaily(q.id)));
      b.appendChild(el('p', 'muted', '<small>Todas as três — um "Baú Diário" com item raro. Novas missões todo dia.</small>'));
    } else if (tab === 'weekly') {
      const r = DQ.wqReward(); for (const q of wq) b.appendChild(card(q.title, q.cur, q.n, { gold: r.gold, shards: r.shards }, q.claimed ? 'claimed' : q.done ? 'done' : 'go', () => DQ.claimWeekly(q.id)));
      b.appendChild(el('p', 'muted', '<small>Renovam toda semana. Dão fragmentos do Abismo para a Cidadela.</small>'));
    } else {
      for (const rr of REPEATABLE) { const s = Q.repState(rr); b.appendChild(card(rr.title, s.cur, rr.n, rr.reward || { gold: rr.gold }, s.done ? 'done' : 'go', () => Q.claimRep(rr.id))); }
      b.appendChild(el('p', 'muted', '<small>Contratos se repetem sem fim — o progresso é automático.</small>'));
    }
  });
  m.live = true;
};

W.map = () => modal(G.zone.name, 'md', b => {
  const c = document.createElement('canvas'); const size = Math.min(640, innerWidth - 40, (innerHeight - 110) * 1.4); c.width = c.height = Math.round(size * 1.5); c.style.width = c.style.height = size + 'px'; c.style.maxWidth = '100%'; c.style.display = 'block'; c.style.margin = '0 auto';
  b.appendChild(c); drawMap(c.getContext('2d'), c.width, G.zone, seen.get(seenKey(G.zone)), G.player, 0);
  b.appendChild(el('p', 'muted', 'Ponto branco — você. Círculo dourado — objetivo da missão. Roxos — portais. Nas Catacumbas o mapa se revela conforme você explora.'));
});

// ---------------------------------------------------------------- «Справка» (сборка 49): «дайте пропустить и вернуться»
// подсказки вкл/выкл, всё, что уже объясняли (перечитать), перезапуск обучения, «Ваш путь» — минуты до ключевых моментов
const mmPlay = sec => `${Math.floor(sec / 60)}:${String(sec % 60).padStart(2, '0')}`;
W.help = () => modal('Ajuda', 'sm', b => {
  const on = hintsOn();
  const r = el('div', 'attr', '<b>Dicas</b> <small class="muted">dedo sobre botões e setas</small>');
  const bt = el('button', 'btn sm' + (on ? ' gold' : ''), on ? 'Lig.' : 'Desl.'); bt.onclick = () => { setHints(!on); rerender(); }; r.appendChild(bt); b.appendChild(r);
  const L = hintLog();
  b.appendChild(el('h3', '', 'Já explicado'));
  if (!L.length) b.appendChild(el('p', 'muted', 'Nada ainda. As dicas aparecerão no jogo quando necessário.'));
  else { const ul = el('ul', 'help-list'); for (const t of L.slice().reverse()) ul.appendChild(el('li', '', esc(t))); b.appendChild(ul); }
  const rs = el('button', 'btn', 'Mostrar todas as dicas de novo'); rs.onclick = () => { closeModal(); const t = G.profile.tutorial; t.tips = {}; t.log = []; bus.emit('tutorialRestart'); };
  b.appendChild(rs);
  const ms = milestones(), got = MILESTONES.filter(([k]) => ms[k] != null);
  if (got.length) {   // «считайте минуты»: тестер присылает скриншот этого списка
    b.appendChild(el('h3', '', 'Sua Jornada'));
    b.appendChild(el('div', 'stats help-ms', got.map(([k, n]) => `<div><span>${esc(n)}</span><b>${mmPlay(ms[k])}</b></div>`).join('')));
    b.appendChild(el('p', 'muted', '<small>Minutos de jogo quando isso aconteceu pela primeira vez.</small>'));
  }
});
export function photoMode(on) {
  document.body.classList.toggle('photo', on); let x = document.querySelector('.photo-exit'); if (x) x.remove();
  if (!on) return;
  x = el('button', 'btn sm photo-exit', '✕ foto'); x.onclick = () => photoMode(false); document.body.appendChild(x);
}
W.settings = () => modal('Configurações', 'sm', b => {
  const P = G.profile, s = P.settings;
  const range = (lab, key) => { const r = el('div', 'attr', `<b>${lab}</b>`); const i = document.createElement('input'); i.type = 'range'; i.min = 0; i.max = 1; i.step = 0.05; i.value = s[key]; i.oninput = () => { s[key] = +i.value; setVolumes(s.sfx, s.music); }; i.onchange = () => bus.emit('save'); r.appendChild(i); b.appendChild(r); };
  range('Sons', 'sfx'); range('Música', 'music');
  if (platform.p.canShortcut) platform.p.canShortcut().then(ok => {   // сборка 54: ярлык на рабочий стол (Яндекс), 200 золота один раз
    if (!ok || !b.isConnected) return;
    const r = el('div', 'attr', '<b>Atalho na tela</b>' + (P.shortcutDone ? '' : ' <small class="muted">+200 de ouro</small>'));
    const bt = el('button', 'btn sm gold', 'Adicionar'); bt.onclick = async () => { if (!(await platform.p.shortcut())) return; if (!P.shortcutDone) { P.shortcutDone = 1; P.gold += 200; bus.emit('hud'); } bus.emit('toast', { text: 'Atalho adicionado', kind: 'good' }); bus.emit('save'); rerender(); };
    r.appendChild(bt); b.insertBefore(r, b.children[2] || null);
  });
  if (platform.name === 'vk') {   // сборка 52: VK — позвать друзей и добавить игру в избранное
    const v = el('div', 'attr', '<b>VK</b>');
    const inv = el('button', 'btn sm', 'Convidar amigos'); inv.onclick = () => platform.p.invite();
    const fav = el('button', 'btn sm', 'Adicionar aos favoritos'); fav.onclick = async () => { if (await platform.p.favorite()) bus.emit('toast', { text: 'Jogo adicionado aos favoritos', kind: 'good' }); };
    v.append(inv, fav); b.appendChild(v);
  }
  const q = el('div', 'attr', '<b>Qualidade gráfica</b>'); for (const [k, n] of [['low', 'Baixa'], ['auto', 'Auto'], ['med', 'Média'], ['high', 'Alta']]) { const bt = el('button', 'btn sm' + (s.quality === k ? ' gold' : ''), n); bt.onclick = () => { s.quality = k; resize(); bus.emit('save'); rerender(); }; q.appendChild(bt); } b.appendChild(q);
  { const ft = el('button', 'btn sm', '⏱ Teste de velocidade (FPS)'); ft.onclick = () => { closeModal(); runFpsTest(html => modal('Teste de velocidade', 'sm', bb => { bb.appendChild(el('div', '', html)); })); }; b.appendChild(ft); }   // сборка 47
  { let cur = '3d'; try { cur = localStorage.getItem('da_render') || '3d'; } catch { } if (new URLSearchParams(location.search).get('render')) cur = new URLSearchParams(location.search).get('render');
    const g = el('div', 'attr', '<b>Gráficos</b>'); for (const [k, n] of [['3d', '3D (padrão)'], ['2d', '2D Clássico']]) { const bt = el('button', 'btn sm' + (cur === k ? ' gold' : ''), n); bt.onclick = () => { try { localStorage.setItem('da_render', k); } catch { } saveNow(); const u = new URL(location.href); u.searchParams.delete('render'); location.href = u.toString(); }; g.appendChild(bt); } b.appendChild(g); b.appendChild(el('p', 'muted', '<small>Mudar os gráficos reinicia o jogo (o progresso é salvo). Arqueiro e mago ainda são sempre 2D.</small>')); }
  { const nm = el('div', 'attr', '<b>Novos modelos</b> <small class="muted">(heróis)</small>'); const bn = el('button', 'btn sm', s.skins !== false ? 'Lig.' : 'Desl.'); bn.onclick = () => { s.skins = s.skins === false; bus.emit('save'); rerender(); }; nm.appendChild(bn); b.appendChild(nm); }
  { const zr = el('div', 'attr', '<b>Câmera</b> <small class="muted">mais perto — mais longe</small>'); const i = document.createElement('input'); i.type = 'range'; i.min = zoomRange().min; i.max = zoomRange().max; i.step = 0.05; i.value = zoomNow(); i.oninput = () => setZoom(+i.value);
    const rs = el('button', 'btn sm', 'Clássico'); rs.onclick = () => { setZoom(1); i.value = 1; }; zr.append(i, rs); b.appendChild(zr);
    b.appendChild(el('p', 'muted', `<small>${matchMedia('(pointer: coarse)').matches ? 'No jogo: afaste ou junte dois dedos numa parte vazia da tela.' : 'No jogo: roda do mouse ou pinça no touchpad.'}</small>`)); }
  { // сборка 49: режим съёмки — интерфейс прячется, для скриншотов и роликов (план продвижения). Джойстик работает, «АВТО» — как было.
    const ph = el('div', 'attr', '<b>Modo foto</b> <small class="muted">sem botões, para prints e vídeos. Ligue o AUTO antes — o herói lutará sozinho</small>'); const bp = el('button', 'btn sm', 'Ativar');
    bp.onclick = () => { closeModal(); photoMode(true); }; ph.appendChild(bp); b.appendChild(ph); }
  const sh = el('div', 'attr', '<b>Tremor da câmera</b>'); const bs = el('button', 'btn sm', s.shake ? 'Lig.' : 'Desl.'); bs.onclick = () => { s.shake = !s.shake; rerender(); }; sh.appendChild(bs); b.appendChild(sh);
  { // С26: размер текста в окнах и подсказках и «меньше движения» — на этом устройстве (localStorage), не в сохранении героя
    const A = a11y(), ts = el('div', 'attr', '<b>Tamanho do texto</b> <small class="muted">janelas, painéis, dicas</small>');
    for (const [k, n] of [[1, 'Comum'], [1.15, 'Grande'], [1.3, 'Muito grande']]) { const bt = el('button', 'btn sm' + (A.fs === k ? ' gold' : ''), n); bt.onclick = () => { setA11y({ fs: k }); rerender(); }; ts.appendChild(bt); }
    b.appendChild(ts);
    const rm = el('div', 'attr', '<b>Menos movimento</b> <small class="muted">sem piscar ou pulsar dos botões; o tremor da câmera é desligado</small>'); const br = el('button', 'btn sm', A.rm ? 'Lig.' : 'Desl.'); br.onclick = () => { setA11y({ rm: !A.rm }); if (!A.rm) s.shake = false; bus.emit('save'); rerender(); }; rm.appendChild(br); b.appendChild(rm); }
  b.appendChild(el('p', 'muted', `<small>Versão da build: ${window.__BUILD || ''}</small>`));
  b.appendChild(el('h3', '', 'Controles'));
  b.appendChild(el('p', 'muted', 'Celular/tablet: deslize o dedo em qualquer lugar da tela — é o joystick; toque num inimigo — escolhe o alvo e corre até ele, toque num baú ou sarcófago — corre até lá e abre. Habilidades, investida e poções à direita. O herói ataca sozinho quando o inimigo está perto: sua parte é se mover, desviar e beber poções. Pinça com dois dedos — zoom da câmera. PC: WASD/setas ou botão direito do mouse pressionado — mover, botão esquerdo do mouse — golpe no ponto, roda do mouse — zoom, Espaço — atacar, 1–4 — habilidades, Shift — esquiva, Q/E — poções, F — interagir, I/C/K/J/M — janelas, T — pergaminho.'));
  const row = el('div', 'row'); row.style.marginTop = '10px';
  const sv = el('button', 'btn', 'Salvar'); sv.onclick = () => { if (saveNow(true)) bus.emit('toast', { text: 'Jogo salvo', kind: 'good' }); else bus.emit('toast', { text: 'Não foi possível salvar', sub: 'O navegador não permite salvar (modo privado ou sem espaço)', kind: 'warn' }); }; row.appendChild(sv);   // С14
  const rp = el('button', 'btn', 'Restaurar compras'); rp.onclick = () => restorePurchases(); row.appendChild(rp);
  const wp = el('button', 'btn', 'Recomeçar'); wp.onclick = () => { if (confirm('Apagar o save deste herói e recomeçar? Isso não pode ser desfeito. Os saves de outros heróis ficam.')) { wipeLocal(G.profile.cls); G.profile = null; const go = () => location.reload(); if (platform.name !== 'demo' && platform.p && platform.p.cloudSave && platform.cloudOK) Promise.race([platform.p.cloudSave(cloudBundle(null), true), new Promise(r => setTimeout(r, 8000))]).finally(go); else go(); } }; row.appendChild(wp);   // С12: перезагрузка — после настоящей записи в облако (не дольше 8 с)
  b.appendChild(row);
  b.appendChild(el('p', 'muted', `<small>Versão 2.0 · plataforma: ${platform.name}</small>`));
});

// ---------------------------------------------------------------- NPCs
const FACES = ['elder', 'smith', 'merchant', 'trainer', 'fortune'];   // сборка 47: портреты из 3D-моделей NPC (tools/qa/scenarios/npc_faces.js)
function dialog(b, id, name, lines, img) {
  const d = el('div', 'dlg');
  if (img || FACES.includes(id)) { const f = el('div', 'npcface', ''); f.style.backgroundImage = `url(${img || `assets/sprites/face_${id}.jpg`})`; d.appendChild(f); }
  const t = el('div', ''); t.appendChild(el('div', 'who', esc(name)));
  const tx = el('div', 'txt'); t.appendChild(tx); d.appendChild(t); b.appendChild(d);
  let i = 0; const show = () => { tx.textContent = lines[i]; };
  show(); return { next: () => { if (i < lines.length - 1) { i++; show(); return true; } return false; }, last: () => i >= lines.length - 1 };
}
W.npc_elder = () => {
  if (HU.readyToTurnIn()) return huntReport();
  const P = G.profile; const q = Q.current(); let lines, fin = false;
  if (q && q.id === 'talk_elder') lines = DIALOG.elder[0];
  else if (q && q.id === 'elder_task') lines = DIALOG.elder.task;
  else if (q && q.id === 'learn_skill') lines = DIALOG.elder.skill;
  else if (q && q.id === 'meet_merchant') lines = DIALOG.elder.shop;
  else if (q && q.id === 'hw_try') lines = DIALOG.elder.hw;
  else if (q && DIALOG.elder[q.id] && !Q.isReady()) lines = DIALOG.elder[q.id];
  else if (Q.isReady() && Q.turnNpc(q) !== 'elder') lines = ['Juntou o ouro? Leve a Goran, o Ferreiro — ele espera na forja.'];
  else if (Q.isReady()) { lines = DIALOG.elder.turnin[q.id] || ['Você conseguiu. Eis sua recompensa.']; fin = true; }
  else if (q && q.id === 'finish') { lines = DIALOG.elder.finish; fin = true; }
  else if (P.chapterDone) lines = DIALOG.elder.done;
  else if (P.world.hasMedallion && !P.story.flags.bossKilled) lines = DIALOG.elder.after_medallion;
  else lines = DIALOG.elder.mid;
  modal('Ancião Edric', 'sm', b => {
    const dl = dialog(b, 'elder', 'Ancião Edric', lines);
    const row = el('div', 'row'); row.style.marginTop = '12px';
    const nx = el('button', 'btn gold', lines.length > 1 ? 'Avançar' : 'Entendi');
    nx.onclick = () => { if (dl.next()) { if (dl.last()) nx.textContent = fin ? 'Aceitar recompensa' : 'Entendi'; return; } Q.talked('elder'); closeModal(); };
    if (lines.length === 1) nx.textContent = fin ? 'Aceitar recompensa' : 'Entendi';
    row.appendChild(nx); b.appendChild(row);
  }, { sticky: true });
};
// hunt report: the slain beast's trophy is handed in to the elder → reward
function huntReport() {
  const cur = HU.current(), H = HU.defOf(cur), B = HU.bossOf(cur), r = huntReward(cur.lvl);
  modal('Ancião Edric', 'sm', b => {
    dialog(b, 'elder', 'Ancião Edric', [H.elder || `${B.name} abatido? Vau Sereno lhe deve. Eis sua recompensa.`]);
    b.appendChild(el('div', 'q-card hunt', `<div class="q-t">✔ Caçada: ${esc(H.title)}</div><div class="muted">Monstro: ${esc(B.name)}</div><div class="q-rw"><span class="chip g">💰 ${fmt(r.gold)}</span><span class="chip s">◆ ${r.shards}</span><span class="chip p">❤ ${r.potions}</span><span class="chip x">✦ ${r.xp} de XP</span><span class="chip i">★ ${esc(typeof H.trophy.name === 'string' ? H.trophy.name : H.trophy.name[G.profile.cls || 'warrior'])}</span></div>`));
    const row = el('div', 'row'); row.style.marginTop = '12px';
    const ok = el('button', 'btn gold', 'Entregar caçada e receber recompensa'); ok.onclick = () => { closeModal(); HU.turnIn(); };
    row.appendChild(ok); b.appendChild(row);
  }, { sticky: true });
}
W.npc_smith = (tab0) => {
  { const q = Q.current(); if (q && Q.isReady() && Q.turnNpc(q) === 'smith') bus.emit('toast', { text: 'Goran: "' + (DIALOG.smith.turnin[q.id] || 'Obrigado!') + '»', kind: 'quest' }); }
  let sel = null, tab = tab0 || 'merge';   // сборка 38: окно кузнеца всегда открывается на слиянии
  modal('Goran, o Ferreiro', 'md', b => {
    const P = G.profile;
    const tabs = el('div', 'tabs big-tabs'); for (const [k, n] of [['merge', 'Fusão 3→1'], ['upg', 'Têmpera']]) { const t = el('button', 'tab' + (tab === k ? ' on' : ''), n); t.onclick = () => { tab = k; sel = null; rerender(); }; tabs.appendChild(t); } b.appendChild(tabs);
    if (tab === 'merge') { mergeTab(b); b.appendChild(el('p', 'goldc', `Seu ouro: ${fmt(P.gold)}`)); return; }
    b.appendChild(el('p', '', `<i>«${esc(DIALOG.smith.hello[1])}»</i>`));
    b.appendChild(el('p', 'muted', 'Têmpera: +10% de dano ou defesa por nível (até +10), sem risco de quebrar. Itens só podem ser temperados aqui, no ferreiro.'));
    const list = [...Object.entries(P.gear).filter(([, i]) => i).map(([s, i]) => i), ...P.bag.filter(i => i.rarity >= 1 || i.dmg || i.armor)];
    const shop = el('div', 'bag');
    for (const it of list) { const d = slotEl(it, '', sel === it.id ? 'sel' : ''); if (Object.values(P.gear).includes(it)) d.appendChild(el('span', 'up2', 'Equipado')); d.onclick = () => { sel = it.id; rerender(); }; shop.appendChild(d); }
    b.appendChild(shop);
    const it = sel && EC.findItem(sel);
    if (it) {
      const det = el('div', 'detail'); det.innerHTML = itemHTML(it, G.stats);
      const row = el('div', 'row'); row.style.marginTop = '8px';
      const up = el('button', 'btn gold', (it.upg || 0) >= MAX_UPG ? 'Máximo' : `Temperar até +${(it.upg || 0) + 1} — ${upgradeCost(it)} ouro`); up.disabled = (it.upg || 0) >= MAX_UPG || P.gold < upgradeCost(it); up.onclick = () => { EC.upgrade(it.id); rerender(); }; row.appendChild(up);
      det.appendChild(row);
      b.appendChild(det);
    } else b.appendChild(el('p', 'muted', 'Selecione um item.'));
    b.appendChild(el('p', 'goldc', `Seu ouro: ${fmt(P.gold)}`));
  }).live = true;
  Q.talked('smith');
};
// Слияние (сборка 38, как в референсе): сверху — три вещи «+» и что получится, кнопка «Слияние»; ниже — вещи сумки.
// Нажатие на вещь выбирает её группу (слот + редкость); в слияние идут три самые сильные из группы (они с галочкой).
let lastMerged = null, mergeSel = null;
function mergeTab(b) {
  const P = G.profile, groups = EC.mergeGroups(), key = g => g.slot + ':' + g.rarity;
  if (mergeSel && !groups.some(g => key(g) === mergeSel && g.can)) mergeSel = null;
  if (!mergeSel) { const g0 = groups.find(g => g.can); if (g0) mergeSel = key(g0); }
  const G3 = mergeSel && groups.find(g => key(g) === mergeSel), three = G3 ? G3.list.slice(0, 3) : [];
  const top = el('div', 'mrg-top');
  if (G3) {
    const res = el('div', 'mrg-res'); const r1 = slotEl({ ...three[0], rarity: G3.rarity + 1, upg: 0, isNew: false }, '', 'big'); res.append(r1, el('div', 'mrg-up', '▲'));
    const inp = el('div', 'mrg-in'); inp.append(slotEl(three[0]), el('span', 'mrg-plus', '+'), slotEl(three[1]), slotEl(three[2]));
    top.append(el('div', 'mrg-t', `<b style="color:${RARITY[G3.rarity + 1].color}">${RARITY[G3.rarity + 1].name}</b> ${SLOT_NAMES[G3.slot].toLowerCase()}`), res, inp);
    const cost = EC.mergeCost(G3.rarity), go = el('button', 'btn gold mrg-go', `Fundir · ${fmt(cost)} ouro`); go.disabled = P.gold < cost;
    go.onclick = () => { lastMerged = EC.mergeOnce(G3.slot, G3.rarity); mergeSel = null; rerender(); }; top.appendChild(go);
  } else { const capG = groups.find(g => g.capLvl && g.n >= 3);
    top.appendChild(el('div', 'mrg-empty', 'São necessários <b>três itens</b> do mesmo espaço (arma, elmo, armadura, amuleto) e <b>da mesma raridade</b> (cor da moldura). Tipo e nome não importam: três cajados verdes quaisquer viram um azul. Cinza → verde → azul → dourado → mítico.<br><small class="muted">Itens equipados e 🔒 não participam.' + (capG ? ` <span class="bad">${RARITY_SHORT[capG.rarity + 1][0].toUpperCase() + RARITY_SHORT[capG.rarity + 1].slice(1)} por fusão — a partir do nível ${capG.capLvl} do herói.</span>` : '') + '</small>')); }
  b.appendChild(top);
  if (lastMerged) { const det = el('div', 'detail'); det.innerHTML = '<div class="muted">Recebido:</div>' + itemHTML(lastMerged, G.stats); const eq = el('button', 'btn', 'Equipar'); eq.onclick = () => { CH.equip(lastMerged.id); lastMerged = null; rerender(); }; det.appendChild(eq); b.appendChild(det); }
  const ready = groups.filter(g => g.can).reduce((a, g) => a + g.can, 0);
  const row = el('div', 'row'); row.appendChild(el('span', 'muted', ready ? `Pronto para fundir: <b class="goldc">${ready}</b>` : 'Nada para fundir ainda'));
  const all = el('button', 'btn sm', 'Fundir tudo'); all.disabled = !ready; all.onclick = () => { const m = EC.mergeAll(); lastMerged = m.length ? m[m.length - 1] : null; mergeSel = null; rerender(); }; row.appendChild(all); b.appendChild(row);
  // вещи: сначала те, что можно слить, потом остальные (с замком)
  const order = [...groups].sort((a, b) => (b.can ? 1 : 0) - (a.can ? 1 : 0) || a.rarity - b.rarity);
  const bag = el('div', 'bag mrg-bag');
  for (const g of order) for (const it of g.list) {
    const on = key(g) === mergeSel && three.includes(it), d = slotEl(it, '', (on ? 'mrg-on' : '') + (g.can ? '' : ' mrg-lock'));
    if (on) d.appendChild(el('span', 'mrg-ck', '✔')); else if (!g.can) d.appendChild(el('span', 'mrg-lk', g.capLvl && g.n >= 3 ? `Nv. ${g.capLvl}` : `${g.n}/3`));
    d.onclick = () => { if (g.can) { mergeSel = key(g); rerender(); } else if (g.capLvl && g.n >= 3) bus.emit('toast', { text: `Fundir em ${RARITY_SHORT[g.rarity + 1]} — a partir do nível ${g.capLvl} do herói`, kind: 'info' }); else bus.emit('toast', { text: `Faltam ${3 - g.n % 3}: ${SLOT_NAMES[g.slot].toLowerCase()} ${RARITY_SHORT[g.rarity]}`, kind: 'info' }); };
    bag.appendChild(d);
  }
  if (!bag.children.length) { const p0 = el('p', 'muted', 'Nenhum item na bolsa para fundir.'); p0.style.gridColumn = '1/-1'; bag.appendChild(p0); }   // С5: текст на всю ширину сетки
  b.appendChild(bag);
}
// ---------------------------------------------------------------- путь сезона и коллекция (сборка 21)
W.season = () => modal('Trilha da Temporada · ' + SE.seasonName(), 'md', b => {
  const S = SE.season(), L = SE.seasonLevel(), P = G.profile;
  b.appendChild(el('div', 'row', `<b class="goldc" style="font:600 17px Georgia">Nível ${L.lvl} de ${SE.SEASON_LEVELS}</b><span class="muted">${L.need ? `${L.into}/${L.need} pontos para o próximo` : 'Trilha concluída!'}</span>`));
  b.appendChild(el('div', 'pb season-pb', `<i style="width:${L.need ? L.into / L.need * 100 : 100}%"></i>`));
  b.appendChild(el('p', 'muted', 'Pontos de temporada só vêm de missões: missão diária — 100, as três no dia — mais 50, check-in — 10, missão semanal — 150. Completando 70% das diárias, a trilha termina em cerca de 3 semanas. Novo mês — nova temporada.'));
  const list = el('div', 'season-list');
  for (let l = 1; l <= SE.SEASON_LEVELS; l++) { const r = SE.seasonReward(l), got = !!S.claimed[l], open = L.lvl >= l;
    const row = el('div', 'sl' + (r.big ? ' big' : r.mid ? ' mid' : '') + (got ? ' got' : open ? ' open' : ''), `<i>${l}</i><span>${r.label}${r.gold ? ` · ${r.gold * P.level} ouro` : ''}</span>`);
    if (open && !got) { const bt = el('button', 'btn sm gold', 'Pegar'); bt.onclick = () => { SE.claimSeason(l); rerender(); }; row.appendChild(bt); } else row.appendChild(el('em', '', got ? '✔' : '🔒'));
    list.appendChild(row); }
  b.appendChild(list);
});
W.codex = () => modal('Coleção', 'md', b => {
  const P = G.profile; SE.codexScan(); const n = SE.codexCount(P), bases = SE.codexBases(P.cls);
  b.appendChild(el('p', '', `<b class="goldc">Registros: ${n}</b> · bônus permanente: <b>+${(n * SE.CODEX_PCT).toFixed(1)}%</b> de dano e vida`));
  b.appendChild(el('p', 'muted', 'Todo item de um novo tipo ou nova raridade (a partir de verde) entra aqui sozinho. Fundir no ferreiro é um jeito rápido de ganhar registros.'));
  const g = el('div', 'merge-grid codex-grid'); g.appendChild(el('div', 'mg-h', ''));
  for (let r = 1; r <= 4; r++) g.appendChild(el('div', 'mg-h', `<span style="color:${RARITY[r].color}">${RARITY_SHORT[r]}</span>`));
  for (const B of bases) { g.appendChild(el('div', 'mg-s', esc(B.name))); for (let r = 1; r <= 4; r++) { const has = P.codex && P.codex[B.k + ':' + r]; g.appendChild(el('div', 'mg-c' + (has ? ' ok' : ''), has ? '✔' : '·')); } }
  b.appendChild(g);
});
W.npc_merchant = () => {
  let tab = 'buy', sel = null; EC.ensureStock();
  modal('Mira, a Mercadora', 'md', b => {
    const P = G.profile;
    const tabs = el('div', 'tabs big-tabs'); for (const [k, n] of [['buy', 'Comprar'], ['sell', 'Vender']]) { const t = el('button', 'tab' + (tab === k ? ' on' : ''), n); t.onclick = () => { tab = k; sel = null; rerender(); }; tabs.appendChild(t); } b.appendChild(tabs);
    b.appendChild(el('p', 'goldc', `Ouro: ${fmt(P.gold)}`));
    if (tab === 'buy') {
      const sh = el('div', 'shop');
      for (const [k, name, ic, have] of [['hp', 'Poção de Vida', 'potion_hp', P.potions.hp], ['mp', 'Poção de Mana', 'potion_mp', P.potions.mp], ['scroll', 'Pergaminho de Retorno', 'scroll', P.scrolls]]) {
        const c = el('div', 'card', `<div class="top"><div class="slot"><img src="${iconURL(ic)}"></div><div><b>${name}</b><div class="muted">possui: ${have}</div></div></div>`);
        const bt = el('button', 'btn gold sm', `Comprar — ${EC.potionPrice(k)} ouro`); bt.disabled = P.gold < EC.potionPrice(k); bt.onclick = () => { EC.buyConsumable(k); rerender(); }; c.appendChild(bt); sh.appendChild(c);
      }
      b.appendChild(sh);
      b.appendChild(el('h3', '', `Ofertas do dia para a classe ${CLASSES[P.cls || 'warrior'].name}`));
      const st = el('div', 'bag');
      P.shop.stock.forEach((it, i) => { const d = slotEl(it, '', sel === i ? 'sel' : ''); const u = usefulness(P, it); if (u > 0.5) d.appendChild(el('span', 'arr good', '▲')); d.onclick = () => { sel = i; rerender(); }; st.appendChild(d); });
      b.appendChild(st);
      const it = sel != null && P.shop.stock[sel];
      if (it) { const det = el('div', 'detail'); det.innerHTML = itemHTML(it, G.stats) + '<h3>Comparação</h3>' + cmpTable(it, CH.slotFor(it)); const bt = el('button', 'btn gold', `Comprar e equipar — ${EC.buyPrice(it)} ouro`); bt.disabled = P.gold < EC.buyPrice(it); bt.onclick = () => { EC.buyItem(sel); sel = null; rerender(); }; det.appendChild(bt); b.appendChild(det); }
      const row = el('div', 'row'); row.style.marginTop = '10px';
      const rf = el('button', 'btn', `Renovar produtos — ${EC.stockRefreshPrice()} ouro`); rf.onclick = () => { EC.refreshStock(false); sel = null; rerender(); }; row.appendChild(rf);
      const ra = el('button', 'btn ad', 'Renovar grátis'); ra.onclick = () => offers.shopRefresh(() => { EC.refreshStock(true); sel = null; rerender(); }); row.appendChild(ra);
      b.appendChild(row);
    } else {
      const row = el('div', 'row'); const sa = el('button', 'btn', 'Vender todos os Comuns (brancos)'); sa.onclick = () => { EC.sellAllCommon(); rerender(); }; row.appendChild(sa); b.appendChild(row);
      const bag = el('div', 'bag'); bag.style.marginTop = '8px';
      for (const it of P.bag) { const d = slotEl(it, '', sel === it.id ? 'sel' : ''); d.onclick = () => { sel = it.id; rerender(); }; bag.appendChild(d); }
      b.appendChild(bag);
      const it = P.bag.find(x => x.id === sel);
      if (it) { const det = el('div', 'detail'); det.innerHTML = itemHTML(it, G.stats); const bt = el('button', 'btn gold', `Vender por ${sellValue(it)} ouro`); bt.onclick = () => { EC.sellItem(it.id); sel = null; rerender(); }; det.appendChild(bt); b.appendChild(det); }
      if (!P.bag.length) b.appendChild(el('p', 'muted', 'Sua bolsa está vazia.'));
    }
  });
  G.atMerchant = true; Q.talked('merchant');
};
// сборка 58: Караванщик Кофи. Первая встреча — рассказ и подарок (фенек); дальше — короткая фраза, лавка — в панели у повозки
W.npc_caravan = () => {
  const first = !petsOf(G.profile).met, a = PETS[petsOf(G.profile).active];
  // сборка 60 (П15): подарок — только когда староста отправит к Кофи перед катакомбами; раньше Кофи лишь знакомится
  if (first && earlyLock('pet')) return modal('Kofi, o caravaneiro', 'sm', b => {
    const dl = dialog(b, 'caravan', 'Kofi, o caravaneiro', ['Paz à sua casa, guerreiro! Sou Kofi, caravaneiro das Terras Ermas. Minhas carroças ficaram presas aqui quando o Abismo se abriu.', 'Meus bichinhos ainda não se recuperaram da estrada. Passe aqui quando o Ancião tiver te preparado para a jornada — vai ter presente.']);
    const row = el('div', 'row'); row.style.marginTop = '12px'; const nx = el('button', 'btn gold', 'Avançar');
    nx.onclick = () => { if (dl.next()) { if (dl.last()) nx.textContent = 'Entendi'; return; } closeModal(); }; row.appendChild(nx); b.appendChild(row);
  }, { sticky: true });
  const lines = first ? ['Paz à sua casa, guerreiro! Sou Kofi, caravaneiro das Terras Ermas. Minhas carroças ficaram presas aqui quando o Abismo se abriu.', 'Minhas feras não temem as criaturas do Abismo. Batem fraco, mas cada uma sabe o seu: uma queima, outra envenena, outra cura.', 'Tome, este feneco de fogo é um presente. Os outros eu dou em troca de fragmentos do Abismo ◆.']
    : [a ? `As areias amam os corajosos. ${a.name} está ao seu lado, então você não está sozinho.` : 'As areias amam os corajosos. Quem você vai levar hoje?'];
  modal('Kofi, o caravaneiro', 'sm', b => {
    const dl = dialog(b, 'caravan', 'Kofi, o caravaneiro', lines);
    const row = el('div', 'row'); row.style.marginTop = '12px';
    const nx = el('button', 'btn gold', lines.length > 1 ? 'Avançar' : 'Entendi');
    nx.onclick = () => { if (dl.next()) { if (dl.last()) { nx.textContent = first ? '🎁 Pegar o presente' : 'Entendi'; if (first) nx.classList.add('pet-gift'); } return; } closeModal(); if (first && meetCaravan()) petReveal(); };
    if (lines.length === 1) nx.textContent = 'Entendi';
    row.appendChild(nx); b.appendChild(row);
  }, { sticky: true });
};
// сборка 59: первый питомец — торжественно. Вспышка и кольцо там, где он появился, фанфары, через секунду — окно «Новый спутник»
// с лучами, крупным зверьком, его умением и тем, где брать остальных
function petReveal() {
  const p = G.pet, D = p && PETS[p.id]; if (!D) return;
  particles(p.x, p.y, 46, { c: [255, 170, 60], sp: 3.4, size: 4 }); particles(p.x, p.y, 24, { c: [255, 236, 170], sp: 1.6, size: 3 });
  effect({ kind: 'ring', x: p.x, y: p.y, r: 2.6, dur: 0.7, c: [255, 200, 110] }); G.cam.kick(0.25);
  bus.emit('sfx', 'epicDrop'); setTimeout(() => bus.emit('sfx', 'levelup'), 350);
  bus.emit('float', { x: p.x, y: p.y, text: D.icon + ' ' + D.name, color: '#ffd27a', z: 1.6, life: 1.8, big: 1 });
  // правки к сборке 60: поздравление на весь экран — «Хе-хе, поздравляем! Вот тебе питомец!» (было небольшое окно «Новый спутник»)
  setTimeout(() => {
    const m = modal('Um novo companheiro!', 'pet-full', b => {
      b.appendChild(el('div', 'pf-rays'));
      b.appendChild(el('div', 'pf-hehe', '«He-he!» — Kofi'));
      b.appendChild(el('div', 'pf-t', 'Parabéns!'));
      b.appendChild(el('div', 'pf-s', 'Aqui está um mascote para você!'));
      b.appendChild(el('div', 'pf-ic', D.icon));
      b.appendChild(el('div', 'pf-n', `${esc(D.name)} <span style="color:${TIERS[D.tier].color}">· ${esc(TIERS[D.tier].name)}</span>`));
      b.appendChild(el('p', 'pf-d', `<b>Habilidade:</b> ${esc(D.desc)}`));
      b.appendChild(el('p', 'pf-d muted', 'Ele segue você por toda parte e luta ao seu lado. Kofi vende novos bichinhos por fragmentos do Abismo ◆.'));
      const ok = el('button', 'btn gold pf-ok', 'Vamos!'); ok.onclick = closeModal; b.appendChild(ok);
    }, { sticky: true });
    m.bg.classList.add('rw-bg', 'pet-full-bg');
  }, 900);
}
W.petReveal = petReveal;
W.npc_trainer = () => {
  // Глава III: герой вспомнил всё — Элвин объясняется (одной сценой, потом обычное окно наставника)
  { const q = Q.current(), scene = q && { c3_elvin: DIALOG.trainer.confess, c2_stone: DIALOG.trainer.stone }[q.id]; if (scene) { const lines = scene;
    return modal('Mentor Elvin', 'sm', b => {
      const dl = dialog(b, 'trainer', 'Mentor Elvin', lines);
      const row = el('div', 'row'); row.style.marginTop = '12px';
      const nx = el('button', 'btn gold', 'Avançar');
      nx.onclick = () => { if (dl.next()) { if (dl.last()) nx.textContent = 'Entendi'; return; } Q.talked('trainer'); closeModal(); };
      row.appendChild(nx); b.appendChild(row);
    }, { sticky: true }); } }
  modal('Mentor Elvin', 'sm', b => {
    const P = G.profile;
    b.appendChild(el('p', '', `<i>«${esc(DIALOG.trainer.hello[P.tutorial.trainerGift ? 1 : 0])}»</i>`));
    if (!P.tutorial.trainerGift) {
      const C = CLASSES[P.cls || 'warrior'];
      const first = classSkillOrder(P.cls || 'warrior')[0], opts = [[first, SKILLS[first].name]];
      const fc = firstLessonCost();   // сборка 55: урок платный — остаётся ровно на зелье здоровья
      b.appendChild(el('p', 'good', fc ? `Primeira aula — ${fc} de ouro: escolha uma técnica e o mentor ensina na hora. Sobrarão ${POTION_RESERVE} de ouro — exatamente para uma poção de vida da Mira.` : 'Primeira aula: escolha uma técnica e o mentor ensina na hora.'));
      const row = el('div', 'row');
      for (const [id, n] of opts) { const bt = el('button', 'btn gold', n); bt.onclick = () => { P.gold -= firstLessonCost(); P.tutorial.trainerGift = id; CH.grantSkill(id); bus.emit('toast', { text: 'Aprendido: ' + n, kind: 'good' }); rerender(); }; row.appendChild(bt); }
      b.appendChild(row);
    }
    b.appendChild(el('h3', '', 'Serviços'));
    const r1 = el('div', 'row');
        const sk = el('button', 'btn ' + (CH.canLearnNow() ? 'gold' : ''), `Habilidades${P.skillPts ? ` (+${P.skillPts})` : ''}`); sk.onclick = () => W.skills({ npc: true }); r1.appendChild(sk); b.appendChild(r1);
    const r2 = el('div', 'row'); r2.style.marginTop = '8px';
    const rs = el('button', 'btn', `Redefinir habilidades — ${EC.respecSkillPrice()} ouro`); rs.disabled = P.gold < EC.respecSkillPrice(); rs.onclick = () => { if (confirm('Redefinir todas as habilidades e devolver os pontos?')) { EC.respecSkills(); rerender(); } }; r2.appendChild(rs);
    b.appendChild(r2);
  });
  Q.talked('trainer');
};
// Доска объявлений: ежедневные, недельные (крупнее) и долгие контракты (самые трудные, повторяются бесконечно)
const qChips = r => `<div class="q-rw">${r.gold ? `<span class="chip g">💰 ${fmt(r.gold)}</span>` : ''}${r.shards ? `<span class="chip s">◆ ${r.shards}</span>` : ''}${r.potions ? `<span class="chip p">❤ ${r.potions}</span>` : ''}${r.xp ? `<span class="chip x">✦ ${r.xp} de XP</span>` : ''}${r.item ? `<span class="chip i">★ item</span>` : ''}${r.skillPts ? `<span class="chip k">+${r.skillPts} habilidade</span>` : ''}</div>`;
function qCard(title, cur, max, rw, state, onClaim, onGo) {
  const d = el('div', 'q-card' + (state === 'done' ? ' hot' : state === 'claimed' ? ' claimed' : ''), `<div class="q-t">${esc(title)}</div><div class="q-prog"><div class="pbar"><i style="width:${Math.min(100, cur / max * 100)}%"></i></div><span>${cur}/${max}</span></div>${qChips(rw)}`);
  const btn = el('button', 'btn sm ' + (state === 'done' ? 'gold' : ''), state === 'done' ? 'Pegar' : state === 'claimed' ? '✔ Resgatado' : 'Ir');
  btn.disabled = state === 'claimed'; btn.onclick = () => { if (state === 'done') { onClaim(); rerender(); } else onGo(); };
  d.appendChild(btn); return d;
}
W.board = () => {
  let tab = W._boardTab || 'daily';
  modal('Quadro de Avisos', 'md', b => {
    const dq = DQ.dailyQuests(), wq = DQ.weeklyQuests();
    const cnt = { daily: dq.filter(q => q.done && !q.claimed).length, weekly: wq.filter(q => q.done && !q.claimed).length, contracts: REPEATABLE.filter(r => Q.repState(r).done).length };
    const tabs = el('div', 'q-tabs');
    for (const [id, name] of [['daily', 'Diárias'], ['weekly', 'Semanais'], ['contracts', 'Longos']]) { const t = el('button', 'q-tab' + (tab === id ? ' on' : ''), `${name}${cnt[id] ? `<i>${cnt[id]}</i>` : ''}`); t.onclick = () => { tab = W._boardTab = id; rerender(); }; tabs.appendChild(t); }
    b.appendChild(tabs);
    if (tab === 'daily') {
      const r = DQ.dqReward(); for (const q of dq) b.appendChild(qCard(q.title, q.cur, q.n, { gold: r.gold, potions: r.potions }, q.claimed ? 'claimed' : q.done ? 'done' : 'go', () => DQ.claimDaily(q.id), closeModal));
      b.appendChild(el('p', 'muted', '<small>Três missões por dia. Complete todas para ganhar o Baú Diário. Renovam todo dia.</small>'));
    } else if (tab === 'weekly') {
      const r = DQ.wqReward(); for (const q of wq) b.appendChild(qCard(q.title, q.cur, q.n, { gold: r.gold, shards: r.shards }, q.claimed ? 'claimed' : q.done ? 'done' : 'go', () => DQ.claimWeekly(q.id), closeModal));
      b.appendChild(el('p', 'muted', '<small>Grandes metas semanais: mais ouro e fragmentos do Abismo para a Cidadela.</small>'));
    } else {
      for (const rr of REPEATABLE) { const s = Q.repState(rr); b.appendChild(qCard(rr.title, s.cur, rr.n, rr.reward || { gold: rr.gold }, s.done ? 'done' : 'go', () => Q.claimRep(rr.id), closeModal)); }
      b.appendChild(el('p', 'muted', '<small>As missões mais difíceis e longas. O progresso é automático; após a recompensa o contrato recomeça.</small>'));
    }
  }).live = true;
};

// ---------------------------------------------------------------- rewards / shop (monetization hub)
W.shrine = () => modal('Fonte de Poder', 'md', b => {
  const P = G.profile, now = Date.now(); if (!P.shrineSeen) { P.shrineSeen = 1; bus.emit('save'); }   // П67
  // 1) благословение — главное предложение алтаря
  { const left = blessLeft(), on = left > 0, full = left > (BLESS_CAP - BLESS_MIN) * 60000;
    const c = el('div', 'bless-card' + (on ? ' on' : ''), `<div class="bl-ic">✦</div><div class="tx"><b>Poder da Fonte</b><div>+25% de ouro e XP, +15% de drop de itens — ${BLESS_MIN} minutos</div><div class="muted">${on ? `Ativo por <b>${Math.floor(left / 60000)}:${String(Math.floor(left / 1000) % 60).padStart(2, '0')}</b>${full ? ' · limite ' + BLESS_CAP + ' min' : ' · pode prolongar'}` : 'Veja um anúncio — drops melhores por 10 minutos'}</div></div>`);
    const used = blessToday() >= BLESS_DAY; c.appendChild(el('div', 'muted', `<small>Hoje: ${blessToday()} de ${BLESS_DAY}</small>`));
    const bt = el('button', 'btn ad', used ? 'Amanhã' : on ? `+${BLESS_MIN} min` : 'Receber'); bt.disabled = full || used || inCombat(); bt.onclick = () => blessing().then(rerender); c.appendChild(bt); b.appendChild(c); }
  // 2) календарь входа: 28 дней, пропуск не сбрасывает, каждый 3-й больше, 7/14/21/28 — вещь
  const ds = dailyStatus(), cur = ds.day, base = ds.streak - (ds.claimable ? 0 : 1) - (cur - 1);   // base — сколько дней было до этого круга
  b.appendChild(el('h3', '', `Dádivas da Fonte · dia ${cur} de ${LOGIN_DAYS}${ds.streak >= LOGIN_DAYS ? ` · ciclo ${Math.floor(base / LOGIN_DAYS) + 1}` : ''}`));
  const cal = el('div', 'login-cal');
  DAILY.forEach((r, i) => { const d = i + 1, got = d < cur || (d === cur && !ds.claimable), today = d === cur && ds.claimable, soon = !got && !today && d - cur <= 3;
    const what = (r.item ? (r.item >= 3 ? '★ item dourado' : '★ item azul') : r.mid ? '✉ pergaminho' : (r.gold * P.level) + ' ouro') + (r.shards ? ` <b class="c-shard">+${r.shards}◆</b>` : '');
    const cell = el('div', 'lc' + (r.big ? ' big' : r.mid ? ' mid' : '') + (got ? ' got' : '') + (today ? ' today' : '') + (soon ? ' soon' : ''), `<i>${d}</i><span>${what}</span>${got ? '<em>✔</em>' : today ? '<em>pegar</em>' : soon ? `<em>${d - cur === 1 ? "amanhã" : "em " + (d - cur) + " d"}</em>` : ''}`);
    if (today) cell.onclick = () => { claimDaily(false); rerender(); };   // правки мамы (М21): нажатие на сам день тоже забирает дар
    cal.appendChild(cell); });
  b.appendChild(cal);
  const nb = DAILY.findIndex((r, i) => i + 1 > cur && (r.big || r.mid)), nr = nb >= 0 ? DAILY[nb] : null;
  const dr = el('div', 'row'); dr.style.marginTop = '6px';
  if (ds.claimable) { const a = el('button', 'btn gold nudge', `Pegar dia ${cur}`); a.onclick = () => { claimDaily(false); rerender(); }; const x2 = el('button', 'btn ad', 'Pegar ×1,5'); x2.onclick = () => watchRewarded('daily_double', offerToken('daily_double', 'd' + new Date().toDateString()), () => claimDaily(true)).then(rerender); dr.append(a, x2); }
  else dr.appendChild(el('span', 'muted', `Próxima dádiva — amanhã.${nr ? ` Em ${nb + 1 - cur} d: <b>${nr.label}</b>` : ''} Perder um dia não reinicia o calendário.`));
  b.appendChild(dr);
  dailyBlock(b);
  // order chest
  const cs = chestStatus(); b.appendChild(el('h3', '', 'Baú da Ordem'));
  const cr = el('div', 'offer', `<div class="ic">▣</div><div class="tx"><b>Item raro + mágico e ouro</b><div class="muted">${cs.ready ? 'Pronto para abrir!' : 'Abre em ' + Math.ceil(cs.left / 60000) + ' min'}</div></div>`);
  const cb = el('button', 'btn ' + (cs.ready ? 'gold' : 'ad'), cs.ready ? 'Abrir' : 'Abrir agora'); cb.onclick = () => { (cs.ready ? Promise.resolve(openOrderChest()) : chestSkip()).then(rerender); }; cr.appendChild(cb); b.appendChild(cr);
  // IAP
  b.appendChild(el('h3', '', 'Loja da Ordem'));
  b.appendChild(el('p', 'muted', '<small>O equipamento da loja muda todo dia. O conjunto azul está disponível desde o início, itens dourados a partir do nível 15, míticos a partir do 22.</small>'));   // П67
  const gearToday = shopGearToday();
  for (const [id, p] of Object.entries(PRODUCTS)) {
    if (!platform.p.hasProduct(id)) continue;
    if (p.gear && !gearToday.includes(id)) continue;   // П67: из снаряжения — только товары дня, открытые по уровню
    const owned = (p.once && P.iap.tx['once_' + id]) || (!p.consumable && P.iap[{ gold_perk: 'goldPerk', no_ads: 'noAds', bag_big: 'bagBig' }[id]]);
    const o = el('div', 'offer', `<div class="ic">${esc(p.icon || '⛁')}</div><div class="tx"><b>${esc(p.title)}</b><div class="muted">${esc(p.desc)}</div></div>`);
    const pr = platform.p.catalogPrice(id), price = typeof pr === 'string' ? esc(pr) : `${esc(pr.value)} ${pr.img ? `<img class="cur" src="${esc(pr.img)}" alt="${esc(pr.code)}">` : esc(pr.code)}`;
    const bt = el('button', 'btn gold', owned ? 'Comprado' : price); bt.disabled = !!owned; bt.onclick = () => buy(id).then(rerender); o.appendChild(bt); b.appendChild(o);
    if (!owned && (p.gear || id === 'starter_pack' || id === 'potion_pack')) { const box = el('div', ''), sh = el('button', 'btn sm', 'O que tem dentro ▾'); sh.onclick = () => { if (box.childElementCount) box.innerHTML = ''; else offerContents(box, id); }; o.querySelector('.tx').appendChild(sh); b.appendChild(box); }   // П24
  }
  if (platform.name === 'demo') b.appendChild(el('p', 'muted', '<small>Modo demo: anúncios e compras são simulados, nada é cobrado. No Yandex Games é usado o SDK da plataforma.</small>'));
});

// П61: страница питомца — урон (сколько и какой), скорость, дальность, дар с числами, уровень и что даст следующий
W.petInfo = id => {
  const D = PETS[id]; if (!D) return;
  modal(`${D.icon} ${D.name}`, 'sm', b => {
    const S = petsOf(G.profile), lvl = S.own[id] || 1, I = petInfo(id, lvl), N = lvl < PET_MAX ? petInfo(id, lvl + 1) : null, T0 = TIERS[D.tier];
    const up = (a, c) => N && a !== c ? ` <span class="good">→ ${c}</span>` : '';
    b.appendChild(el('p', '', `<span style="color:${T0.color}">${T0.name}</span> · ${S.own[id] ? `nível <b>${lvl}</b> de ${PET_MAX}` : 'ainda não comprado (nível 1 exibido)'}${S.active === id ? ' · <b class="good">com você</b>' : ''}`));
    b.appendChild(el('div', 'stats', [
      ['Dano por golpe', `${I.dmg}${up(I.dmg, N && N.dmg)}`], ['Dano por segundo', `${I.dps}${up(I.dps, N && N.dps)}`], ['Tipo de dano', I.type],
      ['Golpe', `a cada ${String(I.cd).replace('.', ',')} s, ${I.reach}`], ['Parcela do golpe do herói', `${I.share}${up(I.share, N && N.share)}`],
    ].map(([a, v]) => `<div><span>${a}</span><b>${v}</b></div>`).join('')));
    if (I.fxName) b.appendChild(el('div', 'pet-fx', `<b>✦ ${esc(I.fxName)}</b><div>${esc(I.fxText)}</div>${N && N.fxText !== I.fxText ? `<div class="good" style="font-size:12px">No nível ${lvl + 1}: ${esc(N.fxText)}</div>` : ''}`));
    b.appendChild(el('p', 'muted', `<small>O dano do mascote cresce com o dano do herói (é uma parcela do golpe médio dele) e +15% por nível do mascote. Melhore com Kofi usando fragmentos do Abismo ◆.</small>`));
    const r = el('div', 'row'); r.style.justifyContent = 'center'; const ok = el('button', 'btn gold', 'Entendi'); ok.onclick = () => closeModal(); r.appendChild(ok); b.appendChild(r);
  });
};
// П62: пустая банка. Реклама даёт 2 зелья; подряд — до 10 раз, потом одна попытка восстанавливается раз в 15 минут.
// Купить — у торговки Миры (в деревне сразу из этого окна, в походе — подсказка, где купить)
const POT_ADS = 10, POT_AD_MS = 15 * 60e3;
function potAds() {
  const P = G.profile, A = P.potAds || (P.potAds = { n: POT_ADS, t: Date.now() }), now = Date.now();
  if (A.t > now) A.t = now;   // часы переведены назад — не ждать часами
  if (A.n >= POT_ADS) A.t = now; else { const k = Math.floor((now - A.t) / POT_AD_MS); if (k > 0) { A.n = Math.min(POT_ADS, A.n + k); A.t = A.n >= POT_ADS ? now : A.t + k * POT_AD_MS; } }
  return A;
}
W.potEmpty = k => {
  const name = k === 'hp' ? 'vida' : 'mana';
  bus.emit('sfx', 'deny');
  modal(`Acabaram as poções de ${name}`, 'sm', b => {
    const P = G.profile, A = potAds(), lock = earlyLock('extra');
    b.appendChild(el('div', 'of-pack', `<div class="of-x"><img src="${iconURL(k === 'hp' ? 'potion_hp' : 'potion_mp')}" alt=""><b>${P.potions[k]}</b><small>poções de ${name}</small></div>`));
    const r = el('div', 'row'); r.style.justifyContent = 'center';
    if (!lock) {
      const ad = el('button', 'btn ad', A.n > 0 ? `2 poções por anúncio · restam ${A.n} de ${POT_ADS}` : `2 poções por anúncio · em ${Math.ceil((A.t + POT_AD_MS - Date.now()) / 60000)} min`); ad.disabled = A.n <= 0;
      ad.onclick = async () => { if (potAds().n <= 0) return; const ok = await watchRewarded('pot_ad', offerToken('pot_ad', String(Date.now())), () => { const A2 = potAds(); if (A2.n >= POT_ADS) A2.t = Date.now(); A2.n--; P.potions[k] += 2; bus.emit('toast', { text: `+2 poções de ${name}`, kind: 'good' }); }); if (ok) closeModal(); else rerender(); };
      r.appendChild(ad);
    }
    if (G.zoneId === 'town') { const pr = EC.potionPrice(k), buyB = el('button', 'btn gold', `Comprar com Mira · ${fmt(pr)} de ouro`); buyB.disabled = P.gold < pr; buyB.onclick = () => { if (EC.buyConsumable(k)) { bus.emit('sfx', 'coin'); rerender(); } }; r.appendChild(buyB); }
    else b.appendChild(el('p', 'muted', 'Mira, a Mercadora, vende poções na vila. Um Pergaminho de Retorno leva você até lá.'));
    b.appendChild(r);
  });
};
// Предложение у «стены» (js/platform/offers.js): один раз, в спокойный момент, с честными бесплатными путями рядом
// П24: что именно даёт покупка — иконками (золото, зелья) и сами вещи с подписью «сейчас надето» и сравнением.
// Вещи выпадают заранее (offerPreview) и всегда сильнее надетого; их же выдаёт покупка
function offerContents(b, id) {
  const P = G.profile, items = offerPreview(id) || [];
  const pack = id === 'starter_pack' ? [['gold', 1000, 'ouro'], ['potion_hp', 10, 'poções de vida'], ['potion_mp', 5, 'poções de mana']] : id === 'potion_pack' ? [['potion_hp', 15, 'poções de vida'], ['potion_mp', 10, 'poções de mana']] : [];
  if (pack.length) b.appendChild(el('div', 'of-pack', pack.map(([ic, n, t]) => `<div class="of-x"><img src="${iconURL(ic)}" alt=""><b>×${fmt(n)}</b><small>${t}</small></div>`).join('')));
  for (const it of items) {
    const cur = P.gear[it.slot], rows = compare(P, it, it.slot).filter(r => typeof r.delta === 'number' && r.delta !== 0).slice(0, 4);
    b.appendChild(el('div', 'rw-card r' + it.rarity, `<div class="slot r${it.rarity}"><img src="${iconURL(iconOf(it))}">${it.upg ? `<span class="up">+${it.upg}</span>` : ''}</div><div><div class="it-name" style="color:${RARITY[it.rarity].color}">${esc(it.name)}</div><div class="it-type">${RARITY[it.rarity].name} · ${it.wt ? WEAPONS[it.wt].name : SLOT_NAMES[it.slot]} · ⚔ ${itemPower(it)}</div>${it.affixes.slice(0, 3).map(a => `<div class="it-aff">${esc(affixText(a))}</div>`).join('')}${epicOf(it) ? `<div class="it-epic">★ ${esc(epicOf(it).desc)}</div>` : ''}
      <div class="rw-eq"><div class="muted" style="margin:4px 0">Equipado agora: "${esc(cur ? cur.name : '—')}"${cur ? ` · ⚔ ${itemPower(cur)}` : ''}</div>${rows.map(r => `<div class="cmp ${r.delta > 0 ? 'up' : 'dn'}"><span>${esc(r.label)}</span><b>${r.before}${r.suf} → ${r.after}${r.suf} ${r.delta > 0 ? '▲' : '▼'}</b></div>`).join('')}</div></div>`));
  }
}
export function showWallOffer() {
  const w = wallOffer(); if (!w || G.modalOpen || inCombat() || inCinema()) return false;
  markShown(w.id, w.promo);
  const pr = platform.p.catalogPrice(w.id);
  const price = !pr ? '' : typeof pr === 'string' ? esc(pr) : `${esc(pr.value)} ${pr.img ? `<img class="cur" src="${esc(pr.img)}" alt="${esc(pr.code)}">` : esc(pr.code)}`;
  modal(w.product.title, 'sm', b => {
    b.appendChild(el('div', 'offer', `<div class="ic">${esc(w.product.icon || '★')}</div><div class="tx"><b>${esc(w.product.desc)}</b><div class="muted">${esc(w.why)}</div></div>`));
    offerContents(b, w.id);
    b.appendChild(el('p', 'muted', 'Dá para zerar o jogo sem compras. Caminhos grátis: subir de nível nas áreas liberadas, temperar e fundir itens com Goran, o Ferreiro, vencer etapas da Crônica de Batalhas.'));
    const r = el('div', 'row');
    const bt = el('button', 'btn gold', price || 'Comprar'); bt.onclick = () => { closeModal(); buy(w.id); };
    const no = el('button', 'btn', 'Eu me viro'); no.onclick = closeModal;
    r.append(bt, no); b.appendChild(r);
  });
  return true;
}
// три поражения подряд в одном месте — бесплатная помощь, чтобы не бросили игру
// П22: бесплатная «подмога или сам справлюсь» была выбором без цены — отказываться незачем. Теперь:
// пока идёт обучение (реклама закрыта) — Орден помогает сам, +15% урона на 10 мин; после — честный выбор: подмога сильнее (+30%) за рекламу,
// или дальше без неё (предложение повторится при следующей гибели в этом же месте)
function helpBlock(where) {
  const P = G.profile, give = (k, txt) => { P.boosts.helpUntil = Date.now() + 10 * 60e3; P.boosts.helpK = k; G.stats = stats(P); helpGiven(where); bus.emit('statsChanged'); bus.emit('toast', { text: txt, kind: 'good' }); };
  const box = el('div', 'death-help', '<b>Trecho difícil — terceira tentativa seguida</b>');
  if (earlyLock('extra')) { give(1.15, 'Ajuda da Ordem: +15% de dano por 10 minutos'); box.appendChild(el('p', 'good', 'A Ordem enviou ajuda: +15% em todo o dano por 10 minutos.')); return box; }
  box.appendChild(el('p', 'muted', 'A Ordem pode enviar ajuda: <b class="good">+30% em todo o dano por 10 minutos</b>.'));
  box.appendChild(adButton('Ajuda da Ordem · +30% de dano', 'order_help', 0, () => give(1.3, 'Ajuda da Ordem: +30% de dano por 10 minutos'), () => { box.innerHTML = '<b class="good">✓ A ajuda da Ordem está com você: +30% de dano por 10 minutos</b>'; }));
  return box;
}
export function showStreakHelp() { return false; }   // оставлено для старых вызовов: подмога — в экране гибели (helpBlock)

// ---------------------------------------------------------------- death / boss reward / chapter end
// П66: надпись гибели — только до телепорта: в новой локации (деревня после «В деревню») экран гибели всегда убран
bus.on('zoneEntered', () => { const d = $('death'); if (d) d.classList.add('hidden'); });
function showDeath() {
  if (!G.player || !G.player.dead) return;   // уже воскрес/перенесён, пока ждали 1,3 с
  const d = $('death'); d.classList.remove('hidden'); G.paused = true;
  d.innerHTML = `<h2>Você Morreu</h2><p class="muted">${G.zoneId === 'wild' ? 'Carga perdida. O inimigo se lembra de você — volte e vingue-se.' : G.run ? `Andar ${G.run.floor} não vencido. O ouro coletado fica com você.` : 'Os mortos-vivos triunfam… mas a Ordem dá uma segunda chance.'}</p>`;
  { const h = G.lastHit, EL = { fire: 'de fogo', cold: 'de frio', light: 'de raio', poison: 'de veneno' }, P = G.profile;   // сборка 49: кто убил и что можно было сделать
    if (h && h.name) { const tip = P.potions.hp > 0 ? `Poções de vida restantes: ${P.potions.hp} — beba antes, com um terço da vida.` : h.big && !h.proj ? 'O golpe forte dele é marcado no chão — saia da zona vermelha ou esquive.' : h.proj ? 'Mate arqueiros e magos primeiro — dá para desviar dos projéteis.' : 'Compre poções com Mira e uma armadura melhor com o ferreiro.';
      d.innerHTML += `<p class="death-why">Morto por: <b>${esc(h.name)}</b>${(() => { const n = (P.fallen || []).filter(f => f.who === h.name.replace(/^Campeão: /, '')).length; return n > 1 ? ` (${n}ª vez)` : ''; })()} — golpe final ${h.dmg}${EL[h.elem] ? ' ' + EL[h.elem] : ''}.<br><small>${tip}</small></p>`; } }
  const row = el('div', 'row'); row.style.justifyContent = 'center';
  const left = Math.max(0, MAX_REVIVES - (G.revives || 0)), canRev = left > 0 && G.zoneId !== 'castle' && G.zoneId !== 'town';
  const ad = el('button', 'btn ad', `Reviver aqui (restam ${left})`);
  ad.onclick = async () => { const tok = offerToken('revive'); const ok = await watchRewarded('revive', tok, () => { }); if (ok) { d.classList.add('hidden'); G.paused = false; revive(true); } };
  if (inPrologue()) {   // сборка 59: в прологе — без деревни и без потери золота: склеп начинается заново
    d.querySelector('p.muted').textContent = 'A Cripta do Despertar não foi concluída. Tente de novo: afaste-se dos golpes preparados e ataque primeiro.';
    const again = el('button', 'btn gold', 'De novo'); again.onclick = () => { d.classList.add('hidden'); G.paused = false; revive(false); };
    row.append(again); d.appendChild(row); return;
  }
  const loss = Math.floor(G.profile.gold * 0.1);
  const town = el('button', 'btn gold', `Para a vila (−${loss} ouro)`); town.onclick = () => { G.profile.gold -= loss; d.classList.add('hidden'); G.paused = false; revive(false); };
  if (canRev) row.append(ad); row.append(town); d.appendChild(row);
  if (helpWhere) { d.appendChild(helpBlock(helpWhere)); helpWhere = null; }
  if (!canRev && G.zoneId !== 'castle' && G.zoneId !== 'town') d.appendChild(el('p', 'bad', 'Sem revividas nesta incursão — volte à vila, cure-se e fique mais forte.'));
  d.appendChild(el('p', 'muted', '<small>Voltar custa 10% do seu ouro. A masmorra é repovoada, incluindo a elite e o chefe se não forem derrotados.</small>'));
}
function bossReward(k) {
  if (G.player.dead) return;
  modal('Carrasco do Abismo derrotado!', 'sm', b => {
    b.appendChild(el('p', '', k.repeat ? 'Ouro e fragmentos do Abismo estão espalhados pela arena. O Carrasco voltará em 30 minutos — um cronômetro marca onde ele caiu.' : 'Ouro espalhado pela arena — colete-o. A recompensa principal aguarda na janela da missão.'));   // П45
    b.appendChild(el('p', 'good', 'Um portal para casa se abriu no centro da arena.'));
    const row = el('div', 'row');
    const ad = el('button', 'btn ad', 'Item raro bônus'); ad.onclick = () => offers.bossExtra(k.id, k.x, k.y).then(ok => { if (ok) closeModal(); });
    const ok = el('button', 'btn gold', 'Coletar espólio'); ok.onclick = closeModal; row.append(ad, ok); b.appendChild(row);
  });
}
// Осколок памяти: сюжетная сцена после победы над стражем печати. Один раз на осколок (profile.story.mem).
export function showMemory(id) {
  const M = MEMORIES[id]; if (!M) return;
  const S = G.profile.story; S.mem = S.mem || {};
  if (S.mem[id]) return; S.mem[id] = 1; bus.emit('save');
  const seals = SEALS.filter(x => (S.flags || {})['seal_' + x.id]).length;
  // фото мамы (М31): после склепа облёт нового портала («Открыт портал: Разрушенный храм») успевал начаться в эти 1,4 с и шёл поверх окна —
  // окно резалось чёрными полосами, «Дальше» не нажималась. Теперь облёт ждёт окно (G.memPending), а окно — конец облёта
  G.memPending = true;
  setTimeout(function open() { if (G.cinema) return setTimeout(open, 500); G.memPending = false; modal(M.title, 'sm', b => {
    const box = el('div', 'mem-box', `<div class="mem-ic">${M.kind === 'turn' ? '✦' : '◈'}</div><div class="mem-sub">${esc(M.sub || '')}</div>`);
    for (const l of M.lines) box.appendChild(el('p', '', esc(l)));
    box.appendChild(el('div', 'mem-seals', SEALS.map((x, i) => `<i class="${i < seals ? 'on' : ''}" title="${esc(x.name)}"></i>`).join('')));
    box.appendChild(el('div', 'muted', `Selos: ${seals} de ${SEALS.length}`));
    b.appendChild(box);
    const r = el('div', 'row'); r.style.justifyContent = 'center'; const ok = el('button', 'btn gold', 'Avançar'); ok.onclick = () => closeModal(); r.appendChild(ok); b.appendChild(r);
  }, { sticky: true }); }, 1400);
  bus.emit('sfx', 'levelup');
}
const CH_DONE = {
  1: ['O primeiro selo está inteiro de novo — o Carrasco do Abismo caiu.', 'Começa o Capítulo II "Sombras Além do Limiar". São quatro selos: o segundo na Floresta Antiga, o terceiro nos Fiordes de Skjold. Primeira missão — achar o portal de gelo no nordeste da vila. As Catacumbas crescem com você; o Carrasco pode ser enfrentado de novo.'],
  2: ['O segundo e o terceiro selos resistiram: o Senhor do Matagal e o Jötunn Skjold foram derrotados.', 'Começa o Capítulo III "Ossos de Gigantes". O jötunn moribundo revelou o quarto selo: os Ermos de Ossos, pelo portal de crânios no lado esquerdo da vila. Lá também está quem quebra os selos.'],
  3: ['O quarto selo está inteiro, e sua memória voltou por completo.', 'Começa o Capítulo IV "A Cidadela de Morven" — o final. A Cidadela está aberta; Morven aguarda no Salão das Provas. Fique mais forte antes: Profundezas, Crônica de Batalhas, conjuntos do ferreiro.'],
  4: ['O Abismo está selado, Morven derrotado. A história de Vau Sereno chegou ao fim.', 'Círculos do Abismo liberados: escolha um círculo na janela das Profundezas — quanto mais alto, mais ferozes os inimigos, mais ouro e mais chance de itens dourados e Míticos. Ainda restam: recordes das Profundezas, Colheita do Abismo, fortes das expedições, a Crônica e os contratos do quadro.'],
};
function chapterDone(n = 1) {
  if (n === 1) G.profile.chapterDone = true;
  if (n === 4) G.profile.storyDone = true;
  bus.emit('save');
  if (n === 3) bus.emit('memory', 'elvin');
  if (n === 4) bus.emit('memory', 'final');
  const roman = ['', 'I', 'II', 'III', 'IV'][n] || n;
  setTimeout(() => modal(`Capítulo ${roman} concluído!`, 'sm', b => {
    const t = CH_DONE[n] || CH_DONE[4];
    b.appendChild(el('p', '', t[0])); b.appendChild(el('p', 'muted', t[1]));
    const r = el('div', 'row'); const ok = el('button', 'btn gold', 'Continuar'); ok.onclick = closeModal; r.appendChild(ok); b.appendChild(r);
  }), 1200);
}
export { W };

// ---------------------------------------------------------------- Depths: floor select, results, dozor, daily
W.depths = () => modal('Profundezas das Catacumbas', 'sm', b => {
  const P = G.profile; P.depths = P.depths || { best: 0, stars: {} };
  b.appendChild(artHead(ART.zone('depths')));   // сборка 58
  const tq = CS.torches(); const tl = CS.nextIn(tq, CS.TORCH_MS);
  const trow = el('div', 'row', `<b class="goldc">⚡ Energia: ${tq.n}/${CS.TORCH_MAX}</b>${tl ? `<span class="muted">+1 em ${Math.ceil(tl / 60000)} min</span>` : ''}`);
  { const eb = el('button', 'btn gold sm', '⚡ Obter Energia'); eb.onclick = () => bus.emit('openEnergy', rerender); trow.appendChild(eb); } b.appendChild(trow);
  // новый этаж (дальше рекорда) — без факела, факел уйдёт только за поражение; повтор пройденного — факел сразу
  const enter = f => { const free = f > (P.depths.best || 0); if (!free && !CS.spendTorch()) { bus.emit('toast', { text: 'Sem energia ⚡', sub: 'Recarrega sozinha: 1 a cada 20 minutos. Andares novos não gastam energia', kind: 'warn' }); bus.emit('openEnergy', rerender); return; } closeModal(); loadZone('depths', { floor: f, free }); };
  b.appendChild(el('p', 'muted', 'Partidas curtas de 5–8 minutos. A cada 5º andar há um guardião. Estrelas: ★ vencer, ★★ matar 90% dos inimigos, ★★★ rápido e sem morrer.'));
  // Круги Бездны (после Главы IV): сложность и награда растут от того, насколько глубоко игрок сам захочет
  if (SE.circlesOpen()) { const k = SE.circle();
    const c = el('div', 'weekly-card circle-card', `<b>◉ Círculo do Abismo: ${k || '—'}</b><div class="muted">Inimigos mais resistentes ×${SE.circleHP(k).toFixed(1)}, batem mais forte ×${SE.circleDmg(k).toFixed(1)}, ouro e XP ×${SE.circleRew(k).toFixed(1)}, itens caem mais. Vale para todos os andares.</div>`);
    const row = el('div', 'row circle-row');
    const dn = el('button', 'btn sm', '−'); dn.disabled = k <= 0; dn.onclick = () => { SE.setCircle(k - 1); rerender(); };
    const up = el('button', 'btn sm', '+'); up.disabled = k >= SE.CIRCLE_MAX; up.onclick = () => { SE.setCircle(k + 1); rerender(); };
    const off = el('button', 'btn sm' + (k ? '' : ' gold'), 'Sem círculo'); off.onclick = () => { SE.setCircle(0); rerender(); };
    row.append(dn, el('b', 'circle-n', `${k} / ${SE.CIRCLE_MAX}`), up, off); c.appendChild(row); b.appendChild(c); }
  if (HU.huntFloor()) b.appendChild(el('p', 'bad', `⚠ Caçada: ${esc(HU.bossOf(HU.current()).name)} — andar ${HU.huntFloor()}`));
  { const R = SE.weeklyRule(), WS = SE.weeklyState(), f = HU.huntFloor() || SE.weeklyFloor(P.level),   // сборка 47: если охота ждёт на этаже Глубин — испытание на этом же этаже (чудовище там)
    days = 7 - ((Math.floor(Date.now() / 864e5) + 3) % 7);   // испытание недели (сборка 21)
    const c = el('div', 'weekly-card', `<b>⚔ Prova da Semana: ${esc(R.name)}</b><div>${esc(R.txt)}</div><div class="muted">Andar ${f} das Profundezas comuns${HU.huntFloor() ? ' — o monstro da caçada também está lá' : ''} · ${WS.done ? `seu recorde ${Math.floor(WS.best / 60)}:${String(Math.floor(WS.best % 60)).padStart(2, '0')} · supere seu tempo` : 'primeira vitória da semana — um item (azul/dourado) e recompensa dobrada'} · renova em ${days} d</div><div class="lb muted"></div>`);
    const go = el('button', 'btn gold', WS.done ? 'De novo (contra o tempo)' : 'Aceitar desafio'); go.onclick = () => { closeModal(); loadZone('depths', { floor: f, weekly: true }); }; c.appendChild(go); b.appendChild(c);
    platform.p.getLeaderboard && platform.p.getLeaderboard('weeklyDepths').then(L => { const d = c.querySelector('.lb'); if (d && L && L.length) d.innerHTML = 'Melhores da semana: ' + L.slice(0, 5).map(e => `${e.rank}. ${esc(e.name)} ${Math.floor(e.score / 60000)}:${String(Math.floor(e.score / 1000) % 60).padStart(2, '0')}`).join(' · '); }); }
  if ((P.depths.best || 0) >= 2) {   // сборка 49: модификатор этажа — риск по желанию игрока, награда растёт вместе с ним
    const cur = FLOOR_MODS[P.depthsMod] ? P.depthsMod : '';
    const c = el('div', 'weekly-card mod-card', `<b>☠ Modificador do Andar</b><div class="muted">${cur ? `${esc(FLOOR_MODS[cur].txt)} — ${modReward(FLOOR_MODS[cur])}` : 'Mais difícil, mais rico. Vale para todos os andares, exceto a prova da semana.'}</div>`);
    const row = el('div', 'row mod-row');
    const off = el('button', 'btn sm' + (cur ? '' : ' gold'), 'Nenhum'); off.onclick = () => { P.depthsMod = ''; rerender(); }; row.appendChild(off);
    for (const id of FLOOR_MOD_IDS) { const M = FLOOR_MODS[id], bt = el('button', 'btn sm' + (cur === id ? ' gold' : ''), `${M.glyph} ${esc(M.name)}`); bt.title = M.txt; bt.onclick = () => { P.depthsMod = id; rerender(); }; row.appendChild(bt); }
    c.appendChild(row); b.appendChild(c);
  }
  const next = P.depths.best + 1;
  const go = el('button', 'btn gold', `▶ Andar ${next}${isBossFloor(next) ? ' · guardião' : ''}${HU.huntFloor() === next ? ' · ⚠ caçada' : ''} (inimigos Nv. ${floorLevel(next)})`);
  go.style.width = '100%'; go.disabled = P.level < floorLevel(next) - 1; if (go.disabled) go.textContent = `Andar ${next}: requer nível ${floorLevel(next) - 1}`; go.onclick = () => enter(next);
  b.appendChild(go);
  if (P.depths.best) {
    b.appendChild(el('h3', '', 'Andares vencidos'));
    const grid = el('div', 'row');
    for (let f = Math.max(1, P.depths.best - 11); f <= P.depths.best; f++) {
      const s = P.depths.stars[f] || 0; const bt = el('button', 'btn sm' + (HU.huntFloor() === f ? ' gold' : ''), `${HU.huntFloor() === f ? '⚠' : ''}${f}${isBossFloor(f) ? '♛' : ''} ${'★'.repeat(s)}${'☆'.repeat(3 - s)}`);
      bt.onclick = () => enter(f); grid.appendChild(bt);
    }
    b.appendChild(grid);
  }
}, { });

// ---------------------------------------------------------------- Походы: Фьорды Скъёльда / Старый Лес
W.wild = realm => modal(REALMS[realm].name, 'sm', b => {
  const RL = REALMS[realm], WS = wildState(realm), P = G.profile, next = Math.max(1, WS.depth || 1);
  b.appendChild(artHead(ART.zone(realm)));   // сборка 58: лес / фьорды / пустоши
  b.appendChild(el('div', 'q cur', `<div class="qt">${esc(nextGoal(realm))}</div>`));
  b.appendChild(el('p', 'muted', RL.blurb));
  b.appendChild(el('p', 'muted', `Cinco áreas abertas diferentes seguidas: cada uma termina num portal "Mais Fundo", e a próxima área exige um nível. A sexta é ${RL.fortName.toLowerCase()}: mate as feras ao redor para abrir os portões e retome o forte. Mais fundo — mais campos, e a cada dois fortes há um chefe. Sua maior profundidade: <b class="goldc">${WS.depth || 0}</b>.`));
  const enter = d => { closeModal(); loadZone('wild', { realm, depth: d }); };
  const need = wildReqLevel(realm, next);
  const go = el('button', 'btn gold', `▶ ${locationName(realm, next)} · profundidade ${next}${isWildBoss(next) ? ' · chefe' : ''} (inimigos Nv. ${wildLevel(realm, next)})`);
  go.style.width = '100%'; if (P.level < need) { go.disabled = true; go.textContent = `Profundidade ${next}: requer nível ${need}`; } else if (wildDepthGate(realm, next)) { go.disabled = true; go.textContent = `Profundidade ${next}: após derrotar o Carrasco do Abismo`; }   /* П37 */ go.onclick = () => enter(next); b.appendChild(go);
  if ((WS.depth || 0) > 1) {
    b.appendChild(el('h3', '', 'Áreas vencidas')); const grid = el('div', 'row');
    for (let d = Math.max(1, (WS.depth || 1) - 11); d < WS.depth; d++) { const bt = el('button', 'btn sm', `${d}${isWildFort(d) ? (isWildBoss(d) ? '♛' : '⚑') : ''}`); bt.title = locationName(realm, d); bt.onclick = () => enter(d); grid.appendChild(bt); }
    b.appendChild(grid);
  }
  const NS = nemState(), foes = NS.list.filter(n => n.alive && n.realm === realm && (n.rank > 0 || n.defeats || n.fled)), tro = NS.trophies.filter(t => t.realm === realm);
  if (foes.length || tro.length) {
    b.appendChild(el('h3', '', 'Caçada: Inimigos Pessoais'));
    for (const n of foes) b.appendChild(el('div', 'q cur', `<div class="qt">☠ ${esc(displayName(n))} · grau ${n.rank}</div><div class="muted">Forte contra: ${n.traits.map(t => TRAITS[t].name + ' (' + TRAITS[t].txt + ')').join('; ')}</div><div class="muted">Guarda espólio: ${n.stash} ouro</div>`));
    for (const t of tro) b.appendChild(el('div', 'q', `<div class="qt">🏆 ${esc(t.name)}</div><div class="muted">Troféu: +${t.bonus.toFixed(1)}% de dano e ouro para sempre</div>`));
  }
  b.appendChild(el('h3', '', 'Missões da Expedição'));
  for (const q of WILD_QUESTS[realm]) {
    const pr = questProgress(realm, q), rw = [q.reward.gold && `${q.reward.gold} ouro`, q.reward.xp && `${q.reward.xp} de XP`, q.reward.potions && `${q.reward.potions} poções`, q.reward.skillPts && `${q.reward.skillPts} ponto de habilidade`, q.reward.items && q.reward.items.map(i => i.epic ? 'arma épica' : 'item').join(', ')].filter(Boolean).join(' · ');
    const d = el('div', 'q' + (pr.claimed ? '' : ' cur'), `<div class="qt">${pr.claimed ? '✔ ' : ''}${esc(q.title)}</div><div class="muted">${esc(q.text)}</div><div class="muted">Recompensa: ${rw}</div>${pr.claimed ? '' : `<div class="pbar"><i style="width:${pr.cur / pr.max * 100}%"></i></div><div class="muted">${pr.cur} / ${pr.max}</div>`}`);
    if (pr.done && !pr.claimed) { const bt = el('button', 'btn sm gold', 'Pegar recompensa'); bt.style.marginTop = '6px'; bt.onclick = () => { claimQuest(realm, q.id); rerender(); }; d.appendChild(bt); }
    b.appendChild(d);
  }
}, {});

function starsStr(n) { return '★'.repeat(n) + '☆'.repeat(3 - n); }
W.wildResult = r => {
  if (G.zoneId !== 'wild' || !G.wild) return;
  const RL = REALMS[r.realm], mm = Math.floor(r.time / 60), ss = String(r.time % 60).padStart(2, '0');
  modal(r.boss ? `${r.name} derrotado!` : `${RL.fortName} retomado!`, 'sm reward', b => {
    b.appendChild(el('div', 'rw-head', `<div class="rw-rays r${r.stars}"></div><div class="rw-t">Profundidade ${r.depth}</div><div class="stars">${[0, 1, 2].map(i => `<span class="${i < r.stars ? 'on' : ''}" style="animation-delay:${0.3 + i * 0.35}s">★</span>`).join('')}</div>`));
    const row = (ok, t) => `<div>${ok ? '✔' : '○'} ${t}</div>`;
    b.appendChild(el('div', 'stats', `${row(true, 'Forte retomado')}${row(r.chOpen >= r.chTotal, `Todos os baús: ${r.chOpen}/${r.chTotal}`)}${row(r.time <= r.par, `Rápido: ${mm}:${ss} (meta ${Math.floor(r.par / 60)}:${String(r.par % 60).padStart(2, '0')})`)}`));
    if (r.bonus) b.appendChild(el('div', 'rw-loot', `<span class="goldc">+${r.bonus} ouro por novas estrelas</span>`));
    if (r.nem) b.appendChild(el('p', '', `☠ ${esc(r.nem.name)} derrotado — o troféu somou dano e ouro para sempre.`));
    b.appendChild(el('p', 'muted', '🎒 A carga agora é sua, e o ouro vai direto para a bolsa. Pegue os baús restantes ou siga em frente. Quanto mais fundo, mais fortes os inimigos e melhor o espólio.'));
    const rw = el('div', 'row'); rw.style.justifyContent = 'center';
    const nx = el('button', 'btn gold', `Mais Fundo ▶ (profundidade ${r.depth + 1})`); nx.onclick = () => { closeModal(); loadZone('wild', { realm: r.realm, depth: r.depth + 1 }); };
    const stay = el('button', 'btn', 'Ficar no campo'); stay.onclick = closeModal;
    const home = el('button', 'btn', 'Para Casa'); home.onclick = () => { closeModal(); loadZone('town', { from: 'wild', realm: r.realm }); };
    rw.append(nx, stay, home); b.appendChild(rw);
  }, { sticky: true });
};
function floorResult(r) {
  setTimeout(() => {
    const m = modal(r.weekly ? 'Prova da Semana concluída!' : r.first ? 'Novo recorde de profundidade!' : 'Andar vencido', 'sm reward', b => {
      b.appendChild(el('div', 'rw-head', `<div class="rw-rays r${r.stars >= 3 ? 3 : r.stars >= 2 ? 2 : 1}"></div><div class="rw-t">${r.weekly ? 'Prova da Semana' : 'Andar ' + r.floor}</div><div class="stars"${r.weekly ? ' style="display:none"' : ''}>${[0, 1, 2].map(i => `<span class="${i < r.stars ? 'on' : ''}" style="animation-delay:${0.3 + i * 0.35}s">★</span>`).join('')}</div>`));
      const mm = Math.floor(r.time / 60), ss = String(Math.floor(r.time % 60)).padStart(2, '0');
      b.appendChild(el('div', 'stats', `<div><span>Tempo</span><b>${mm}:${ss}</b></div><div><span>Inimigos</span><b>${r.kills}/${r.total}</b></div><div><span>Ouro coletado</span><b>${r.runGold}</b></div>`));
      b.appendChild(el('div', 'rw-loot', `<span class="goldc">+${r.gold} de ouro</span> · <span style="color:#b8e3ff">+${r.xp} de XP</span>${r.first ? ' · <span style="color:#ff9a9a">+1 poção</span>' : ''}`));
      if (r.weekly) b.appendChild(el('p', 'goldc', `${esc(r.weekly)}${r.weeklyFirst ? ' · primeira vitória da semana: item na bolsa/equipado' : ''}${r.weeklyRec ? ' · novo recorde pessoal!' : ''}`));
      const row = el('div', 'row'); row.style.justifyContent = 'center';
      const ad = el('button', 'btn ad', `×2 ouro (+${r.gold})`);
      ad.onclick = () => watchRewarded('floor_x2', offerToken('floor_x2', r.token), () => { G.profile.gold += r.gold; bus.emit('toast', { text: `+${r.gold} de ouro`, kind: 'good' }); }).then(ok => { if (ok) { ad.disabled = true; ad.textContent = '✔ Dobrado'; } });
      const nx = el('button', 'btn gold', `Andar ${r.floor + (r.first ? 1 : 0) + (r.first ? 0 : 1)} ▶`);
      const next = Math.max(r.floor + 1, 1);
      nx.textContent = `Andar ${next} ▶`;
      nx.onclick = async () => { const keepBoons = true; if (G.profile.level < floorLevel(next) - 1) { bus.emit('toast', { text: `Andar ${next} — a partir do nível ${floorLevel(next) - 1}`, sub: 'Farme XP em andares vencidos', kind: 'warn' }); return; } const free = next > (G.profile.depths.best || 0); if (!free && !CS.spendTorch()) { bus.emit('toast', { text: 'Sem energia ⚡', sub: '+1 a cada 20 minutos ou "Obter energia"', kind: 'warn' }); bus.emit('openEnergy'); return; } closeModal(); await maybeInterstitial('floor'); loadZone('depths', { floor: next, keepBoons, free, fullHeal: r.boss }); };   // сборка 49: после босса — передышка, следующий этаж с полным здоровьем
      const home = el('button', 'btn', 'Para a vila');
      home.onclick = async () => { closeModal(); await maybeInterstitial('floor'); loadZone('town', { from: 'depths' }); };
      if (r.weekly) { nx.textContent = 'De novo ▶'; nx.onclick = () => { closeModal(); loadZone('depths', { floor: r.floor, weekly: true }); }; }   // испытание недели: повтор на время, а не следующий этаж
      row.append(ad, nx, home); b.appendChild(row);
      if (r.boss && !r.weekly) b.appendChild(el('p', 'goldc', 'Descanso após o chefe: o próximo andar começa com vida e mana cheias.'));
      const P = G.profile; if (G.run && G.run.boons.length) b.appendChild(el('p', 'muted', `As dádivas do Abismo (${G.run.boons.length}) são mantidas se você descer sem voltar à vila.`)); if (P.attrPts || P.skillPts) b.appendChild(el('p', 'muted', 'Há pontos não gastos — o Mentor Elvin espera na vila.'));
    }, { sticky: true });
    maybeReview(r);
  }, 600);
}
let reviewAsked = false;
async function maybeReview(r) {
  const P = G.profile;
  if (reviewAsked || P.reviewDone || P.stats.playTime < 900 || !(r.stars === 3 || r.boss)) return;
  reviewAsked = true; try { const ok = await PF.p.requestReview(); if (ok) P.reviewDone = true; } catch { }
}
bus.on('bossDefeated', () => { const P = G.profile; if (!reviewAsked && !P.reviewDone && P.stats.playTime > 900) { reviewAsked = true; setTimeout(async () => { try { if (await PF.p.requestReview()) P.reviewDone = true; } catch { } }, 6000); } });
export function showDozor(d) {
  const h = Math.floor(d.ms / 3600e3), mi = Math.floor(d.ms / 60e3) % 60;
  modal('Vigília da Ordem', 'sm reward', b => {
    b.appendChild(el('div', 'rw-head', `<div class="rw-rays r2"></div><div class="rw-t">Enquanto você esteve fora…</div>`));
    b.appendChild(el('p', '', `Seu esquadrão patrulhou as Profundezas por ${h ? h + ' h ' : ''}${mi} min (até o andar ${G.profile.depths.best}).`));
    b.appendChild(el('div', 'rw-loot', `<span class="goldc">+${d.gold} de ouro</span> · <span style="color:#b8e3ff">+${d.xp} de XP</span>`));
    const row = el('div', 'row'); row.style.justifyContent = 'center';
    const ad = el('button', 'btn ad', 'Pegar ×2'); ad.onclick = async () => { const ok = await watchRewarded('dozor_x2', offerToken('dozor_x2', String(G.profile.dozorAt)), () => DQ.claimDozor(2)); if (ok) { G.dozorChecked = true; closeModal(); } };
    const ok = el('button', 'btn gold', 'Pegar'); ok.onclick = () => { DQ.claimDozor(1); G.dozorChecked = true; closeModal(); };
    row.append(ad, ok); b.appendChild(row);
    { const t = CS.torches(), ds = dailyStatus(), wait = [];   // сборка 47: что ещё накопилось, пока игрока не было
      wait.push(`⚡ Energia: ${t.n} de ${CS.TORCH_MAX}${t.n >= CS.TORCH_MAX ? ' — cheia' : ''}`);
      if (ds.claimable && !earlyLock('extra')) wait.push(`🎁 Recompensa do dia ${ds.day} no calendário`);
      try { if (wheelReady() && !earlyLock('extra')) wait.push('🎡 A Roda da Senhora da Roda gira de graça'); } catch { }
      if (ds.claimable) wait.push('📜 Novas missões diárias — no quadro da praça');
      b.appendChild(el('div', 'rw-wait', '<b>Ainda aguarda:</b><br>' + wait.join('<br>'))); }
    b.appendChild(el('p', 'muted', '<small>A Vigília acumula recompensas por até 8 horas. Quanto mais fundo você foi, maior o espólio.</small>'));
  }, { sticky: true });
}
function dailyBlock(b) {
  b.appendChild(el('h3', '', 'Missões Diárias'));
  const list = DQ.dailyQuests(); const r = DQ.dqReward();
  for (const q of list) {
    const d = el('div', 'q' + (q.done && !q.claimed ? ' cur' : '') + (q.claimed ? ' done' : ''), `<div class="qt">${q.claimed ? '✔ ' : ''}${esc(q.title)} — ${q.cur}/${q.n}</div><div class="pbar"><i style="width:${q.cur / q.n * 100}%"></i></div>`);
    if (q.done && !q.claimed) { const bt = el('button', 'btn sm gold', `Pegar: ${r.gold} ouro + poção`); bt.style.marginTop = '6px'; bt.onclick = () => { DQ.claimDaily(q.id); rerender(); }; d.appendChild(bt); }
    b.appendChild(d);
  }
  b.appendChild(el('p', 'muted', `<small>Todas as três — um Baú Diário com item raro para sua classe. Novas missões amanhã.</small>`));
}
export { dailyBlock };

function boonChoice() {
  const r = G.run; if (!r || r.done || G.player.dead) return;
  if (cur) { setTimeout(boonChoice, 600); return; }
  const pool = BOON_IDS.filter(id => !r.boons.includes(id)).sort(() => Math.random() - 0.5).slice(0, 3);
  if (!pool.length) return;
  bus.emit('sfx', 'rareDrop');
  modal('Dádiva do Abismo', 'md reward', b => {
    b.appendChild(el('p', 'muted', 'Uma dádiva por anúncio ou por sangue — dura até o fim do andar. Você pode seguir sem dádiva.'));   // сборка 47: дары за рекламу; сборка 49: или за 30% здоровья
    const row = el('div', 'boons'), pl = G.player, BLOOD = 0.3;
    let blood = false; const tags = [];
    for (const id of pool) {
      const B = BOONS[id];
      const c = el('button', 'boon' + (B.minus ? ' cursed' : ''), `<div class="bg" style="color:${B.color};text-shadow:0 0 18px ${B.color}">${artTag(ART.boon(id), B.glyph)}</div><b>${esc(B.name)}</b><span>${esc(B.desc)}${B.minus ? `<em class="minus">${esc(B.minus)}</em>` : ''}</span><small class="lv">▶ por anúncio</small>`);
      tags.push(c.querySelector('.lv'));
      const give = () => { r.boons.push(id); G.stats = calcStats(G.profile); bus.emit('statsChanged'); bus.emit('toast', { text: 'Dádiva: ' + B.name, kind: 'good' }); bus.emit('sfx', 'learn'); closeModal(); };
      c.onclick = async () => {
        if (blood) { pl.hp = Math.max(1, pl.hp - G.stats.maxHP * BLOOD); particles(pl.x, pl.y, 18, { c: [200, 30, 40], z: 1, sp: 2, size: 3 }); bus.emit('sfx', 'hurt'); give(); bus.emit('hud'); return; }   // здоровье как валюта
        if (G.auto) { give(); return; } await watchRewarded('boon', offerToken('boon', id + ':' + Date.now()), give);
      };
      row.appendChild(c);
    }
    b.appendChild(row);
    const can = pl.hp > G.stats.maxHP * (BLOOD + 0.05);
    const bl = el('button', 'btn blood', can ? '🩸 Pagar com sangue (−30% de vida)' : '🩸 Vida insuficiente para pagar com sangue');
    bl.disabled = !can;
    bl.onclick = () => { blood = !blood; bl.classList.toggle('on', blood); for (const t of tags) t.textContent = blood ? '🩸 por 30% da vida' : '▶ por anúncio'; bl.textContent = blood ? '▶ Melhor por anúncio' : '🩸 Pagar com sangue (−30% de vida)'; };
    b.appendChild(bl);
    const skip = el('button', 'btn', 'Sem dádiva'); skip.onclick = () => closeModal(); b.appendChild(skip);
  }, { sticky: true });
  cur.bg.querySelector('.mx').style.display = 'none';
  if (G.auto) setTimeout(() => { const bs = document.querySelectorAll('.boons .boon'); if (bs.length) bs[Math.floor(Math.random() * bs.length)].click(); }, 2500);
}

// ---------------------------------------------------------------- «Жатва Бездны»
const mmssT = t => `${Math.floor(t / 60)}:${String(Math.floor(t % 60)).padStart(2, '0')}`;
W.survival = () => modal('Colheita do Abismo', 'md', b => {
  const P = G.profile; P.surv = P.surv || { best: 0, ach: {}, runs: 0 };
  b.appendChild(artHead(ART.harvest('intro'), 'tall'));   // сборка 58: староста Эдрик держит портал Жатвы
  b.appendChild(el('p', '', 'Uma arena sem fim do Abismo e ondas infinitas. <b>Só continue se movendo</b> — o herói ataca sozinho. Colete cristais de alma, suba de nível, escolha vantagens e desperte armas. Meta: sobreviver 20 minutos. Os inimigos ficam mais fortes a cada minuto. <b>Cada nível da partida dá ao herói 2,5% do XP de um nível</b> (até 75% por partida).'));
  const row = el('div', 'row'); row.style.cssText = 'justify-content:center;margin:10px 0'; const intro = !(P.story.flags && P.story.flags.bossKilled);
  const go = el('button', 'btn gold', intro ? '▶ Tutorial · 3 minutos' : `▶ Lutar · ${SV.RUN_COST} ⚡`); go.style.width = '100%'; go.onclick = () => { if (!intro && !CS.spendEnergy(SV.RUN_COST)) { bus.emit('toast', { text: `Requer ${SV.RUN_COST} ⚡ de energia`, kind: 'warn' }); bus.emit('openEnergy', rerender); return; } closeModal(); loadZone('survival'); }; row.appendChild(go); b.appendChild(row);   // кнопка вверху: не нужно листать список
  b.appendChild(el('div', 'stats', `<div><span>Recorde</span><b>${mmssT(P.surv.best)}</b></div><div><span>Partidas</span><b>${P.surv.runs}</b></div>`));
  b.appendChild(el('h3', '', 'Conquistas'));
  for (const a of SV.ACH) b.appendChild(el('div', 'q' + (P.surv.ach[a.id] ? ' done' : ''), `<div class="qt">${P.surv.ach[a.id] ? '🏆 ' : '○ '}${esc(a.name)}</div><div class="muted">+${a.gold} ouro · +${a.shards}◆</div>`));
  b.appendChild(el('h3', '', 'Despertares de Armas'));
  b.appendChild(el('div', 'muted', SV.EVOS.map(e => `<b>${esc(e.name)}</b>: ${esc(SV.PERKS[e.from].name)} Nv. 5 + ${esc(SV.PERKS[e.need].name)}`).join('<br>')));
});
function survLevel() {
  const S = G.surv; if (!S || S.over) return;
  if (cur) { setTimeout(survLevel, 500); return; }
  let cs = SV.choices(), extra = false; bus.emit('sfx', 'levelup');
  modal(`Nível ${S.lvl}!`, 'md reward', b => {
    b.appendChild(el('p', 'muted', 'Escolha uma melhoria:'));
    { const rr = el('button', 'btn ad sm', '↻ Renovar por anúncio'); rr.onclick = async () => { const ok = await watchRewarded('surv_reroll', offerToken('surv_reroll', String(Date.now())), () => { S.rerolls++; }); if (ok) { cs = SV.choices(); rerender(); } }; b.appendChild(rr); }   // сборка 47
    const row = el('div', 'boons b4');   // сборка 47: карточки мельче, 4 в ряд; 3 бесплатно, 4-я случайная — за рекламу
    cs.forEach((c, i) => {
      if (i === 3 && !extra) {
        const lock = earlyLock('extra'), card = el('button', 'boon locked', `<div class="bg">?</div><b>Outra opção</b><small class="lv">${lock ? 'após o tutorial' : '▶ por anúncio'}</small><span>Melhoria aleatória</span>`);
        card.disabled = lock;
        card.onclick = async () => { const ok = await watchRewarded('surv_extra', offerToken('surv_extra', String(Date.now())), () => {}); if (ok) { extra = true; rerender(); } };
        row.appendChild(card); return;
      }
      const title = c.evo ? '⚡ ' + c.evo.name : c.gold ? 'Ouro' : c.P.name, desc = c.evo ? c.evo.desc : c.gold ? '+50 de ouro' : c.P.desc(c.lvl), lv = c.evo ? 'DESPERTAR' : c.gold ? '' : c.lvl ? `Nv. ${c.lvl} → ${c.lvl + 1}` : 'novo';
      const card = el('button', 'boon' + (c.evo ? ' evo' : ''), `<div class="bg">${c.evo ? artTag(ART.evo(c.evo.id), '✹') : c.gold ? '⛁' : artTag(ART.perk(c.id), c.P.icon || '⚔')}</div><b>${esc(title)}</b><small class="lv">${lv}</small><span>${esc(desc)}</span>`);
      card.onclick = () => { SV.take(c); closeModal(); };
      row.appendChild(card);
    });
    b.appendChild(row);
  }, { sticky: true });
  cur.bg.querySelector('.mx').style.display = 'none';
}
function survEnd(r) {
  setTimeout(() => modal(r.win ? 'Você sobreviveu!' : 'Colheita encerrada', 'sm reward', b => {
    b.appendChild(artHead(ART.harvest(r.win ? 'victory' : 'defeat'), 'tall'));   // сборка 58: рассвет над ареной / волна мертвецов
    b.appendChild(el('div', 'rw-head', `<div class="rw-rays r${r.win ? 3 : 1}"></div><div class="rw-t">${mmssT(r.t)}${r.record ? ' · recorde!' : ''}</div>`));
    b.appendChild(el('div', 'stats', `<div><span>Abates</span><b>${r.kills}</b></div><div><span>Nível da partida</span><b>${r.lvl}</b></div>`));
    b.appendChild(el('div', 'rw-loot', `<span class="goldc">+${r.gold} de ouro</span>${r.heroXP ? ` · <span style="color:#b8e3ff">+${r.heroXP} de XP para o herói</span>` : ''}${r.shards ? ` · <span class="c-shard">+${r.shards}◆</span>` : ''}`));
    if (r.intro) b.appendChild(el('p', 'goldc', 'Ancião Edric: "Não dá mais para segurar o portal — nossas forças acabaram. Junte ouro e procure o Mentor Elvin para melhorias. A Colheita reabre quando o Carrasco do Abismo cair."'));
    if (r.newAch.length) b.appendChild(el('p', 'goldc', '🏆 ' + r.newAch.map(esc).join(' · ')));
    const row = el('div', 'row'); row.style.justifyContent = 'center';
    const again = el('button', 'btn gold', `De novo · ${SV.RUN_COST} ⚡`); again.onclick = () => { if (!CS.spendEnergy(SV.RUN_COST)) { bus.emit('toast', { text: `Requer ${SV.RUN_COST} ⚡ de energia`, kind: 'warn' }); bus.emit('openEnergy'); return; } closeModal(); loadZone('survival'); };
    const home = el('button', 'btn', 'Para a vila'); home.onclick = () => { closeModal(); loadZone('town', { from: 'survival' }); };
    if (!r.intro) row.append(again); row.append(home); b.appendChild(row);
  }, { sticky: true }), 700);
}

// ---------------------------------------------------------------- lore intros (first visit)
const LORE = {
  depths: ['Profundezas das Catacumbas', 'As catacumbas da Ordem não têm fundo. A cada quinto andar há um guardião, e além deles há uma escuridão cada vez mais antiga: criptas inundadas, minas de cinzas e, dizem, o próprio Coração do Abismo. As dádivas do Abismo ajudam — mas só até você dar meia-volta.'],
  // сборка 60 (П13): вместо легенды — короткая инструкция
  survival: ['Colheita do Abismo · como jogar', 'Aqui não precisa de botões de combate.', ['🏃 Só corra — o herói ataca sozinho. Deslize o dedo pela tela.', '💎 Inimigos soltam almas azuis — corra até elas, são coletadas sozinhas. Encheu a barra — novo nível: escolha uma habilidade nova ou melhore uma antiga.', '🏹 Desvie das flechas e projéteis inimigos — corra para o lado.', '⏳ Não fique parado na multidão e aguente o máximo possível.']],   // правки мамы (М10)
  castle: ['Cidadela da Ordem', 'Aqui viviam os grão-mestres da Ordem. Agora é o seu lar. Abra os salões: o altar acumula ouro enquanto você dorme, e no Salão das Provas guardiões do passado testarão sua força.'],
};
bus.on('zoneEntered', id => { const P = G.profile; P.lore = P.lore || {}; const L = LORE[id]; if (!L || P.lore[id] || (id === 'depths' && !(G.run && G.run.floor > 0))) return; P.lore[id] = 1; bus.emit('save');
  const show = () => { if (cur) { setTimeout(show, 800); return; } modal(L[0], 'sm reward', b => { b.appendChild(artHead(ART.zone(id))); b.appendChild(el('p', 'lore', esc(L[1]))); if (L[2]) b.appendChild(el('div', 'lore-how', L[2].map(x => `<div>${esc(x)}</div>`).join(''))); const r = el('div', 'row'); r.style.justifyContent = 'center'; const ok = el('button', 'btn gold', 'Avante'); ok.onclick = closeModal; r.appendChild(ok); b.appendChild(r); }); cur.bg.classList.add('rw-bg'); }; setTimeout(show, 600); });

// ---------------------------------------------------------------- main menu: big labelled tiles instead of a row of tiny icons
W.menu = () => modal('Menu', 'md', b => {
  const tiles = [
    ['inventory', '🎒', 'Herói', 'equipamento e bolsa', 'dotInv'], ['character', '🛡', 'Personagem', 'atributos', 'dotChar'], ['skills', '✦', 'Habilidades', 'habilidades e botões', 'dotSkill'],
    ['journal', '📜', 'Missões', 'história e diárias'], ['map', '🗺', 'Mapa', 'área atual'],
    ['herospath', '⚔', 'Crônica de Batalhas', 'combates automáticos', 'dotHW'], ['shrine', '🎁', 'Fonte de Poder', 'dádivas, Poder da Fonte', 'dotGift'], ['season', '🏆', 'Trilha da Temporada', SE.seasonName() + ' · 30 níveis', 'dotSeason'], ['codex', '📖', 'Coleção', '+0,5% por achado'],
    ['help', '❓', 'Ajuda', 'dicas e tutorial'], ['settings', '⚙', 'Configurações', 'som, gráficos'],
  ];
  const g = el('div', 'menu-grid');
  for (const [id, ic, name, sub, badge] of tiles) {
    const locked = TOWN_ONLY[id] && G.zoneId !== 'town';
    const n = badge ? BADGES[badge] || 0 : 0;
    const t = el('button', 'menu-tile' + (locked ? ' locked' : ''), `<span class="mt-ic">${ic}</span><b>${name}</b><small>${locked ? 'na vila' : sub}</small>${n ? `<span class="mt-dot">${n}</span>` : ''}`); t.dataset.w = id;
    t.onclick = () => { closeModal(); openWindow(id); };
    g.appendChild(t);
  }
  b.appendChild(g);
  setTimeout(() => bus.emit('menuOpened'), 60);   // сборка 60 (П32): обучение показывает плитку «Герой»
});
