// Proximity panels: walk into an NPC/room circle → the panel opens by itself; walk away → it closes.
// The game keeps running (no pause). Everything shows the price and the effect up front.
import { G, bus } from '../game/ctx.js';
import { $, el, esc, fmt, ICO } from '../core/util.js';
import { UPGRADES, upgCost, upgHave, ROOMS, DECOR } from '../data/upgrades.js';
import { REPEATABLE } from '../data/quests.js';
import { REALMS } from '../data/wild.js';
import * as CH from '../game/character.js';
import * as EC from '../game/economy.js';
import * as Q from '../game/quests.js';
import * as CS from '../game/castle.js';
import * as DQ from '../game/daily.js';
import { upgradeCost, MAX_UPG, iconOf } from '../game/items.js';
import { iconURL } from './icons.js';
import { openWindow, W } from './windows.js';
import { watchRewarded, offerToken } from '../platform/monetize.js';
import { startTrial } from '../game/game.js';
import { adButton } from './adbtn.js';
import { stats } from '../game/stats.js';
import { earlyLock } from '../game/progress.js';
import { PETS, TIERS, PET_MAX, GIFT_PET, TRAIN, TRAIN_MAX, TRAIN_STEP } from '../data/pets.js';
import * as PT from '../game/pets.js';

let target = null, box = null, lastSig = '', dismissed = null;
export function initPanel() {
  box = el('div', 'npc-panel hidden'); box.id = 'npcPanel'; $('ui').appendChild(box); box.addEventListener('scroll', moreDn, { passive: true });
  // правки мамы (М30): выполненное задание сдаётся сразу, как подошли к жителю (кузнец, Мира, Элвин, Кофи) — раньше только после второго подхода
  // или открытия его окна, и стрелка всё вела к нему
  bus.on('panel', t => { if (!t) dismissed = null; target = t; lastSig = ''; if (t && t.id && Q.isReady() && Q.turnNpc(Q.current()) === t.id) Q.talked(t.id); render(true); });
  // tap anywhere on the game field outside the panel → close it until you walk away and come back
  const hide = e => { if (!target || box.classList.contains('hidden') || box.contains(e.target)) return; dismissed = target; render(true); };
  for (const id of ['game', 'joyZone']) { const n = $(id); if (n) n.addEventListener('pointerdown', hide, true); }
  for (const ev of ['hud', 'statsChanged', 'roomUnlocked', 'save']) bus.on(ev, () => render());
  setInterval(() => render(), 1000);   // live timers (altar, seals)
}
const coin = n => `<span class="c-gold">${fmt(n)}</span>`;
const shard = n => `<span class="c-shard">${n}◆</span>`;
function row(icon, title, sub, btnText, ok, onClick, extraCls = '') {
  const r = el('div', 'pn-row ' + extraCls, `<div class="pn-ic">${icon}</div><div class="pn-tx"><b>${title}</b><small>${sub}</small></div>`);
  if (btnText != null) { const b = el('button', 'pn-btn' + (ok ? ' ok' : ''), btnText); b.disabled = !ok; b.onpointerdown = e => { e.stopPropagation(); onClick(); bus.emit('sfx', 'click'); render(true); }; r.appendChild(b);
    // правки мамы (М6): нажатие на саму строку («Зелье здоровья») тоже покупает — раньше срабатывала только зелёная кнопка справа.
    // Строку жмём коротким касанием (click), чтобы прокрутка списка пальцем ничего не покупала
    if (ok) { r.classList.add('tap'); r.onclick = e => { if (e.target.closest('button')) return; onClick(); bus.emit('sfx', 'click'); render(true); }; } }
  return r;
}
// правки мамы (М2): внизу панели «▼ ещё ниже», пока список не долистан
const moreDn = () => box && box.classList.toggle('more-dn', box.scrollHeight - box.clientHeight - box.scrollTop > 8);
function render(force) {
  if (!box) return;
  const showing = !(!target || target === dismissed || G.modalOpen || G.player.dead); $('ui').classList.toggle('panel-open', showing);
  if (!showing) { box.classList.add('hidden'); return; }
  const P = G.profile; const sig = [target.id, P.gold, P.shards, P.level, P.attrPts, P.skillPts, JSON.stringify(P.upg), JSON.stringify(P.castle), JSON.stringify(P.pets), P.potions.hp, Math.floor(Date.now() / 1000)].join('|');
  if (!force && sig === lastSig) return; lastSig = sig;
  const st = box.scrollTop; box.innerHTML = ''; box.classList.remove('hidden'); setTimeout(moreDn, 0);
  const head = (t, s) => { const h = el('div', 'pn-head', `<b>${t}</b>${s ? `<small>${s}</small>` : ''}`); const x = el('button', 'pn-x', '✕'); x.onpointerdown = e => { e.stopPropagation(); dismissed = target; render(true); }; h.appendChild(x); box.appendChild(h); };
  const bal = () => box.appendChild(el('div', 'pn-bal', `${coin(P.gold)} ouro · ${shard(P.shards || 0)}`));
  const T = target;
  if (T.id === 'trainer') {
    head('Mentor Elvin', 'Aqui se aprendem habilidades. Abaixo: melhorias por ouro (Precisão por fragmentos do Abismo ◆).'); bal();
    const b2 = el('div', 'pn-tabs');
    const sk = el('button', 'pn-tab' + (CH.canLearnNow() ? ' hot' : ''), `<span>✦</span><b>Habilidades</b>${P.skillPts ? `<i>+${P.skillPts}</i>` : ''}`); sk.id = 'tBtnSkills'; sk.onclick = () => W.skills({ npc: true });
    b2.append(sk); box.appendChild(b2);
    if (P.skillPts && !Object.values(P.skills || {}).some(Boolean)) box.appendChild(el('div', 'pn-tip', '💡 Aprenda primeiro uma <b>habilidade ativa</b> — ela aparece como botão no canto inferior direito e facilita muito as lutas.'));
    box.appendChild(el('div', 'pn-sub', 'Melhorias'));
    const upLock = earlyLock('upg');   // сборка 47: усиления — после первой Летописи битв
    if (upLock) box.appendChild(el('div', 'pn-tip', '🔒 As melhorias liberam quando você se testar na <b>Crônica de Batalhas</b> e voltar com ouro.'));
    // правки мамы (М8): было непонятно, что значит «усилить героя» — умение или усиления. Засчитывается любое из двух — так и пишем,
    // и то, на что хватает золота, пульсирует
    const elvStep = !upLock && Q.current() && (Q.current().id === 'hw_elvin' || Q.current().id === 'surv_elvin');
    const rankOk = elvStep && P.skillPts > 0 && Object.keys(P.skills || {}).some(id => P.skills[id] && CH.canLearn(id).ok && P.gold >= CH.skillCost(id));
    if (elvStep) box.appendChild(el('div', 'pn-tip', `💡 Gaste o ouro em uma de duas coisas: ${P.skillPts > 0 ? '<b>✦ Habilidades</b> — suba o nível de uma habilidade (você tem um ponto de habilidade) ou ' : ''}compre uma melhoria abaixo — <b>Poder de Golpe</b> ou <b>Fortitude</b>. A missão conta logo após a compra.`));
    if (rankOk) sk.classList.add('nudge');
    let nudged = rankOk;
    for (const [id, U] of Object.entries(UPGRADES)) {
      const l = (P.upg && P.upg[id]) || 0, max = l >= U.max, cost = upgCost(id, l), can = !upLock && !max && upgHave(P, id) >= cost;
      const r = row(U.icon, `${U.name} <span class="lv">Nv. ${l}</span>`, max ? U.fmt(l) + ' · máximo' : `${U.fmt(l)} → <span class="good">${U.fmt(l + 1)}</span>`, max ? '—' : upLock ? '🔒' : U.shards ? `${cost}◆` : `${fmt(cost)}`, can, () => buyUpg(id));
      r.querySelector('.pn-btn').classList.add('cost');   // крупная цена и осколок на всю кнопку (а не мелкая цифра посреди пустой кнопки)
      if (elvStep && can && !nudged && !U.shards) { r.querySelector('.pn-btn').classList.add('nudge'); r.classList.add('hot'); nudged = true; }
      box.appendChild(r);
    }
  } else if (T.id === 'smith') {
    head('Goran, o Ferreiro', 'Fusão: três itens → um melhor. Têmpera: +10% por nível.'); bal();
    { const ready = EC.mergeGroups().reduce((a, g) => a + g.can, 0);   // сборка 38: слияние на виду, первой кнопкой
      const m = el('button', 'btn pn-merge ' + (ready ? 'gold' : ''), `⚒ Fundir 3 → 1${ready ? ` · ${ready} pronto(s)` : ''}`); m.onclick = () => W.npc_smith('merge'); box.appendChild(m);
      if (!ready) box.appendChild(el('div', 'pn-tip', '💡 <b>Fusão</b> — o ferreiro funde três itens iguais (mesmo tipo e cor, por exemplo três elmos verdes) em um mais forte. Ainda não há o que fundir: itens caem de inimigos e baús.')); }   // М30: «что такое слияние — непонятно»
    box.appendChild(el('div', 'pn-sub', 'Temperar Equipados'));
    for (const slot of ['weapon', 'head', 'chest', 'amulet']) {
      const it = P.gear[slot]; if (!it) continue; const u = it.upg || 0, c = upgradeCost(it);
      box.appendChild(row(`<img src="${iconURL(iconOf(it))}">`, `${esc(it.name)} <span class="lv">+${u}</span>`, it.dmg ? 'dano' : 'defesa', u >= MAX_UPG ? 'máx.' : `+${u + 1} · ${fmt(c)}`, u < MAX_UPG && P.gold >= c, () => EC.upgrade(it.id)));
    }
    const b = el('button', 'btn sm', 'Temperar Itens da Bolsa'); b.onclick = () => W.npc_smith('upg'); box.appendChild(b);
  } else if (T.id === 'merchant') {
    head('Mira, a Mercadora'); bal();
    const potStep = Q.current() && Q.current().id === 'meet_merchant';
    if (potStep) box.appendChild(el('div', 'pn-tip', '💡 Compre uma <b>Poção de Vida</b>: toque no botão verde "Comprar" na linha dela. Em combate, toque no botão vermelho de poção — ela cura. Tecla <b>Q</b> no PC.'));
    for (const [k, n, ic] of [['hp', 'Poção de Vida', 'potion_hp'], ['mp', 'Poção de Mana', 'potion_mp'], ['scroll', 'Pergaminho de Retorno', 'scroll']]) {
      const pr = EC.potionPrice(k), r = row(`<img src="${iconURL(ic)}">`, n, `possui: ${k === 'scroll' ? P.scrolls : P.potions[k]}`, `Comprar<br>${fmt(pr)}`, P.gold >= pr, () => EC.buyConsumable(k), potStep && k === 'hp' ? 'hot' : '');
      box.appendChild(r);
      // М6: на шаге «Купить зелье» кнопка покупки пульсирует (панель перерисовывается раз в секунду — палец бы пропадал)
      if (potStep && k === 'hp' && P.gold >= pr) r.querySelector('.pn-btn').classList.add('nudge');
    }
    const b = el('button', 'btn sm', 'Ofertas do Dia para sua Classe'); b.onclick = () => W.npc_merchant(); box.appendChild(b);
  } else if (T.id === 'caravan') {
    // сборка 58: Караванщик Кофи — питомцы за осколки Бездны (js/data/pets.js, js/game/pets.js)
    const S = PT.petsOf(P);
    head('Kofi, o caravaneiro', 'Feras das Terras Ermas. Uma anda com você: bate fraco, mas cada uma tem seu dom.'); bal();
    // правки к сборке 60: подарок здесь брали в обход старосты (шаг «Заглянуть к Кофи» потом засчитывался сам) и без поздравления.
    // До этого шага — только обещание; на шаге — крупная мигающая кнопка и праздник на весь экран (W.petReveal)
    if (!S.met && earlyLock('pet')) box.appendChild(el('div', 'pn-tip', '🎁 Kofi tem um presente para você — poderá pegá-lo quando o ancião Edric mandar você até ele.'));
    else if (!S.met) {
      box.appendChild(el('div', 'pn-tip', `🎁 Um presente de Kofi: <b>${PETS[GIFT_PET].name}</b>. ${PETS[GIFT_PET].desc}`));
      const g = el('button', 'btn gold pet-gift', '🎁 Pegar o presente'); g.onpointerdown = e => { e.stopPropagation(); if (PT.meetCaravan()) { dismissed = target; render(true); W.petReveal(); } }; box.appendChild(g);
    }
    const btn = (r, text, ok, fn, cls = '') => { const b = el('button', 'pn-btn' + (ok ? ' ok' : '') + cls, text); b.disabled = !ok; b.onpointerdown = e => { e.stopPropagation(); fn(); render(true); }; r.appendChild(b); };
    for (const [id, D] of Object.entries(PETS)) {
      const lvl = S.own[id] || 0, c = PT.petCan(id), T0 = TIERS[D.tier], on = S.active === id;
      const sub = `<span style="color:${T0.color}">${T0.name}</span> · ⚔ ${PT.petInfo(id, lvl || 1).dps}/s · ${D.desc}`;
      const r = row(D.icon, `${esc(D.name)}${lvl ? ` <span class="lv">nv. ${lvl}</span>` : ''}`, sub, null, false, null, on ? 'hot' : '');
      { const ib = el('button', 'pn-btn ok pn-info', 'ℹ'); ib.title = 'Dano e dom do mascote'; ib.onpointerdown = e => { e.stopPropagation(); W.petInfo(id); }; r.appendChild(ib); }   // П61
      if (!lvl) btn(r, c.why ? '🔒 ' + c.why : `${c.cost}◆`, c.ok, () => PT.buyPet(id), c.why ? '' : ' cost');
      else {
        btn(r, on ? '✔ Com você' : 'Levar', !on, () => PT.choosePet(id));
        if (lvl < PET_MAX) btn(r, `▲ ${c.cost}◆`, c.ok, () => PT.upgradePet(id), ' up cost');
      }
      box.appendChild(r);
    }
    // П29 (правки 2): дрессировка за золото — физический и магический урон всех питомцев; короткое обучение при первом заходе
    if (S.met) {
      box.appendChild(el('div', 'pn-sub', 'Adestramento (para todos os mascotes)'));
      if (!S.tut) {
        const tip = el('div', 'pn-tip', '<b>Como o mascote cresce</b><br>1. O <b>nível</b> do bicho (▲ por fragmentos ◆) — +15% em todo o seu poder, até o nível 5.<br>2. O <b>adestramento</b> por ouro — para todos os mascotes de uma vez: 🗡 dano físico (mordida, garras, agulhas) e ✦ mágico (fogo, veneno, faíscas, cura, escudo). +10% por grau.<br>3. Troque de mascote — o adestramento continua.');
        const ok = el('button', 'btn gold', 'Entendi'); ok.onpointerdown = e => { e.stopPropagation(); S.tut = 1; bus.emit('save'); render(true); }; tip.appendChild(ok); box.appendChild(tip);
      }
      for (const [k, T] of Object.entries(TRAIN)) {
        const c = PT.trainCan(k), r = row(T.icon, `${esc(T.name)} <span class="lv">${c.lvl}/${TRAIN_MAX}</span>`, `+${Math.round(c.lvl * TRAIN_STEP * 100)}% · ${esc(T.txt)}`, null, false, null, '');
        if (!c.max) btn(r, `▲ ${fmt(c.cost)} de ouro`, c.ok, () => PT.trainPet(k), ' up'); box.appendChild(r);
      }
    }
    box.appendChild(el('p', 'muted pn-shards', ICO.pile + '<small>Fragmentos do Abismo ◆ vêm de guardiões, chefes, campeões, baús, da Colheita e de missões semanais. Melhoria: +15% de poder do pet por nível.</small>'));
  } else if (T.id === 'board') {
    head('Quadro de Missões', 'Diárias · semanais · contratos longos');
    box.appendChild(el('div', 'pn-sub', 'Diárias'));
    for (const q of DQ.dailyQuests()) box.appendChild(row('☀', esc(q.title), q.claimed ? 'resgatado' : `${q.cur}/${q.n}`, q.done && !q.claimed ? 'Pegar' : null, q.done && !q.claimed, () => DQ.claimDaily(q.id), q.done && !q.claimed ? 'hot' : ''));
    box.appendChild(el('div', 'pn-sub', 'Semanais (maiores)'));
    for (const q of DQ.weeklyQuests()) box.appendChild(row('☾', esc(q.title), q.claimed ? 'resgatado' : `${q.cur}/${q.n}`, q.done && !q.claimed ? 'Pegar' : null, q.done && !q.claimed, () => DQ.claimWeekly(q.id), q.done && !q.claimed ? 'hot' : ''));
    box.appendChild(el('div', 'pn-sub', 'Contratos Longos (difíceis)'));
    for (const r of REPEATABLE) { const s = Q.repState(r); box.appendChild(row(s.done ? '✔' : '•', esc(r.title), `${s.cur}/${r.n}`, s.done ? 'Pegar' : null, s.done, () => Q.claimRep(r.id), s.done ? 'hot' : '')); }
  } else if (T.type === 'roomgate') {
    const R = ROOMS[T.room]; const c = CS.canUnlock(T.room);
    head(R.name, R.desc); bal();
    box.appendChild(el('div', 'pn-req', `<span class="${P.level >= R.lvl ? 'good' : 'bad'}">Nível ${R.lvl}+</span> · <span class="${P.gold >= R.gold ? 'good' : 'bad'}">${fmt(R.gold)} ouro</span>${R.shards ? ` · <span class="${(P.shards || 0) >= R.shards ? 'good' : 'bad'}">${R.shards} fragmentos</span>` : ''}`));
    const b = el('button', 'btn ' + (c.ok ? 'gold' : ''), c.ok ? 'Liberar Sala' : c.why); b.disabled = !c.ok; b.onclick = () => CS.unlock(T.room); box.appendChild(b);
    box.appendChild(el('p', 'muted', '<small>Fragmentos do Abismo caem ao acaso: de elites, Campeões, guardiões, chefes e baús.</small>'));
  } else if (T.type === 'castleguide') {
    head('Mapa da Cidadela', 'Toque em "Ir" para chegar à entrada da sala.'); bal();
    const rooms = G.zone.json.rooms;
    for (const [id, R] of Object.entries(ROOMS)) {
      const open = P.castle[id]; const gate = G.zone.inter.find(i => i.type === 'roomgate' && i.room === id);
      box.appendChild(row(open ? '✔' : '🔒', esc(R.name), open ? 'liberado' : `Nv. ${R.lvl} · ${fmt(R.gold)} ouro${R.shards ? ` · ${R.shards}◆` : ''}`, 'Ir', true, () => {
        const rr = rooms[id]; const tx = open ? rr[0] + rr[2] / 2 : gate.x, ty = open ? rr[1] + rr[3] / 2 + 1 : gate.y;
        const [x, y] = G.zone.map.nearestFree(open ? tx : (gate.x + (id === 'altar' ? 1.6 : id === 'trial' ? -1.6 : 0)), open ? ty : (gate.y + (id === 'treasury' || id === 'trophy' ? 1.6 : 0)), 0.35);
        G.player.x = x; G.player.y = y; G.cam.x = x; G.cam.y = y; bus.emit('sfx', 'portal');
      }));
    }
  } else if (T.type === 'nemwall') {
    const S = P.nemesis || { list: [], trophies: [] }, foes = S.list.filter(n => n.alive && (n.rank > 0 || n.defeats || n.fled));
    head('Muro de Inimigos', 'Nêmesis abatidos ficam pendurados como troféus (+dano e ouro para sempre). Os vivos aguardam vingança.');
    box.appendChild(el('div', 'pn-big', `Troféus: <b>${S.trophies.length}</b> · +${S.trophies.reduce((a, t) => a + t.bonus, 0).toFixed(1)}% de dano e ouro`));
    for (const t of S.trophies) box.appendChild(row('☠', esc(t.name), `${(REALMS[t.realm] || REALMS.forest).short} · grau ${t.rank} · +${t.bonus.toFixed(1)}%`, null, false, null));
    for (const n of foes) box.appendChild(row('⚔', esc(n.name + (n.title ? ', ' + n.title : '')), `vivo · grau ${n.rank}${n.stash ? ` · guarda ${n.stash} ouro` : ''}`, null, false, null, 'hot'));
    if (!S.trophies.length && !foes.length) box.appendChild(el('p', 'muted', '<small>Vazio por enquanto. Retome um forte nos Fiordes de Skjold ou na Floresta Antiga — o comandante vira seu nêmesis.</small>'));
  } else if (T.type === 'socket') {
    const cur = P.castle.decor && P.castle.decor[T.sid];
    head(cur ? DECOR[cur].name : 'Espaço de Decoração', cur ? `Bônus: ${DECOR[cur].txt}. Substituível (o antigo devolve metade do preço).` : 'Mobilie a cidadela: cada decoração dá um bônus permanente.'); bal();
    for (const [id, D] of Object.entries(DECOR)) { if (id === cur) continue; box.appendChild(row('✦', esc(D.name), D.txt, `${fmt(D.gold)}${D.shards ? ` · ${D.shards}◆` : ''}`, P.gold >= D.gold && (P.shards || 0) >= D.shards, () => CS.placeDecor(T.sid, id))); }
  } else if (T.room === 'altar') {
    const l = P.castle.altar, stored = CS.altarStored(), rate = CS.altarRate(), uc = CS.altarUpgCost();
    head(`Altar de Ouro · Nv. ${l}`, `${fmt(rate)} ouro/hora, acumula até 8 horas — mesmo offline.`); bal();
    box.appendChild(el('div', 'pn-big', `Acumulado: ${coin(stored)}`));
    const r1 = el('div', 'pn-row2');
    const a = el('button', 'btn gold', 'Pegar'); a.disabled = !stored; a.onclick = () => { CS.altarCollect(1); render(true); };
    const ad = el('button', 'btn ad', 'Pegar ×2'); ad.disabled = !stored; ad.onclick = () => watchRewarded('altar_x2', offerToken('altar_x2', String(P.castle.altarAt)), () => CS.altarCollect(2)).then(() => render(true));
    r1.append(a, ad); box.appendChild(r1);
    if (l < 10) box.appendChild(row('▲', `Melhorar altar para Nv. ${l + 1}`, `renda → ${fmt(Math.round((35 + 25 * (l + 1)) * (1 + P.level * 0.08)))}/hora`, `${fmt(uc.gold)} · ${uc.shards}◆`, P.gold >= uc.gold && P.shards >= uc.shards, () => CS.altarUpgrade()));
  } else if (T.room === 'trial') {
    const s = CS.seals(); const left = CS.nextIn(s, CS.SEAL_MS);
    head('Salão das Provas', 'Lute contra um guardião aqui mesmo na cidadela. Ligue o AUTO — o herói luta sozinho.'); bal();
    box.appendChild(el('div', 'pn-big', `Selos: <b>${s.n}/${CS.SEAL_MAX}</b>${left ? ` <small>· +1 em ${Math.ceil(left / 60000)} min</small>` : ''}`));
    const F = P.story.flags, seen = t => t.type === 'boss' ? !!F.bossKilled : !!(F.eliteKilled || F.bossKilled);   // испытания только против тех, кого герой уже победил в сюжете
    for (const t of CS.TRIALS) if (!seen(t)) { box.appendChild(row('?', 'Inimigo Desconhecido', t.type === 'boss' ? 'Libera após derrotar o Carrasco do Abismo' : 'Libera após derrotar o Guardião do Medalhão', null, false, () => { })); }
    else box.appendChild(row('⚔', esc(t.name), `Nv. do inimigo ${P.level + t.lvl} · requer Nv. ${t.req}`, P.level < t.req ? `Nv. ${t.req}` : 'Lutar', P.level >= t.req && s.n > 0 && !G.trial, () => startTrial(t)));
    box.appendChild(el('p', 'muted', `<small>Selos são a entrada das provas. Recarregam sozinhos: +1 a cada 3 horas (máximo ${CS.SEAL_MAX}). Ganhe mais um selo por anúncio uma vez por hora.</small>`));
    box.appendChild(adButton('+1 selo', 'seal', 60 * 60e3, () => { s.n++; bus.emit('save'); }, () => render(true)));
  } else if (T.room === 'treasury') {
    head('Tesouro do Abismo', 'Baú: um item Raro da sua classe, 7% de chance de Épico.'); bal();
    box.appendChild(row('▣', 'Baú do Abismo', `${CS.CHEST_SHARDS} fragmentos`, 'Abrir', (P.shards || 0) >= CS.CHEST_SHARDS, () => CS.openTreasury()));
  } else if (T.room === 'trophy') {
    const l = P.castle.trophy || 0, c = CS.trophyCost();
    head(`Salão dos Troféus · Nv. ${l}`, `Agora: +${l * 3}% de dano, +${l * 5}% de ouro.`); bal();
    if (l < 15) box.appendChild(row('♛', `Troféu Nv. ${l + 1}`, `+3% de dano, +5% de ouro`, `${fmt(c.gold)} · ${c.shards}◆`, P.gold >= c.gold && (P.shards || 0) >= c.shards, () => CS.trophyUpgrade()));
  }
  box.scrollTop = st;
}
function buyUpg(id) {
  const P = G.profile; P.upg = P.upg || {}; const l = P.upg[id] || 0, cost = upgCost(id, l);
  if (earlyLock('upg')) { bus.emit('sfx', 'deny'); return; }
  if (l >= UPGRADES[id].max || upgHave(P, id) < cost) { bus.emit('sfx', 'deny'); if (UPGRADES[id].shards && l < UPGRADES[id].max) bus.emit('toast', { text: `Requer ${cost}◆ fragmentos do Abismo`, sub: 'Fragmentos vêm dos chefes da Crônica, da Colheita, de missões semanais e da Trilha da Temporada', kind: 'warn' }); return; }
  { const q = Q.current(); if (q && q.id === 'hw_elvin') P.story.flags.upgBought = true; if (q && q.id === 'surv_elvin') P.story.flags.upgBought2 = true; }   // шаги обучения «Усилить героя у Элвина»
  if (UPGRADES[id].shards) P.shards -= cost; else P.gold -= cost; P.upg[id] = l + 1; G.stats = stats(P); bus.emit('statsChanged'); bus.emit('sfx', 'anvil'); bus.emit('save');
  bus.emit('float', { x: G.player.x, y: G.player.y, text: `${UPGRADES[id].name} ↑`, color: '#9fe38e', z: 2.4 });
}
