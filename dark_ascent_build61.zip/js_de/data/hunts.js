// «Охота» — тревожные слухи. Раз в 15 минут (реального времени) появляется новое задание:
// где-то объявилось чудовище — мини-босс, который водится ТОЛЬКО в охотах.
// Пока текущая охота не завершена (или не отменена), новая не появится — таймер стоит.
// Логика — game/hunts.js, таймер и карточка — ui/hud.js и окно «Задания» → «Охота».
// Как добавить новую охоту за 3 шага — docs/HUNTS.md.

export const HUNT_EVERY = 15 * 60e3;   // пауза между охотами (после завершения/отказа)
export const HUNT_FIRST = 2 * 60e3;    // первая охота — через 2 минуты после открытия системы

// ---- Места, где могут объявиться чудовища.
// zone: в какой зоне игры спавнится; at — точка в деревне; room — зал катакомб; depths — этаж Глубин.
export const PLACES = {
  // сборка 43: деревня — безопасная зона, охоты там больше не появляются (forest/graveyard остались только для старых сохранений)
  forest: { name: 'Rand des Schwarzen Waldes', zone: 'town', at: [34.5, 5.5], steps: ['Geh zum Nordostrand des Dorfes – zum Rand des Schwarzen Waldes.', 'Rote Pfeile am Boden führen dich zum Monster.'] },
  graveyard: { name: 'Alter Friedhof', zone: 'town', at: [31.5, 35.5], steps: ['Geh in den Südosten des Dorfes, zum alten Friedhof hinter dem Zaun.', 'Rote Pfeile am Boden führen dich zum Monster.'] },
  catacombs: { name: 'Katakomben', zone: 'catacombs', steps: ['Steig durch das Ordensportal (Nordwesten des Dorfes) in die Katakomben hinab.', 'Das Monster wartet in der Halle „{room}“ – folge den roten Pfeilen.'] },
  depths: { name: 'Tiefen der Katakomben', zone: 'depths', steps: ['Blaues Portal der Tiefen am Platz → wähle Ebene {floor} (mit ⚠ markiert).', 'Das Monster streift in der Mitte der Ebene umher – folge den roten Pfeilen.'] },
};
export const ROOM_NAMES = { entry: 'Vorhalle', ossuary: 'Ossarium', gallery: 'Galerie', cave: 'Höhle', cross: 'Kreuzung' };

// ---- Мини-боссы. Это обычные записи врагов (как в data/enemies.js) + поля охоты:
//  mini: true      — мини-босс охоты (полоса здоровья как у босса, красный круг под ногами)
//  atlas           — чей спрайт берём (пока схематично: перекрашенные существующие модели)
//  tint, scale     — CSS-фильтр цвета и размер, чтобы отличался от обычного монстра
//  base            — базовое поведение (melee/fast/archer/caster/beast/elite)
//  abil            — особые умения:
//     enrage: true                          — ярость на 50% здоровья (быстрее, бьёт чаще)
//     summon: { type, n, cd }               — призывает приспешников каждые cd секунд
//     nova:   { r, cd, elem, mult, c }      — круговой удар вокруг себя (с красным предупреждением)
//     volley: { n, spread, cd }             — веер снарядов (для стрелков и колдунов)
export const MINIBOSSES = {
  mb_forest_horror: {
    name: 'Waldschrecken', atlas: 'beast', tint: 'brightness(0.55) sepia(1) hue-rotate(60deg) saturate(2.2)', scale: 1.5,
    base: 'beast', hp: 260, dmg: [9, 14], speed: 3.0, range: 1.5, cd: 2.4, impact: 0.5, xp: 140, gold: [50, 80], armor: 12, radius: 0.62,
    abil: { enrage: true, nova: { r: 3.2, cd: 9, mult: 1.3, c: [120, 255, 90] } },
    desc: 'Riesige Bestie mit Moosfell. Springt aus der Ferne an (weich seitlich vom roten Streifen aus) und stampft den Boden um sich.',
  },
  mb_grave_weeper: {
    name: 'Friedhofsklagende', atlas: 'skel_mage', tint: 'grayscale(1) brightness(1.5) sepia(0.4) hue-rotate(170deg) saturate(2.5)', scale: 1.35,
    base: 'caster', hp: 200, dmg: [7, 11], elem: 'cold', speed: 2.2, range: 7.5, keep: 5, cd: 2.2, impact: 0.55, xp: 140, gold: [50, 80], armor: 6, radius: 0.45, proj: 'darkbolt',
    abil: { summon: { type: 'skel_warrior', n: 2, cd: 12 }, volley: { n: 3, spread: 0.35, cd: 7 } },
    desc: 'Geisterhexe. Teleportiert sich, wirft einen Fächer aus Eisgeschossen und erweckt Skelette aus Gräbern. Töte sie – dann zerfällt ihr Gefolge.',
  },
  mb_bone_reaper: {
    name: 'Knochenschnitter', atlas: 'elite', tint: 'sepia(1) hue-rotate(-40deg) saturate(3) brightness(0.8)', scale: 1.15,
    base: 'elite', hp: 320, dmg: [10, 15], speed: 2.7, range: 1.8, cd: 1.8, impact: 0.6, xp: 200, gold: [70, 110], armor: 18, radius: 0.55,
    abil: { enrage: true, nova: { r: 3.6, cd: 10, mult: 1.5, c: [255, 60, 40] } },
    desc: 'Wächter aus hundert Knochen. Schlägt im Kegel, wirbelt im Kreis und entlädt alle 10 Sekunden eine Blutwelle.',
  },
  mb_ghoul_mother: {
    name: 'Ghulmutter', atlas: 'ghoul', tint: 'sepia(1) hue-rotate(50deg) saturate(3) brightness(0.75)', scale: 1.7,
    base: 'fast', hp: 230, dmg: [6, 10], speed: 3.6, range: 1.3, cd: 1.1, impact: 0.5, xp: 160, gold: [60, 90], armor: 8, radius: 0.55,
    abil: { enrage: true, summon: { type: 'ghoul', n: 3, cd: 11 } },
    desc: 'Ein aufgedunsener Ghul, der Brut gebiert. Schnell, schlägt Haken. Bleib in Bewegung und triff zuerst die Mutter.',
  },
  mb_plague_archer: {
    name: 'Pestschütze', atlas: 'skel_archer', tint: 'sepia(1) hue-rotate(40deg) saturate(4) brightness(0.9)', scale: 1.35,
    base: 'archer', hp: 210, dmg: [6, 10], speed: 2.5, range: 9, keep: 6, cd: 1.7, impact: 0.66, xp: 170, gold: [60, 90], armor: 6, radius: 0.45, proj: 'arrow',
    abil: { volley: { n: 5, spread: 0.22, cd: 6 }, summon: { type: 'skel_archer', n: 2, cd: 16 } },
    desc: 'Hält Abstand und schießt einen Fächer aus 5 Pfeilen – weich per Sprint seitlich aus. Verkürze den Abstand.',
  },
  mb_eyeless_stalker: {
    name: 'Augenloser Jäger', atlas: 'beast', tint: 'sepia(1) hue-rotate(220deg) saturate(3) brightness(0.8)', scale: 1.35,
    base: 'beast', hp: 280, dmg: [10, 15], speed: 3.4, range: 1.4, cd: 1.6, impact: 0.5, xp: 190, gold: [70, 100], armor: 12, radius: 0.55,
    abil: { enrage: true, nova: { r: 2.8, cd: 7, mult: 1.2, elem: 'light', c: [190, 110, 255] } },
    desc: 'Blinde Bestie aus den Tiefen: springt öfter als üblich und schlägt Blitze um sich.',
  },
  mb_ash_lich: {
    name: 'Aschenlich', atlas: 'skel_mage', tint: 'sepia(1) hue-rotate(-20deg) saturate(5) brightness(1.1)', scale: 1.45,
    base: 'caster', hp: 240, dmg: [8, 12], elem: 'fire', speed: 2.0, range: 8, keep: 5.5, cd: 2.4, impact: 0.55, xp: 220, gold: [80, 120], armor: 6, radius: 0.48, proj: 'darkbolt',
    abil: { enrage: true, nova: { r: 3.0, cd: 9, mult: 1.4, elem: 'fire', c: [255, 140, 40] }, summon: { type: 'skel_mage', n: 1, cd: 14 } },
    desc: 'Feuerhexer. Feuerring um sich, ruft Knochenhexer herbei. Bleib fern, wenn unter ihm ein Kreis aufflammt.',
  },
};
// общие поля мини-боссов (их не нужно повторять в каждой записи)
for (const D of Object.values(MINIBOSSES)) Object.assign(D, { mini: true, elite: true, ai: 'mini', fps: { walk: 10, attack: 10 } });

// ---- Сами охоты (задания). Одна запись = одно возможное задание.
//  title    — заголовок тревоги
//  rumor    — слух, который игрок видит в карточке (атмосфера + подсказка)
//  boss     — ключ из MINIBOSSES
//  place    — ключ из PLACES; rooms — залы катакомб (для place: 'catacombs')
//  minLevel — с какого уровня героя может выпасть
//  trophy   — именная вещь-трофей (slot: weapon/head/chest/amulet), выдаётся вместе с золотом и опытом;
//             для оружия name можно задать по классам: { warrior, archer, mage }
//  elder    — что говорит староста Эдрик, когда герой сдаёт охоту (награда выдаётся у него)
export const HUNTS = [
  { id: 'forest_horror', title: 'Schreckliche Bestie in den Katakomben', place: 'catacombs', rooms: ['cave', 'gallery'], boss: 'mb_forest_horror', minLevel: 2,
    rumor: 'Holzfäller kehrten nicht vom Waldrand zurück, und Spuren so groß wie ein Wagenrad führen hinab in die Katakomben. Niemand weiß, was das für ein Wesen ist.',
    elder: 'Das also hat die Holzfäller verschleppt … Ein Reißzahn so groß wie ein Dolch! Morgen kehren die Holzfäller an den Waldrand zurück.',
    trophy: { slot: 'amulet', name: 'Zahn des Waldschreckens' } },
  { id: 'grave_weeper', title: 'Klagen im Ossarium', place: 'catacombs', rooms: ['ossuary', 'gallery'], boss: 'mb_grave_weeper', minLevel: 3,
    rumor: 'Jede Nacht dringt aus dem Ossarium der Katakomben unter dem Friedhof das Weinen einer Frau, und morgens sind zwei, drei Gräber aufgewühlt.',
    elder: 'Das Weinen ist verstummt? Dem Licht sei Dank. Der Wächter zündet die Laterne über den Gräbern wieder an.',
    trophy: { slot: 'head', name: 'Schleier der Klagenden' } },
  { id: 'bone_reaper', title: 'Schnitter in den Katakomben', place: 'catacombs', rooms: ['ossuary', 'gallery', 'cross'], boss: 'mb_bone_reaper', minLevel: 3,
    rumor: 'Aus den Katakomben dringt ein Schaben – als wetze jemand eine Sense an Knochen. Selbst Skelette fliehen von dort.',
    elder: 'Der Schnitter ist zerfallen? Dann verstummt das Schaben unter dem Dorf endlich. Nimm deinen Lohn, du hast ihn verdient.',
    trophy: { slot: 'weapon', name: { warrior: 'Sense des Schnitters', archer: 'Knochenbogen des Schnitters', mage: 'Stab des Schnitters' } } },
  { id: 'ghoul_mother', title: 'Nest in der Höhle', place: 'catacombs', rooms: ['cave', 'gallery'], boss: 'mb_ghoul_mother', minLevel: 3,
    rumor: 'In den Katakomben gibt es doppelt so viele Ghule. Irgendwo in der Höhle muss sich eine Mutter eingenistet haben.',
    elder: 'Die Mutter ist tot? Ohne sie hält die Brut keine Woche durch. Stillfurt schläft ruhiger.',
    trophy: { slot: 'chest', name: 'Haut der Mutter' } },
  { id: 'plague_archer', title: 'Pestschütze in den Tiefen', place: 'depths', boss: 'mb_plague_archer', minLevel: 6,
    rumor: 'Ordensspäher kehrten mit Giftpfeilen in den Schilden zurück. Der Schütze hat sich auf einer Ebene der Tiefen verschanzt.',
    elder: 'Der Pestschütze schießt nie wieder. Die Ordensspäher lassen dich grüßen.',
    trophy: { slot: 'weapon', name: { warrior: 'Pestklinge', archer: 'Pestsehne', mage: 'Peststab' } } },
  { id: 'eyeless_stalker', title: 'Blindes Wesen auf der Ebene', place: 'depths', boss: 'mb_eyeless_stalker', minLevel: 6,
    rumor: 'In den Tiefen jagt etwas die Untoten. Es sieht nichts – aber hört jeden Schritt.',
    elder: 'Der blinde Jäger wurde selbst zur Beute. Diese Perle aus seiner Augenhöhle trägst du besser um den Hals – man sagt, sie hört Gefahr.',
    trophy: { slot: 'amulet', name: 'Perlenauge' } },
  { id: 'ash_lich', title: 'Der Aschenlich erwacht', place: 'depths', boss: 'mb_ash_lich', minLevel: 8,
    rumor: 'Kerzen in der Gruft erlöschen von selbst, und aus den Tiefen riecht es nach Brand. Der alte Lich ist zurück.',
    elder: 'Der Lich ist besiegt – die Kerzen der Gruft brennen wieder ruhig. Nicht zum ersten Mal hast du uns gerettet.',
    trophy: { slot: 'head', name: 'Aschenkrone' } },
];

// Награда за охоту (масштабируется уровнем чудовища)
export const huntReward = lvl => ({ gold: 60 + lvl * 25, xp: 80 + lvl * 30, shards: 1 + Math.floor(lvl / 6), potions: 1 });
