// Entry point: boot sequence, title screen, main loop.
import { G, bus } from './game/ctx.js';
import { loadGroup, getAtlas } from './core/assets.js';
import { initInput, initMouse, input, releaseInput } from './core/input.js';
import { initCamZoom } from './core/camzoom.js';
import { initAudio, sfx, startMusic, setVolumes, setPaused, deviceVolumes } from './core/audio.js';
import './core/nature.js';   // звуки природы и голоса мобов
import { initRenderer, render, resize, startPreload } from './render/index.js';
import { newProfile, loadSlots, mergeCloud } from './game/save.js';
import { stats } from './game/stats.js';
import { initQuests } from './game/quests.js';
import { initHunts } from './game/hunts.js';
import { loadZone, update, saveNow } from './game/game.js';
import { initHUD, updateHUD } from './ui/hud.js';
import { initPanel } from './ui/panel.js';
import { initTutorial, intro, unlockAll } from './ui/tutorial.js';
import { cinema, introShots, portalShots } from './ui/cinema.js';
import * as CS from './game/castle.js';
import { initPlatform, platform, gameplay } from './platform/platform.js';
import { restorePurchases } from './platform/monetize.js';
import { initAnalytics, wireAnalytics, track } from './platform/analytics.js';
import { dozorPending, initDozor } from './game/daily.js';
import { showDozor } from './ui/windows.js';
import { $, el, esc } from './core/util.js';
import { CLASSES } from './data/items.js';
import { iconURL } from './ui/icons.js';
import { initFullscreen } from './ui/fullscreen.js';
import { qa, initQA } from './core/qa.js';

export const BUILD = '2026-10-11 · Build 61';   // видно на титульном экране и в настройках: так проверяют, что загрузилась свежая версия
const CORE = ['props', 'icons'];
// hero sheets are big (HD): load only the chosen class
export const CLASS_ATLAS = { warrior: ['hero_body', 'hero_sword', 'hero_axe', 'hero_greatsword', 'hero_shield'], archer: ['hero_archer_body', 'hero_archer_bow'], mage: ['hero_mage_body', 'hero_mage_staff'] };
const MONSTERS = ['skel_warrior', 'skel_archer', 'skel_mage', 'ghoul', 'beast', 'elite', 'boss'];

async function boot() {
  initFullscreen();
  await initRenderer($('game'));
  initAudio(); bus.on('sfx', sfx); bus.on('audioPause', p => setPaused(p, 'ad'));   // реклама; своя причина тишины у платформы и скрытой вкладки (audio.js)
  const bar = $('loadbar').firstElementChild, txt = $('loadtxt');
  // правки мамы (М14): на Android загрузка долгая и казалось, что всё зависло — к тексту добавлены проценты, полоса «переливается» (css #loadbar)
  const prog = (f, t) => { bar.style.width = Math.round(f * 100) + '%'; txt.textContent = t + (f < 1 ? ` ${Math.round(f * 100)}%` : ''); if (window.__bootStep) window.__bootStep(); };   // П42: сторож загрузки в index.html
  prog(0.05, 'Plattform wird verbunden …');
  await initPlatform();
  prog(0.1, 'Lade Held und Welt …');
  await loadGroup(CORE, f => prog(0.1 + f * 0.6, 'Lade Held und Welt …'));
  $('titleHero').style.backgroundImage = 'url(assets/sprites/portrait.png)';
  // save: local, or cloud if newer (Yandex)
  // сборка 44: три сохранения — по одному на класс; облако (Яндекс) — если там новее
  let saves = loadSlots();
  if (platform.name !== 'demo') { try { const c = await platform.p.cloudLoad(); if (!(c && c.error)) { saves = mergeCloud(saves, c); platform.cloudOK = true; } } catch { } }   // облако не ответило — писать в него нельзя, пока не прочитаем (game.js, cloudRetry)
  prog(1, 'Fertig');
  platform.p.ready();
  initAnalytics();
  // сборка 51: монстры, модели героев и зверей качаются после Game Ready, пока игрок на титульном экране
  const mons = loadGroup(MONSTERS).catch(e => console.warn(e));
  startPreload(saves.last);
  $('loadbar').classList.add('hidden'); $('loadtxt').classList.add('hidden');
  const btns = $('titleBtns'); btns.classList.remove('hidden'); $('title').classList.add('ready'); if (window.__bootOk) window.__bootOk();   // сборка 58: фон загрузки (лестница) → титульный (Тихий Брод)
  const start = async (p) => {
    await loadGroup(CLASS_ATLAS[p.cls || 'warrior']).catch(() => { });
    const dv = deviceVolumes(); if (dv) { p.settings.sfx = dv.sfx; p.settings.music = dv.music; }   // громкость — настройка устройства (одна для всех героев)
    G.profile = p; G.stats = stats(p); wireAnalytics(); setVolumes(p.settings.sfx, p.settings.music); resize();
    btns.innerHTML = '<div class="muted">Betrete die Welt …</div>';
    initQuests(); initHunts(); initHUD(); initPanel(); CS.C(); initTutorial();
    await mons;
    const fresh = !p.tutorial.prologue && p.story.stage === 0 && !p.xp && p.level === 1;
    track(fresh ? 'start_new' : 'start_continue', { cls: p.cls });
    if (!fresh && !p.tutorial.un) unlockAll();   // старые сохранения (до обучения кнопками): все кнопки боя открыты. Сборка 59: раньше — при любой перезагрузке, и посреди обучения разом появлялись все кнопки
    const crypt = !fresh && !p.tutorial.prologue;   // сборка 59: перезагрузка посреди пролога — снова в склеп, а не в деревню без пролога
    await loadZone(crypt ? 'depths' : 'town', crypt ? { floor: 0 } : undefined);
    $('title').remove(); startMusic('town');
    bus.on('zoneEntered', z => startMusic(z));
    bus.on('music', z => startMusic(z || G.zoneId));   // сборка 60: бой Летописи — своя тема, потом обратно музыка зоны
    restorePurchases().catch(() => { });
    const dz = dozorPending(); if (dz) setTimeout(() => showDozor(dz), 900); else { initDozor(); G.dozorChecked = true; }
    if (p.simplified && p.simplified.upg) { bus.emit('toast', { text: 'Upgrades vereinfacht', sub: `Überzählige Upgrades erstattet: ${p.simplified.gold} G`, kind: 'good' }); delete p.simplified; }
    if (p.simplified) { bus.emit('toast', { text: 'Ausrüstung auf 4 Items vereinfacht', sub: `Überzählige Items (${p.simplified.n}) für ${p.simplified.gold} G verkauft`, kind: 'good' }); delete p.simplified; }
    if (p.fromBak) bus.emit('toast', { text: 'Spielstand konnte nicht gelesen werden', sub: 'Die vorherige Kopie wurde geladen', kind: 'warn' });
    if (p.pendingCarry > 0) { const n = p.pendingCarry; p.gold += n; p.stats.gold += n; p.pendingCarry = 0; bus.emit('toast', { text: `Beute der Expedition gesichert: +${n} Gold`, sub: 'Das Spiel wurde mitten in einer Expedition geschlossen', kind: 'good' }); }
    if (p.legacyKey) { bus.emit('toast', { text: 'Spielstand aus Version 1.x übernommen', sub: 'Stufe, Gold und Werte bleiben erhalten', kind: 'good' }); delete p.legacyKey; }
    requestAnimationFrame(loop);
    // новая игра: сначала облёт деревни («вау» и загадка), потом склеп пробуждения
    if (fresh) {
      if (p.tutorial.on === undefined) p.tutorial.on = true;   // сборка 49: без вопроса «Показать подсказки?» — сразу в игру; выключить можно в «Справке»
      await cinema(introShots());
      await loadZone('depths', { floor: 0 });
      intro();
    }
  };
  const S = saves.slots, cname = c => CLASSES[c] ? CLASSES[c].name : c;
  // новая игра: класс, у которого уже есть сохранение, — только после «Перезаписать?»
  const newGame = () => { sfx('click'); pickClass(btns, cls => start(newProfile(cls)), S, cls => confirm(`Spielstand von Held „${cname(cls)}“ (St. ${S[cls].level}) überschreiben? Sein Fortschritt geht verloren, andere Helden bleiben.`)); };
  if (saves.last) {
    const lp = S[saves.last];
    const c = el('button', 'btn gold', `Weiter: ${esc(cname(saves.last))}, St. ${lp.level}`); c.onclick = () => { sfx('click'); start(lp); };
    btns.append(c);
    for (const cls of Object.keys(S)) if (cls !== saves.last) { const o = el('button', 'btn', `${esc(cname(cls))}, St. ${S[cls].level}`); o.onclick = () => { sfx('click'); start(S[cls]); }; btns.append(o); }
    const n = el('button', 'btn', 'Neues Spiel'); n.onclick = newGame; btns.append(n);
  } else {
    const n = el('button', 'btn gold', 'Spiel starten'); n.onclick = newGame; btns.append(n);
  }
  btns.appendChild(el('div', 'muted', `<small>Version: ${BUILD}</small>`));
  btns.appendChild(el('div', 'muted', '<small>Handy: Zieh den Finger irgendwo über den Bildschirm – der Held läuft; tippe auf einen Feind oder eine Truhe – er rennt hin; Sprint und Tränke rechts · PC: WASD, Shift – Sprint</small>'));
  if (G.webglFail) btns.appendChild(el('div', 'muted', '<small>' + esc('3D-Grafik ist auf diesem Gerät nicht verfügbar, das Spiel läuft in 2D. Grund: ') + esc(G.webglFail) + '</small>'));   // П42
}

function pickClass(box, cb, saved = {}, askOverwrite = () => true) {
  box.innerHTML = '<div class="goldc" style="font:600 18px Georgia">Wähle einen Helden</div>';
  // правки мамы (М14): касание «Начать игру» / «Новая игра» на телефоне доходило и до карточки героя, появившейся под пальцем, — выбор пропускался.
  // Карточка принимает нажатие, только если палец опустился на неё саму (клавиатура — как раньше)
  const row = el('div', 'classes');
  for (const [id, C] of Object.entries(CLASSES)) {
    const has = saved[id];
    const c = el('button', 'class-card', `<picture><source media="(min-width:900px) and (min-height:600px)" srcset="assets/art/gpt/heroes/${id}.png"><img class="pt" src="assets/sprites/${id === 'warrior' ? 'portrait' : 'portrait_' + id}.png" alt="" onerror="this.src='${iconURL(C.icon)}'"></picture><b>${esc(C.name)}</b><span>${esc(C.desc)}</span>${has ? `<em class="cc-save">Spielstand · St. ${has.level}</em>` : ''}`);
    c.onpointerdown = () => { c._down = true; };
    c.onclick = e => { if (box._picked || (e.detail && !c._down)) return; if (has && !askOverwrite(id)) return; box._picked = true; sfx('click'); cb(id); }; row.appendChild(c);
  }
  box.appendChild(row);
}
let last = performance.now(), fpsAcc = 0, fpsN = 0;
function loop(now) {
  const dt = Math.min(0.05, (now - last) / 1000); last = now;
  fpsAcc += dt; fpsN++; if (fpsAcc > 1) { G.fps = Math.round(fpsN / fpsAcc); fpsAcc = 0; fpsN = 0; }
  if (!qa.hold) try { if (!document.hidden && !G.awayPause) update(dt); render(); updateHUD(dt); } catch (e) { console.error(e); }   // qa.hold — время идёт через window.advanceTime (автотесты)
  gameplay(!G.paused && !G.awayPause && !document.hidden && !(G.player && G.player.dead));   // меню, окна, пауза, смерть — для Яндекса игра стоит
  requestAnimationFrame(loop);
}
// persist on tab hide / close (mobile browsers kill background tabs)
// пауза и тишина при сворачивании вкладки / событиях платформы (требование модерации Яндекс Игр)
// Правки 2 (П12): свернули браузер или ушли на другую вкладку — везде (деревня, катакомбы, Глубины, Жатва, Летопись) игра стоит,
// а по возвращении ждёт «Продолжить», чтобы мобы не били, пока игрок снова берёт телефон в руки
const away = new Set();   // 'hidden' — вкладка скрыта, 'platform' — пауза от Яндекса/VK
let pauseOv = null;
function showPauseOv() {
  if (pauseOv || !G.profile) return;
  pauseOv = el('div', 'pause-ov'); pauseOv.appendChild(el('div', 'pause-box')).appendChild(el('div', 'goldc pause-t', 'Pause'));
  // пока стояла пауза, могло открыться окно (предложение, награда) — тогда паузу держит оно, «Продолжить» её не снимает
  const go = el('button', 'btn gold', 'Weiter'); go.onclick = () => { pauseOv.remove(); pauseOv = null; if (away.size) return; G.awayPause = false; if (G.hidePaused && !G.modalOpen) G.paused = false; G.hidePaused = false; bus.emit('sfx', 'click'); };
  pauseOv.firstChild.appendChild(go); document.body.appendChild(pauseOv);
}
const setAway = (why, on) => {
  if (!G.profile) return;
  const was = away.size > 0; if (on) away.add(why); else away.delete(why); if (why === 'platform') setPaused(on, 'platform');   // скрытую вкладку глушит сам audio.js
  if (on && !was) { if (!G.awayPause) { G.hidePaused = !G.paused; if (G.hidePaused) G.paused = true; } G.awayPause = true; releaseInput(); saveNow(true); gameplay(false); }
  else if (!on && was && !away.size) showPauseOv();   // GameplayAPI.start — из цикла (loop), когда игрок нажмёт «Продолжить»
};
document.addEventListener('visibilitychange', () => setAway('hidden', document.hidden));
bus.on('platformPause', on => setAway('platform', on));
addEventListener('pagehide', () => { releaseInput(); if (G.profile) saveNow(true); });
addEventListener('contextmenu', e => e.preventDefault());
// iOS Safari: block pinch/double-tap zoom and reset any zoom left over after rotation
// двойной тап / щипок на телефоне не должен приближать страницу (экран «уезжал», вернуть масштаб было нельзя)
let lastTap = 0;
document.addEventListener('touchend', e => { const n = Date.now(); if (n - lastTap < 350 && e.target && e.target.closest && e.target.closest('#game,#game3d,#joyZone')) e.preventDefault(); lastTap = n; }, { passive: false });
document.addEventListener('touchmove', e => { if (e.touches && e.touches.length > 1) e.preventDefault(); }, { passive: false });
document.addEventListener('dblclick', e => e.preventDefault());
document.addEventListener('wheel', e => { if (e.ctrlKey) e.preventDefault(); }, { passive: false });
for (const ev of ['gesturestart', 'gesturechange', 'gestureend']) document.addEventListener(ev, e => e.preventDefault(), { passive: false });
const vpMeta = document.querySelector('meta[name=viewport]'); const VP = vpMeta.content;
function resetZoom() {
  vpMeta.content = VP + ', minimum-scale=1'; setTimeout(() => { vpMeta.content = VP; window.scrollTo(0, 0); }, 60);
}
addEventListener('orientationchange', () => { resetZoom(); setTimeout(resetZoom, 400); });
if (window.visualViewport) visualViewport.addEventListener('resize', () => { if (Math.abs(visualViewport.scale - 1) > 0.01) resetZoom(); });
initInput($('joyZone'), $('joyBase'), $('joyKnob')); initMouse($('game')); initCamZoom($('game'));
input.anchor = () => G.player ? G.cam.toScreen(G.player.x, G.player.y) : [innerWidth / 2, innerHeight / 2];
window.__G = G;   // for automated QA
initQA({ update, render, updateHUD });   // window.advanceTime / render_game_to_text — js/core/qa.js
window.__BUILD = BUILD;
if (window.__bootStep) window.__bootStep();
boot().catch(e => { console.error(e); $('loadtxt').textContent = 'Ladefehler: ' + e.message; if (window.__bootFail) window.__bootFail('Ladefehler: ' + e.message, true); });
