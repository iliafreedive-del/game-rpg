// HUD: bars, tracker, gold, buffs, boss bar, toasts, touch controls, minimap.
import { streak } from '../game/streak.js';
import { earlyLock } from '../game/progress.js';
import { G, bus, inCombat } from '../game/ctx.js';
import { $, el, esc, fmt } from '../core/util.js';
import { input, resetBase, mouse } from '../core/input.js';
import { xpToNext } from '../game/stats.js';
import { SKILLS } from '../data/skills.js';
import { WEAPONS, RARITY } from '../data/items.js';
import { CHAPTER, STORY, chapterOf } from '../data/quests.js';
import * as Q from '../game/quests.js';
import * as C from '../game/combat.js';
import { interact, usePotion, useScroll, scrollZone } from '../game/game.js';
import { drawIcon, skillIcon, iconURL } from './icons.js';
import { ART, withArt } from './art.js';
import { iconOf } from '../game/items.js';
import { dailyStatus, chestStatus, blessLeft, blessTick, autoOK, autoFree, autoLeft, autoAd, AUTO_MIN } from '../platform/monetize.js';
import { seasonClaimable, nextGoalLine } from '../game/season.js';
import { dailyReady } from '../game/daily.js';
import { BOONS } from '../data/boons.js';
import { openWindow, pumpRewards } from './windows.js';
import * as CS from '../game/castle.js';
import { hwReady } from './herospath.js';
import './energy.js';
const skillCanvasInto = (cv, id) => skillIcon(cv, id, false);   // сборка 58: рисуем прямо в кнопку — нарисованная иконка догружается в неё же
import * as SV from '../game/survival.js';
import * as HU from '../game/hunts.js';
import { unlocked as tutUn, hideHand, pointAt } from './tutorial.js';

let lastHud = 0, trackOpenUntil = 0;
export function initHUD() {
  $('ui').classList.remove('hidden'); requestAnimationFrame(resetBase);
  // menu
  for (const b of document.querySelectorAll('[data-open]')) b.onclick = () => { bus.emit('sfx', 'click'); openWindow(b.dataset.open); };
  $('portrait').onclick = () => openWindow('menu');   // сборка 44: «Герой», «Меню» и остальное — по нажатию на портрет
  $('huntBox').onclick = () => { bus.emit('sfx', 'click'); openWindow('journal', { tab: 'hunt' }); };
  bus.on('huntNew', () => { const b = $('huntBox'); b.classList.remove('flash'); void b.offsetWidth; b.classList.add('flash'); });
  // «Веди меня»: герой сам бежит к цели задания (для тех, кто потерялся, и для самых маленьких)
  $('btnLead').onclick = () => { bus.emit('sfx', 'click'); G.lead = !G.lead; $('btnLead').classList.toggle('on', G.lead); toast({ text: G.lead ? 'Führ mich: an' : 'Führ mich: aus', sub: G.lead ? 'Der Held folgt den Pfeilen' : '', kind: 'info' }); };
  bus.on('zoneEntered', () => { G.lead = false; $('btnLead').classList.remove('on'); });
  $('tracker').onclick = () => { trackOpenUntil = $('tracker').classList.contains('open') ? 0 : G.time + 8; lastHud = 0; };
  // combat buttons (pointer events → instant response, supports multi-touch with joystick)
  const hold = (id, on, off) => { const b = $(id); b.addEventListener('pointerdown', e => { e.preventDefault(); b.classList.add('on'); on(); }); const up = () => { b.classList.remove('on'); off && off(); }; b.addEventListener('pointerup', up); b.addEventListener('pointercancel', up); b.addEventListener('pointerleave', up); };
  // the big button: basic attack, or the skill the player put on it (falls back to attack while on cooldown)
  hold('btnAtk', () => { const bs = G.profile.bigSkill; if (bs && G.profile.skills[bs] && C.skillUsable(bs).ok) C.castSkill(bs); input.attackHeld = true; }, () => { input.attackHeld = false; });
  for (let i = 0; i < 4; i++) hold('sk' + i, () => { const id = G.profile.slots[i]; if (id) C.castSkill(id); else openWindow('skills'); });
  hold('btnDodge', () => G.player.dodge(input.wx, input.wy));
  // П62: нажал пустую банку — окно: купить у Миры или 2 зелья за рекламу (а не только «Нет зелий»)
  const pot = k => { if (G.profile.potions[k] > 0 || G.player.dead) usePotion(k); else openWindow('potEmpty', k); };
  hold('potHP', () => pot('hp')); hold('potMP', () => pot('mp'));
  hold('btnAct', () => { if (G.focus) interact(G.focus); });
  $('btnScroll').onclick = () => useScroll();
  // правки 2 (П51): напоминание о рывке в бою с большим боссом (combat.js enemyTelegraph) — кнопка мигает, над героем подсказка не чаще раза в 4 с
  { let hT = 0, fT = -9; bus.on('dodgeHint', () => { const b = $('btnDodge'); if (!b || G.player.cds.dodge > 0.3) return; b.classList.add('hint'); clearTimeout(hT); hT = setTimeout(() => b.classList.remove('hint'), 1100);
    if (G.time - fT > 4) { fT = G.time; bus.emit('float', { x: G.player.x, y: G.player.y, text: matchMedia('(pointer:coarse)').matches ? 'Ausweichen!' : 'Ausweichen — Shift!', color: '#ffe08a', z: 2.6, life: 1.1 }); } }); }
  const ab = $('btnAuto'); ab.removeAttribute('data-open'); ab.onclick = null; ab.onpointerdown = async e => { e.preventDefault(); e.stopPropagation();
    if (!G.auto && !autoOK()) { if (!await autoAd()) return; toast({ text: `Autokampf für ${AUTO_MIN} Minuten`, sub: 'Der Held kämpft, trinkt Tränke und geht zum Ziel', kind: 'good' }); }   // сборка 47: автобой за рекламу
    G.auto = !G.auto; ab.classList.toggle('on', G.auto); toast({ text: G.auto ? 'Autokampf an' : 'Autokampf aus', sub: G.auto ? (autoFree() ? 'Der Held kämpft, trinkt Tränke und geht zum Ziel' : `Noch ${Math.ceil(autoLeft() / 60000)} min`) : '', kind: 'info' }); };
  // keyboard shortcuts
  input.onKey = (code) => {
    if (G.modalOpen) { if (code === 'Escape') bus.emit('closeModal'); return; }
    const map = { KeyI: 'inventory', KeyB: 'inventory', KeyC: 'character', KeyK: 'skills', KeyJ: 'journal', KeyM: 'map', Escape: 'settings' };
    if (map[code]) return openWindow(map[code]);
    if (code.startsWith('Digit')) { const i = +code.slice(5) - 1; if (i >= 0 && i < 4 && G.profile.slots[i]) { const recent = performance.now() - mouse.t < 4000; C.castSkill(G.profile.slots[i], recent ? (([x, y]) => ({ x, y }))(G.cam.toWorld(mouse.x, mouse.y + 20)) : undefined); } }
    if (code === 'KeyQ') usePotion('hp'); if (code === 'KeyE') usePotion('mp');
    if (code === 'ShiftLeft' || code === 'ShiftRight') G.player.dodge(input.wx, input.wy);
    if (code === 'KeyF' || code === 'Enter') { if (G.focus) interact(G.focus); }
    if (code === 'KeyT') useScroll();
  };
  drawIcon($('potHP').querySelector('canvas'), 'potion_hp'); drawIcon($('potMP').querySelector('canvas'), 'potion_mp');
  withArt(ART.item('scroll'), im => { const b = $('btnScroll'), sv = b.querySelector('svg'); if (sv) sv.replaceWith(Object.assign(im.cloneNode(), { className: 'art-scroll', alt: '' })); });   // сборка 58: нарисованный свиток вместо контура
  const cl = G.profile.cls || 'warrior'; $('portrait').style.backgroundImage = `url(assets/sprites/${cl === 'warrior' ? 'portrait' : 'portrait_' + cl}.png)`;
  bus.on('hud', () => { lastHud = 0; });
  bus.on('skillsChanged', refreshSkills);
  bus.on('skillSlotted', ({ id, i }) => { toast({ text: `Neue Fähigkeit: ${SKILLS[id].name}`, sub: `Knopf ${i + 1} unten rechts`, kind: 'good' }); const b = $('sk' + i); b.classList.add('flash'); setTimeout(() => b.classList.remove('flash'), 4000); }); bus.on('equipChanged', refreshWeapon); bus.on('statsChanged', refreshSkills); bus.on('statsChanged', refreshWeapon);
  bus.on('focus', it => { const b = $('btnAct'); if (it) { b.textContent = it.label; b.classList.remove('hidden'); } else b.classList.add('hidden'); });
  bus.on('toast', toast);
  bus.on('bagFull', () => toast({ text: 'Tasche voll!', sub: 'Verkauf Überflüssiges oder kauf eine größere Tasche – tippe, um die Tasche zu öffnen', kind: 'bad', onClick: () => openWindow('inventory') }));   // сборка 38
  bus.on('itemPicked', it => toast({ text: 'Gefunden: ' + it.name, sub: RARITY[it.rarity].name + ' · tippe zum Vergleichen', kind: 'item', color: RARITY[it.rarity].color, onClick: () => openWindow('inventory', { select: it.id }) }));
  // сборка 59: новое задание объявляется один раз. Окно награды уже пишет «Следующее задание» — тогда без тоста; подсказка-строка обучения убрана
  bus.on('questNew', q => { setTimeout(() => { if (!document.querySelector('.rw-bg')) toast({ text: 'Neue Quest', sub: q.title + (G.zoneId === 'town' && (q.chapter || 1) === 1 ? ' — folge dem goldenen Pfeil' : ''), kind: 'quest' }); }, 350); trackOpenUntil = G.time + 7; });
  bus.on('zoneEntered', () => { trackOpenUntil = G.time + 6; });
  bus.on('levelUp', l => { if (G.hwOpen) return;   // сборка 60: в Летописи уровень празднует своё окно итога (herospath.js)
    const e = $('levelUp'); e.textContent = `Stufe ${l}!`; e.classList.remove('show'); void e.offsetWidth; e.classList.add('show'); toast({ text: '+5 Attribute · +1 Fertigkeit', sub: 'Verteile sie bei Mentor Elvin im Dorf', kind: 'good' }); });   // сборка 59: «Уровень N!» уже крупно по центру — без повтора
  bus.on('bossStart', e => { G.boss = e; });
  refreshSkills(); refreshWeapon();
}
function refreshWeapon() {
  const w = G.profile.gear.weapon, bs = G.profile.bigSkill, b = $('btnAtk'); if (bs && G.profile.skills[bs]) skillCanvasInto(b.querySelector('canvas'), bs); else drawIcon(b.querySelector('canvas'), w ? iconOf(w) : 'sword');
  // П31: герой бьёт сам, когда враг рядом, — отдельная кнопка удара не нужна. Большая кнопка видна, только если на неё поставлен навык (★),
  // и тогда на ней видна перезарядка, как на малых. Пробел на ПК по-прежнему бьёт
  const on = !!(bs && G.profile.skills[bs]); $('ui').classList.toggle('noatk', !on);
  if (on && !b.querySelector('.cd')) b.appendChild(el('div', 'cd'));
}
const waveSt = {};
function potWave(id, low) {
  const st = waveSt[id] || (waveSt[id] = { low: false, at: 0 }), was = st.low; st.low = low;
  if (!low || was || performance.now() < st.at) return;
  const b = $(id); if (!b || !b.offsetParent) return; st.at = performance.now() + 15000;
  for (let i = 0; i < 3; i++) { const r = el('i', 'potwave ' + id); r.style.cssText = `left:${b.offsetLeft}px;top:${b.offsetTop}px;width:${b.offsetWidth}px;height:${b.offsetHeight}px;animation-delay:${i * 0.45}s`; b.parentNode.appendChild(r); setTimeout(() => r.remove(), 2000 + i * 450); }
}
function refreshSkills() {
  for (let i = 0; i < 4; i++) {
    const b = $('sk' + i), id = G.profile.slots[i]; b.innerHTML = '';
    if (!id || !G.profile.skills[id]) { b.classList.add('empty'); b.innerHTML = '<span style="font:bold 20px serif;color:#8a7a5a">+</span>'; b.title = 'Leerer Platz – Fähigkeiten öffnen'; continue; }
    b.classList.remove('empty'); b.title = SKILLS[id].name;
    const c = document.createElement('canvas'); c.width = c.height = 72; skillIcon(c, id); b.appendChild(c);
    b.appendChild(el('div', 'cd')); b.appendChild(el('span', 'mana', SKILLS[id].mana));
  }
}

// ---------------------------------------------------------------- toasts (bounded, auto-removed)
export function toast(t) {
  const box = $('toasts');
  // сборка 59: тот же тост уже на экране — не дублировать
  for (const c of box.children) if (c.dataset.k === t.text + '|' + (t.sub || '')) return c;
  while (box.children.length >= 4) box.firstChild.remove();
  // сборка 50: на вертикальном телефоне — под правой колонкой HUD (задание, «Веди меня»), а не поверх неё (iPhone SE, Android 360)
  { const r = $('hudR'), port = innerHeight > innerWidth && innerWidth <= 760; box.style.top = port && r && r.offsetParent ? Math.min(innerHeight * 0.5, r.getBoundingClientRect().bottom + 8) + 'px' : '';
    // С2: в горизонтали — в просвет между левой колонкой (полосы, «Сезон») и правой (золото, трекер), а не поверх них
    box.style.left = box.style.width = '';
    if (!port && innerWidth > innerHeight && r && r.offsetParent) {
      const L = $('hudL').getBoundingClientRect().right, Rl = Math.min(...[...r.children].filter(c => c.offsetParent && c.offsetWidth).map(c => c.getBoundingClientRect().left), innerWidth);
      if (Rl - L >= 220) { box.style.left = (L + Rl) / 2 + 'px'; box.style.width = Math.min(420, Rl - L - 16) + 'px'; }
      else box.style.top = Math.min(innerHeight * 0.5, r.getBoundingClientRect().bottom + 8) + 'px';
    }
    const sv = $('survHud'); if (sv && sv.offsetParent && G.zoneId === 'survival') box.style.top = Math.min(innerHeight * 0.5, Math.max(r && r.offsetParent ? r.getBoundingClientRect().bottom : 0, sv.getBoundingClientRect().bottom) + 8) + 'px'; }   // сборка 59: в Жатве — под её табло, не под ним
  const d = el('div', 'toast ' + (t.kind || ''), `<div class="a" ${t.color ? `style="color:${t.color}"` : ''}>${esc(t.text)}</div>${t.sub ? `<div class="b">${esc(t.sub)}</div>` : ''}`);
  d.dataset.k = t.text + '|' + (t.sub || '');
  if (t.onClick) d.onclick = () => { t.onClick(); d.remove(); };
  box.appendChild(d);
  setTimeout(() => d.classList.add('out'), t.kind === 'quest' ? 3600 : 2600); setTimeout(() => d.remove(), t.kind === 'quest' ? 4100 : 3100);
}

// ---------------------------------------------------------------- per-frame HUD update (throttled DOM writes)
let tick = 0;
export function updateHUD(dt) {
  const P = G.profile, pl = G.player, S = G.stats; if (!pl || !S) return;
  tick += dt; pumpRewards();
  setBar('hpBar', pl.hp / S.maxHP, `${Math.ceil(pl.hp)} / ${S.maxHP}`);
  setBar('mpBar', pl.mp / S.maxMP, `${Math.floor(pl.mp)} / ${S.maxMP}`);
  // skill cooldowns / availability
  for (let i = 0; i < 4; i++) {
    const id = P.slots[i]; if (!id) continue; const b = $('sk' + i); const cd = b.querySelector('.cd'); if (!cd) continue;
    const sk = SKILLS[id]; const left = pl.cds[id] || 0; cd.style.setProperty('--p', (left > 0 ? left / sk.cd * 100 : 0) + '%');
    const u = C.skillUsable(id); b.classList.toggle('off', !u.ok && u.why !== 'Abklingzeit');
  }
  { const bs = P.bigSkill, cd = bs && P.skills[bs] && $('btnAtk').querySelector('.cd'); if (cd) { const left = pl.cds[bs] || 0; cd.style.setProperty('--p', (left > 0 ? left / SKILLS[bs].cd * 100 : 0) + '%'); } }
  // П31: здоровье или мана ≤ 30% — от банки ненадолго расходятся волны (раз в 15 с, пока не отпустит)
  potWave('potHP', !pl.dead && pl.hp <= S.maxHP * 0.3 && P.potions.hp > 0);
  potWave('potMP', !pl.dead && pl.mp <= S.maxMP * 0.3 && (P.potions.mp || 0) > 0);
  const ui = $('ui');
  ui.classList.toggle('lowhp', G.player && !G.player.dead && G.player.hp < G.stats.maxHP * 0.3);
  ui.classList.toggle('surv', !!G.surv);
  if (G.surv) { const S = G.surv; let sh = $('survHud'); if (!sh) { sh = el('div', '', ''); sh.id = 'survHud'; ui.appendChild(sh); sh.innerHTML = '<div class="sv-time"></div><div class="sv-xp"><i></i></div><div class="sv-info"></div><button class="sv-quit">Aufgeben</button>'; sh.querySelector('.sv-quit').onclick = () => { if (confirm('Lauf beenden? Belohnungen werden gutgeschrieben.')) SV.endRun(false); }; }
    sh.querySelector('.sv-time').textContent = `${Math.floor(S.t / 60)}:${String(Math.floor(S.t % 60)).padStart(2, '0')} / 20:00`; sh.querySelector('.sv-xp i').style.width = (S.xp / S.next * 100) + '%'; sh.querySelector('.sv-info').textContent = `St. ${S.lvl} · ${S.kills} Kills`; }
  else { const sh = $('survHud'); if (sh) sh.remove(); }
  // кнопки боя скрыты, пока не понадобились впервые (обучение)
  for (const k of ['dodge', 'pot', 'potMP', 'sk', 'auto', 'scroll']) ui.classList.toggle('lk-' + k, !tutUn(k));
  ui.classList.toggle('fight', inCombat());
  ui.classList.toggle('dungeon', G.zoneId !== 'town');
  $('tracker').classList.toggle('open', G.time < trackOpenUntil && !inCombat());
  edgeArrow(); const lb = $('btnLead'); lb.classList.toggle('hidden', !G.guide || inCombat() || !!G.surv); lb.classList.toggle('on', !!G.lead); lb.classList.toggle('lure', !G.lead && G.profile.level < 5);   // М24: в начале кнопка «Веди меня» мягко пульсирует — её не хотелось нажимать
  const boss = G.enemies.find(e => (e.D.boss || e.D.elite) && e.aggro && !e.dead) || null;
  ui.classList.toggle('boss', !!boss);
  if (boss && !boss.dead && G.enemies.includes(boss)) {
    const bb = $('bossBar'); bb.classList.remove('hidden'); bb.querySelector('.n').textContent = boss.name + (boss.phase > 1 ? ` – Phase ${boss.phase}` : '');
    bb.querySelector('i').style.width = (boss.hp / boss.maxHP * 100) + '%'; bb.querySelector('b').textContent = `${Math.ceil(boss.hp)} / ${boss.maxHP}`;
  } else { $('bossBar').classList.add('hidden'); if (boss && (boss.dead || !G.enemies.includes(boss))) G.boss = null; }
  if (lastHud > 0 && tick < 0.25) { lastHud -= dt; return; }
  tick = 0; lastHud = 0.25;
  $('lvl').textContent = P.level; $('lvl').classList.toggle('up', P.attrPts > 0 || P.skillPts > 0);
  setBar('xpBar', P.xp / xpToNext(P.level));
  $('gold').textContent = fmt(P.gold); $('shards').textContent = P.shards || 0; $('torchV').textContent = CS.torches().n;   // П44: подписи «зол.», «◆», «⚡» — картинки в index.html
  autoTick(); $('btnAuto').classList.toggle('on', !!G.auto); dot('dotHW', G.zoneId === 'town' && hwReady() ? 1 : 0);
  $('hpCount').textContent = P.potions.hp; $('mpCount').textContent = P.potions.mp; $('scrollCount').textContent = P.scrolls;
  $('btnScroll').classList.toggle('hidden', !scrollZone());   // П48/П64: и в походах, и в Глубинах
  const newItems = P.bag.filter(x => x.isNew).length; dot('dotInv', newItems);
  dot('dotChar', G.zoneId === 'town' ? P.attrPts : 0); dot('dotSkill', G.zoneId === 'town' ? P.skillPts : 0);
  const ds = dailyStatus(), cs = chestStatus(), gifts = (ds.claimable ? 1 : 0) + (cs.ready ? 1 : 0) + (dailyReady() ? 1 : 0); dot('dotGift', gifts);
  const sh = G.zone && G.zone.inter.find(i => i.id === 'shrine'); if (sh) { sh.plate = 'Quell der Macht' + (gifts ? ` 🎁${gifts}` : blessLeft() > 0 ? '' : ' ✦'); sh.marker = (gifts || !P.shrineSeen) && !earlyLock('extra') ? '!' : null; }   /* П67: «!» над Источником, пока игрок ни разу не заходил */   // значок над алтарём
  blessTick(); dot('dotSeason', seasonClaimable());
  { const n = streak(); let sb = $('streakB'); if (!sb) { sb = el('span', '', ''); sb.id = 'streakB'; $('portrait').appendChild(sb); }   // сборка 47: огонёк серии побед
    const t = n ? `🔥${n}` : ''; if (sb.textContent !== t) { sb.textContent = t; sb.title = n ? `Siegesserie: +${Math.min(10, n) * 5} % Gold` : ''; } sb.style.display = n ? '' : 'none'; }
  { let gl = $('goalLine'); if (!gl) { gl = el('div', '', ''); gl.id = 'goalLine'; $('buffs').after(gl); } const t = G.zoneId === 'wild' || G.zoneId === 'survival' || (G.run && G.run.floor === 0) ? '' : G.zoneId === 'town' || !inCombat() ? nextGoalLine() : ''; if (gl.textContent !== t) gl.textContent = t; }   // «до цели» (сборка 21); в походе на этом месте плашка ноши
  // buffs
  const now = Date.now(); const bf = [];
  if (blessLeft() > 0) bf.push(`<b class="bless">✦ Kraft des Quells ${mmss(blessLeft())}</b>`);
  if (P.boosts.xpUntil > now) bf.push(`EP +50 % ${mmss(P.boosts.xpUntil - now)}`);
  if (P.boosts.goldUntil > now) bf.push(`Gold +50 % ${mmss(P.boosts.goldUntil - now)}`);
  if (pl.shield > 1) bf.push(`Schild ${Math.round(pl.shield)}`);
  if (G.run && G.run.boons) for (const id of G.run.boons) bf.push(`${BOONS[id].glyph} ${BOONS[id].name}`);
  if (G.run && G.run.mod) bf.push(`<b class="modbuff">${G.run.mod.glyph} ${G.run.mod.name}</b>`);   // сборка 49: модификатор этажа виден без меню
  $('buffs').innerHTML = bf.map(b => `<span class="buff">${b}</span>`).join('');
  tracker(); huntBox(); minimap();
}
// «Охота»: always-visible timer to the next alarm, or the active beast and where it lurks
let lastHunt = '';
function huntBox() {
  let h = '', on = false;
  if (HU.unlocked() && !G.surv) {
    const cur = HU.current();
    // коротко, чтобы плашка не закрывала пол-экрана: «⚠ Лесной Ужас / Катакомбы · Преддверие» (красная рамка и так говорит, что это охота)
    if (cur && cur.slain) { on = true; h = `<div class="hb-t ok">✔ ${esc(HU.bossOf(cur).name)}</div><div class="hb-d">Bei Dorfältestem Edric abgeben</div>`; }
    else if (cur) { on = true; h = `<div class="hb-t">⚠ ${esc(HU.bossOf(cur).name)}</div><div class="hb-d">${esc(HU.whereText(cur).replace(/, зал «(.+)»$/, ' · $1'))}</div>`; }
    else h = `<span class="hb-ico">🎯</span> Jagd in <b>${mmss(HU.msLeft())}</b>`;
  }
  const b = $('huntBox'); b.classList.toggle('hidden', !h); b.classList.toggle('on', on); b.classList.toggle('ready', HU.readyToTurnIn());
  if (h !== lastHunt) { b.innerHTML = h; lastHunt = h; }
}
const mmss = ms => { const s = Math.ceil(ms / 1000); return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`; };
export const BADGES = {};
function dot(id, n) { BADGES[id] = n || 0; const d = $(id); if (!d) { const m = $('dotMenu'); const tot = ['dotInv', 'dotChar', 'dotSkill', 'dotGift', 'dotHW', 'dotSeason'].reduce((a, k) => a + (BADGES[k] || 0), 0); if (m) { m.classList.toggle('hidden', !tot); m.textContent = tot > 9 ? '9+' : tot; } return; } d.classList.toggle('hidden', !n); d.textContent = n > 9 ? '9+' : n; }
function setBar(id, f, txt) { const b = $(id); b.firstElementChild.style.width = Math.max(0, Math.min(1, f)) * 100 + '%'; if (txt != null) b.querySelector('b').textContent = txt; }
let lastTrack = '';
function tracker() {
  const q = Q.current(); let h;
  if (G.run) {
    const r = G.run, t = Math.floor(G.time - r.t0); const boss = G.enemies.find(e => e.story === 'floorboss' && !e.dead);
    h = `<div class="t">${r.floor === 0 ? 'Prolog · Gruft des Erwachens' : esc(G.zone.name)}</div><div class="d" style="display:block">Feinde ${r.kills}/${r.total} · ${Math.floor(t / 60)}:${String(t % 60).padStart(2, '0')}${r.kills >= r.total ? ' · Portal offen' : ' · töte alle, um das Portal zu öffnen'}</div>`;
    if (h !== lastTrack) { $('tracker').innerHTML = h; lastTrack = h; } return;
  }
  if (!q) h = `<div class="ch">${chapterOf(STORY[STORY.length - 1])}</div><div class="t">Geschichte abgeschlossen!</div><div class="d">Abgrundkreise im Tiefen-Fenster, Ebenenrekorde, Abgrundernte, Feldzug-Forts und Aufträge am Brett</div>`;
  else {
    const pr = Q.progressOf(q), ch = q.chapter || 1, inCh = STORY.filter(x => (x.chapter || 1) === ch), done = inCh.indexOf(q);
    let txt = q.text; const Wd = G.profile.world;
    if (q.id === 'medallion') txt = !Wd.hasKey ? 'Schritt 1/3: Der Schlüssel ist in einem der Sarkophage der Katakomben versteckt – öffne sie.' : !Wd.opened.door_altar ? 'Schritt 2/3: Du hast den Schlüssel. Geh zur verschlossenen Tür im Osten.' : 'Schritt 3/3: Besiege den Wächter in der Halle hinter der Tür und nimm das Amulett vom Altar.';
    if (Q.isReady()) { const who = Q.TURN_NAME[Q.turnNpc(q)]; txt = G.zoneId === 'town' ? `✔ Erledigt! Geh zu ${who} (Zeichen „?“) für deine Belohnung.` : `✔ Erledigt! Kehr für die Belohnung zu ${who} ins Dorf zurück.`; }
    else if (q.where && q.where !== G.zoneId && !(G.zoneId === 'wild' && G.wild && q.target === 'portal_' + G.wild.realm)) txt =   // задания леса (П37): цель — в этом походе, «вернитесь в деревню» не пишем
      (q.where === 'catacombs' ? 'Steig durch das Portal in die Katakomben hinab. ' : 'Kehr durch das Portal ins Dorf zurück. ') + txt;
    h = `<div class="ch">${chapterOf(q)} · ${done}/${inCh.length}</div><div class="t">${esc(q.title)}${pr ? ` <span class="muted">${pr.cur}/${pr.max}</span>` : ''}</div><div class="d">${esc(txt)}</div>` + (pr ? `<div class="pb"><i style="width:${pr.cur / pr.max * 100}%"></i></div>` : '');
  }
  if (h !== lastTrack) { $('tracker').innerHTML = h; lastTrack = h; }
}
let safeC = null, safeEl = null;
addEventListener('resize', () => { safeC = null; }); addEventListener('orientationchange', () => { safeC = null; });
function safeInsets() {   // env(safe-area-inset-*) в пикселях: CSS-переменные --safe-* читаем через невидимый элемент
  if (safeC) return safeC;
  if (!safeEl) { safeEl = el('div', ''); safeEl.style.cssText = 'position:fixed;visibility:hidden;pointer-events:none;padding:var(--safe-t) var(--safe-r) var(--safe-b) var(--safe-l)'; document.body.appendChild(safeEl); }
  const c = getComputedStyle(safeEl), n = v => parseFloat(v) || 0;
  return (safeC = { t: n(c.paddingTop), r: n(c.paddingRight), b: n(c.paddingBottom), l: n(c.paddingLeft) });
}
// короткое имя цели стрелки: у жителей — имя без звания («Наставник Элвин» → «Элвин»), у порталов и мест — табличка
function guideName(t) {
  const n = (G.npcs || []).find(x => x.id === t.id), full = (n && n.name) || t.npcName || t.plate || (t.D && t.D.name) || '';
  if (!full) return ''; const w = String(full).split(' '); return n && w.length > 1 ? w[w.length - 1] : full.length > 18 ? w[0] : full;
}
// стрелка у края экрана: если цель задания за кадром, показываем, в какую сторону бежать и сколько метров
function edgeArrow() {
  const e = $('edgeArrow'), t = G.guide, P = G.player;
  if (!t || !P || P.dead || G.surv) { e.classList.add('hidden'); return; }
  const [sx, sy] = G.cam.toScreen(t.x, t.y);
  // С3: отступ от края — 46 px плюс вырез/скругление экрана с каждой стороны (safe area)
  const S = safeInsets(), W = innerWidth, H = innerHeight, mL = 46 + S.l, mR = 46 + S.r, mT = 46 + S.t, mB = 46 + S.b;
  if (sx > mL && sx < W - mR && sy > mT && sy < H - mB) { e.classList.add('hidden'); return; }
  const cx = (mL + W - mR) / 2, cy = (mT + H - mB) / 2; let dx = sx - cx, dy = sy - cy; const l = Math.hypot(dx, dy) || 1; dx /= l; dy /= l;
  let k = Math.min((dx > 0 ? W - mR - cx : cx - mL) / Math.abs(dx || 1e-6), (dy > 0 ? H - mB - cy : cy - mT) / Math.abs(dy || 1e-6));
  // сборка 59: стрелка не ложится на полосы здоровья, трекер, кнопки боя — сдвигается по тому же направлению ближе к центру
  const R = ['hudL', 'hudR', 'pad', 'btnAct', 'btnLead'].map(id => $(id)).filter(x => x && x.offsetParent).map(x => x.getBoundingClientRect()).filter(r => r.width && r.width < W * 0.9);
  const hit = (x, y) => R.some(r => x > r.left - 30 && x < r.right + 30 && y > r.top - 26 && y < r.bottom + 26);
  while (k > 70 && hit(cx + dx * k, cy + dy * k)) k -= 10;
  e.classList.remove('hidden');
  e.style.left = (cx + dx * k) + 'px'; e.style.top = (cy + dy * k) + 'px';
  e.querySelector('.ea-a').style.transform = `rotate(${Math.atan2(dy, dx)}rad)`;
  // правки мамы (М26): «25 м» без подписи было непонятно — теперь «Элвин · 25 м»: куда идти и сколько шагов (метров) до цели
  const nm = guideName(t); e.querySelector('.ea-d').textContent = (nm ? nm + ' · ' : '') + Math.round(Math.hypot(t.x - P.x, t.y - P.y)) + ' m';
}

// minimap: explored-radius reveal in dungeon, quest target marker
const seen = new Map();
function minimap() {
  const cv = $('minimap'); if (!cv || cv.offsetParent === null) return;
  const Z = G.zone, m = Z.map, x = cv.getContext('2d'), P = G.player;
  const key = seenKey(Z); let S = seen.get(key); if (!S) { if (Z.json.seed != null) for (const k of seen.keys()) if (k.startsWith(Z.id + ':')) seen.delete(k); S = new Uint8Array(m.w * m.h); seen.set(key, S); }   // П30: у сгенерированной раскладки своя разведанная карта, прежние не копятся
  const R = 7; for (let dy = -R; dy <= R; dy++) for (let dx = -R; dx <= R; dx++) { const tx = Math.floor(P.x) + dx, ty = Math.floor(P.y) + dy; if (tx >= 0 && ty >= 0 && tx < m.w && ty < m.h && dx * dx + dy * dy <= R * R) S[ty * m.w + tx] = 1; }
  drawMap(x, cv.width, Z, S, P, 13);
}
export function drawMap(x, size, Z, S, P, span) {
  const m = Z.map; x.clearRect(0, 0, size, size);
  const cell = span ? size / (span * 2) : size / ((m.w + m.h) * 0.74);
  // rotate 45° to match isometric view
  x.save(); x.translate(size / 2, size / 2); x.scale(1, 0.62); x.rotate(Math.PI / 4);
  const cx = span ? P.x : m.w / 2, cy = span ? P.y : m.h / 2;
  for (let ty = 0; ty < m.h; ty++) for (let tx = 0; tx < m.w; tx++) {
    if (Z.dark && S && !S[ty * m.w + tx]) continue;
    if (span && (Math.abs(tx - cx) > span * 1.5 || Math.abs(ty - cy) > span * 1.5)) continue;
    const c = m.ch(tx, ty); if (c === 'x' || c === 'v') continue;   // пропасть походов — пусто
    x.fillStyle = m.blocked(tx, ty) ? (c === '~' ? '#23406a' : Z.dark ? '#5a4a3a' : '#2a3a1a') : Z.dark ? '#2a221c' : (c === '#' ? '#6a6258' : c === ',' ? '#5a4630' : '#34502a');
    x.fillRect((tx - cx) * cell, (ty - cy) * cell, cell + 0.4, cell + 0.4);
  }
  const dotAt = (wx, wy, col, r) => { x.fillStyle = col; x.beginPath(); x.arc((wx - cx) * cell, (wy - cy) * cell, r, 0, 7); x.fill(); };
  for (const it of Z.inter) if (!it.hidden) { if (Z.dark && S && !S[Math.floor(it.y) * m.w + Math.floor(it.x)]) continue; dotAt(it.x, it.y, it.type === 'portal' ? '#b48cff' : it.type === 'npc' ? '#ffd24a' : it.done ? '#666' : '#e8c26a', Math.max(2, cell * 0.6)); }
  const q = Q.current(); if (q && q.target) { const t = Z.inter.find(i => i.id === q.target) || (q.target === 'elite' || q.target === 'boss' ? G.enemies.find(e => e.story === q.target) : null); if (t) { x.strokeStyle = '#ffd24a'; x.lineWidth = 2; x.beginPath(); x.arc((t.x - cx) * cell, (t.y - cy) * cell, Math.max(4, cell * 1.2), 0, 7); x.stroke(); } }
  const hg = G.huntGuide; if (hg && (!Z.dark || !S || S[Math.floor(hg.y) * m.w + Math.floor(hg.x)] || hg.D)) { x.strokeStyle = '#ff4030'; x.lineWidth = 2; x.beginPath(); x.arc((hg.x - cx) * cell, (hg.y - cy) * cell, Math.max(5, cell * 1.4), 0, 7); x.stroke(); }
  for (const e of G.enemies) if (!e.dead && e.aggro) dotAt(e.x, e.y, e.D.boss || e.D.elite ? '#ff8030' : '#d33', Math.max(1.5, cell * 0.4));
  dotAt(P.x, P.y, '#fff', Math.max(2.5, cell * 0.7));
  x.restore();
}
export { seen };
export const seenKey = Z => `${Z.id}:${Z.json.floorN ?? ''}:${Z.json.seed ?? ''}:${Z.map.w}x${Z.map.h}`;

// ---------------------------------------------------------------- автобой за рекламу (сборка 47)
// время вышло — выключаем, но не посреди боя; иногда (не в бою) стрелка напоминает, что АВТО есть
let remindAt = 0;
function autoTick() {
  const ab = $('btnAuto'), ok = autoOK(); ab.classList.toggle('ad', !ok);
  if (G.auto && !ok && !inCombat()) { G.auto = false; toast({ text: 'Autokampf beendet', sub: `Tippe AUTO und schau Werbung – noch ${AUTO_MIN} Minuten`, kind: 'info' }); }
  const now = Date.now(), wild = G.zoneId !== 'town' && G.zoneId !== 'castle' && G.zoneId !== 'survival';
  if (!remindAt) remindAt = now + 3 * 60000;
  if (G.auto || !wild || !tutUn('auto') || now < remindAt || inCombat() || G.modalOpen || !G.player || G.player.dead) return;
  if (pointAt('btnAuto', ok ? 'AUTO: Der Held kämpft allein' : `AUTO für Werbung: Der Held kämpft ${AUTO_MIN} Minuten allein`, { time: 6, force: true })) remindAt = now + 8 * 60000;
}
