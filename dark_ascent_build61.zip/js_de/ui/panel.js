// Proximity panels: walk into an NPC/room circle → the panel opens by itself; walk away → it closes.
// The game keeps running (no pause). Everything shows the price and the effect up front.
import { G, bus } from '../game/ctx.js';
import { $, el, esc, fmt, ICO } from '../core/util.js';
import { UPGRADES, upgCost, upgHave, ROOMS, DECOR } from '../data/upgrades.js';
import { REPEATABLE } from '../data/quests.js';
import { REALMS } from '../data/wild.js';
import * as CH from '../game/character.js';
import * as EC from '../game/economy.js';
import * as Q from '../game/quests.js';
import * as CS from '../game/castle.js';
import * as DQ from '../game/daily.js';
import { upgradeCost, MAX_UPG, iconOf } from '../game/items.js';
import { iconURL } from './icons.js';
import { openWindow, W } from './windows.js';
import { watchRewarded, offerToken } from '../platform/monetize.js';
import { startTrial } from '../game/game.js';
import { adButton } from './adbtn.js';
import { stats } from '../game/stats.js';
import { earlyLock } from '../game/progress.js';
import { PETS, TIERS, PET_MAX, GIFT_PET, TRAIN, TRAIN_MAX, TRAIN_STEP } from '../data/pets.js';
import * as PT from '../game/pets.js';

let target = null, box = null, lastSig = '', dismissed = null;
export function initPanel() {
  box = el('div', 'npc-panel hidden'); box.id = 'npcPanel'; $('ui').appendChild(box); box.addEventListener('scroll', moreDn, { passive: true });
  // правки мамы (М30): выполненное задание сдаётся сразу, как подошли к жителю (кузнец, Мира, Элвин, Кофи) — раньше только после второго подхода
  // или открытия его окна, и стрелка всё вела к нему
  bus.on('panel', t => { if (!t) dismissed = null; target = t; lastSig = ''; if (t && t.id && Q.isReady() && Q.turnNpc(Q.current()) === t.id) Q.talked(t.id); render(true); });
  // tap anywhere on the game field outside the panel → close it until you walk away and come back
  const hide = e => { if (!target || box.classList.contains('hidden') || box.contains(e.target)) return; dismissed = target; render(true); };
  for (const id of ['game', 'joyZone']) { const n = $(id); if (n) n.addEventListener('pointerdown', hide, true); }
  for (const ev of ['hud', 'statsChanged', 'roomUnlocked', 'save']) bus.on(ev, () => render());
  setInterval(() => render(), 1000);   // live timers (altar, seals)
}
const coin = n => `<span class="c-gold">${fmt(n)}</span>`;
const shard = n => `<span class="c-shard">${n}◆</span>`;
function row(icon, title, sub, btnText, ok, onClick, extraCls = '') {
  const r = el('div', 'pn-row ' + extraCls, `<div class="pn-ic">${icon}</div><div class="pn-tx"><b>${title}</b><small>${sub}</small></div>`);
  if (btnText != null) { const b = el('button', 'pn-btn' + (ok ? ' ok' : ''), btnText); b.disabled = !ok; b.onpointerdown = e => { e.stopPropagation(); onClick(); bus.emit('sfx', 'click'); render(true); }; r.appendChild(b);
    // правки мамы (М6): нажатие на саму строку («Зелье здоровья») тоже покупает — раньше срабатывала только зелёная кнопка справа.
    // Строку жмём коротким касанием (click), чтобы прокрутка списка пальцем ничего не покупала
    if (ok) { r.classList.add('tap'); r.onclick = e => { if (e.target.closest('button')) return; onClick(); bus.emit('sfx', 'click'); render(true); }; } }
  return r;
}
// правки мамы (М2): внизу панели «▼ ещё ниже», пока список не долистан
const moreDn = () => box && box.classList.toggle('more-dn', box.scrollHeight - box.clientHeight - box.scrollTop > 8);
function render(force) {
  if (!box) return;
  const showing = !(!target || target === dismissed || G.modalOpen || G.player.dead); $('ui').classList.toggle('panel-open', showing);
  if (!showing) { box.classList.add('hidden'); return; }
  const P = G.profile; const sig = [target.id, P.gold, P.shards, P.level, P.attrPts, P.skillPts, JSON.stringify(P.upg), JSON.stringify(P.castle), JSON.stringify(P.pets), P.potions.hp, Math.floor(Date.now() / 1000)].join('|');
  if (!force && sig === lastSig) return; lastSig = sig;
  const st = box.scrollTop; box.innerHTML = ''; box.classList.remove('hidden'); setTimeout(moreDn, 0);
  const head = (t, s) => { const h = el('div', 'pn-head', `<b>${t}</b>${s ? `<small>${s}</small>` : ''}`); const x = el('button', 'pn-x', '✕'); x.onpointerdown = e => { e.stopPropagation(); dismissed = target; render(true); }; h.appendChild(x); box.appendChild(h); };
  const bal = () => box.appendChild(el('div', 'pn-bal', `${coin(P.gold)} G · ${shard(P.shards || 0)}`));
  const T = target;
  if (T.id === 'trainer') {
    head('Mentor Elvin', 'Hier lernst du Fähigkeiten. Unten: Upgrades für Gold (Präzision für Abgrundsplitter ◆).'); bal();
    const b2 = el('div', 'pn-tabs');
    const sk = el('button', 'pn-tab' + (CH.canLearnNow() ? ' hot' : ''), `<span>✦</span><b>Fähigkeiten</b>${P.skillPts ? `<i>+${P.skillPts}</i>` : ''}`); sk.id = 'tBtnSkills'; sk.onclick = () => W.skills({ npc: true });
    b2.append(sk); box.appendChild(b2);
    if (P.skillPts && !Object.values(P.skills || {}).some(Boolean)) box.appendChild(el('div', 'pn-tip', '💡 Lerne zuerst eine <b>aktive Fähigkeit</b> – sie erscheint als Knopf unten rechts und macht Kämpfe viel leichter.'));
    box.appendChild(el('div', 'pn-sub', 'Upgrades'));
    const upLock = earlyLock('upg');   // сборка 47: усиления — после первой Летописи битв
    if (upLock) box.appendChild(el('div', 'pn-tip', '🔒 Upgrades öffnen sich, sobald du dich in der <b>Schlachtchronik</b> versucht hast und mit Gold zurückkehrst.'));
    // правки мамы (М8): было непонятно, что значит «усилить героя» — умение или усиления. Засчитывается любое из двух — так и пишем,
    // и то, на что хватает золота, пульсирует
    const elvStep = !upLock && Q.current() && (Q.current().id === 'hw_elvin' || Q.current().id === 'surv_elvin');
    const rankOk = elvStep && P.skillPts > 0 && Object.keys(P.skills || {}).some(id => P.skills[id] && CH.canLearn(id).ok && P.gold >= CH.skillCost(id));
    if (elvStep) box.appendChild(el('div', 'pn-tip', `💡 Gib das Gold für eins von beiden aus: ${P.skillPts > 0 ? '<b>✦ Fähigkeiten</b> – steigere den Rang einer Fähigkeit (du hast einen Fähigkeitspunkt) oder ' : ''}kauf unten ein Upgrade – <b>Schlagkraft</b> oder <b>Robustheit</b>. Die Aufgabe zählt sofort nach dem Kauf.`));
    if (rankOk) sk.classList.add('nudge');
    let nudged = rankOk;
    for (const [id, U] of Object.entries(UPGRADES)) {
      const l = (P.upg && P.upg[id]) || 0, max = l >= U.max, cost = upgCost(id, l), can = !upLock && !max && upgHave(P, id) >= cost;
      const r = row(U.icon, `${U.name} <span class="lv">St. ${l}</span>`, max ? U.fmt(l) + ' · max.' : `${U.fmt(l)} → <span class="good">${U.fmt(l + 1)}</span>`, max ? '—' : upLock ? '🔒' : U.shards ? `${cost}◆` : `${fmt(cost)}`, can, () => buyUpg(id));
      r.querySelector('.pn-btn').classList.add('cost');   // крупная цена и осколок на всю кнопку (а не мелкая цифра посреди пустой кнопки)
      if (elvStep && can && !nudged && !U.shards) { r.querySelector('.pn-btn').classList.add('nudge'); r.classList.add('hot'); nudged = true; }
      box.appendChild(r);
    }
  } else if (T.id === 'smith') {
    head('Schmied Goran', 'Verschmelzen: drei Items → ein besseres. Härtung: +10 % pro Stufe.'); bal();
    { const ready = EC.mergeGroups().reduce((a, g) => a + g.can, 0);   // сборка 38: слияние на виду, первой кнопкой
      const m = el('button', 'btn pn-merge ' + (ready ? 'gold' : ''), `⚒ Verschmelzen 3 → 1${ready ? ` · ${ready} bereit` : ''}`); m.onclick = () => W.npc_smith('merge'); box.appendChild(m);
      if (!ready) box.appendChild(el('div', 'pn-tip', '💡 <b>Verschmelzen</b> – der Schmied schmilzt drei gleiche Items (gleiche Art und Farbe, z. B. drei grüne Helme) zu einem stärkeren ein. Noch gibt es nichts zu verschmelzen: Items fallen von Feinden und aus Truhen.')); }   // М30: «что такое слияние — непонятно»
    box.appendChild(el('div', 'pn-sub', 'Angelegtes härten'));
    for (const slot of ['weapon', 'head', 'chest', 'amulet']) {
      const it = P.gear[slot]; if (!it) continue; const u = it.upg || 0, c = upgradeCost(it);
      box.appendChild(row(`<img src="${iconURL(iconOf(it))}">`, `${esc(it.name)} <span class="lv">+${u}</span>`, it.dmg ? 'Schaden' : 'Abwehr', u >= MAX_UPG ? 'max.' : `+${u + 1} · ${fmt(c)}`, u < MAX_UPG && P.gold >= c, () => EC.upgrade(it.id)));
    }
    const b = el('button', 'btn sm', 'Taschen-Items härten'); b.onclick = () => W.npc_smith('upg'); box.appendChild(b);
  } else if (T.id === 'merchant') {
    head('Händlerin Mira'); bal();
    const potStep = Q.current() && Q.current().id === 'meet_merchant';
    if (potStep) box.appendChild(el('div', 'pn-tip', '💡 Kauf einen <b>Heiltrank</b>: Drück den grünen Knopf „Kaufen“ in seiner Zeile. Im Kampf drückst du den roten Trankknopf – er heilt. Taste <b>Q</b> am PC.'));
    for (const [k, n, ic] of [['hp', 'Heiltrank', 'potion_hp'], ['mp', 'Manatrank', 'potion_mp'], ['scroll', 'Rückkehrrolle', 'scroll']]) {
      const pr = EC.potionPrice(k), r = row(`<img src="${iconURL(ic)}">`, n, `im Besitz: ${k === 'scroll' ? P.scrolls : P.potions[k]}`, `Kaufen<br>${fmt(pr)}`, P.gold >= pr, () => EC.buyConsumable(k), potStep && k === 'hp' ? 'hot' : '');
      box.appendChild(r);
      // М6: на шаге «Купить зелье» кнопка покупки пульсирует (панель перерисовывается раз в секунду — палец бы пропадал)
      if (potStep && k === 'hp' && P.gold >= pr) r.querySelector('.pn-btn').classList.add('nudge');
    }
    const b = el('button', 'btn sm', 'Tagesangebote für deine Klasse'); b.onclick = () => W.npc_merchant(); box.appendChild(b);
  } else if (T.id === 'caravan') {
    // сборка 58: Караванщик Кофи — питомцы за осколки Бездны (js/data/pets.js, js/game/pets.js)
    const S = PT.petsOf(P);
    head('Karawanenhändler Kofi', 'Tiere aus dem Ödland. Eines begleitet dich: Es schlägt schwach zu, doch jedes hat seine eigene Gabe.'); bal();
    // правки к сборке 60: подарок здесь брали в обход старосты (шаг «Заглянуть к Кофи» потом засчитывался сам) и без поздравления.
    // До этого шага — только обещание; на шаге — крупная мигающая кнопка и праздник на весь экран (W.petReveal)
    if (!S.met && earlyLock('pet')) box.appendChild(el('div', 'pn-tip', '🎁 Kofi hat ein Geschenk für dich — du bekommst es, sobald Dorfältester Edric dich zu ihm schickt.'));
    else if (!S.met) {
      box.appendChild(el('div', 'pn-tip', `🎁 Ein Geschenk von Kofi: <b>${PETS[GIFT_PET].name}</b>. ${PETS[GIFT_PET].desc}`));
      const g = el('button', 'btn gold pet-gift', '🎁 Geschenk annehmen'); g.onpointerdown = e => { e.stopPropagation(); if (PT.meetCaravan()) { dismissed = target; render(true); W.petReveal(); } }; box.appendChild(g);
    }
    const btn = (r, text, ok, fn, cls = '') => { const b = el('button', 'pn-btn' + (ok ? ' ok' : '') + cls, text); b.disabled = !ok; b.onpointerdown = e => { e.stopPropagation(); fn(); render(true); }; r.appendChild(b); };
    for (const [id, D] of Object.entries(PETS)) {
      const lvl = S.own[id] || 0, c = PT.petCan(id), T0 = TIERS[D.tier], on = S.active === id;
      const sub = `<span style="color:${T0.color}">${T0.name}</span> · ⚔ ${PT.petInfo(id, lvl || 1).dps}/s · ${D.desc}`;
      const r = row(D.icon, `${esc(D.name)}${lvl ? ` <span class="lv">St. ${lvl}</span>` : ''}`, sub, null, false, null, on ? 'hot' : '');
      { const ib = el('button', 'pn-btn ok pn-info', 'ℹ'); ib.title = 'Schaden und Gabe des Begleiters'; ib.onpointerdown = e => { e.stopPropagation(); W.petInfo(id); }; r.appendChild(ib); }   // П61
      if (!lvl) btn(r, c.why ? '🔒 ' + c.why : `${c.cost}◆`, c.ok, () => PT.buyPet(id), c.why ? '' : ' cost');
      else {
        btn(r, on ? '✔ Bei dir' : 'Mitnehmen', !on, () => PT.choosePet(id));
        if (lvl < PET_MAX) btn(r, `▲ ${c.cost}◆`, c.ok, () => PT.upgradePet(id), ' up cost');
      }
      box.appendChild(r);
    }
    // П29 (правки 2): дрессировка за золото — физический и магический урон всех питомцев; короткое обучение при первом заходе
    if (S.met) {
      box.appendChild(el('div', 'pn-sub', 'Abrichtung (für alle Begleiter)'));
      if (!S.tut) {
        const tip = el('div', 'pn-tip', '<b>Wie ein Begleiter wächst</b><br>1. <b>Stufe</b> des Tiers (▲ für Splitter ◆) — +15% auf seine ganze Kraft, bis Stufe 5.<br>2. <b>Abrichtung</b> für Gold — für alle Begleiter zugleich: 🗡 physischer Schaden (Biss, Krallen, Nadeln) und ✦ magischer (Feuer, Gift, Funken, Heilung, Schild). +10% pro Rang.<br>3. Wechsle das Tier — die Abrichtung bleibt.');
        const ok = el('button', 'btn gold', 'Verstanden'); ok.onpointerdown = e => { e.stopPropagation(); S.tut = 1; bus.emit('save'); render(true); }; tip.appendChild(ok); box.appendChild(tip);
      }
      for (const [k, T] of Object.entries(TRAIN)) {
        const c = PT.trainCan(k), r = row(T.icon, `${esc(T.name)} <span class="lv">${c.lvl}/${TRAIN_MAX}</span>`, `+${Math.round(c.lvl * TRAIN_STEP * 100)}% · ${esc(T.txt)}`, null, false, null, '');
        if (!c.max) btn(r, `▲ ${fmt(c.cost)} G`, c.ok, () => PT.trainPet(k), ' up'); box.appendChild(r);
      }
    }
    box.appendChild(el('p', 'muted pn-shards', ICO.pile + '<small>Abgrundsplitter ◆ geben Wächter, Bosse, Champions, Truhen, die Ernte und Wochenaufgaben. Verbesserung: +15 % Begleiterstärke pro Stufe.</small>'));
  } else if (T.id === 'board') {
    head('Questbrett', 'Täglich · wöchentlich · lange Aufträge');
    box.appendChild(el('div', 'pn-sub', 'Täglich'));
    for (const q of DQ.dailyQuests()) box.appendChild(row('☀', esc(q.title), q.claimed ? 'abgeholt' : `${q.cur}/${q.n}`, q.done && !q.claimed ? 'Abholen' : null, q.done && !q.claimed, () => DQ.claimDaily(q.id), q.done && !q.claimed ? 'hot' : ''));
    box.appendChild(el('div', 'pn-sub', 'Wöchentlich (größer)'));
    for (const q of DQ.weeklyQuests()) box.appendChild(row('☾', esc(q.title), q.claimed ? 'abgeholt' : `${q.cur}/${q.n}`, q.done && !q.claimed ? 'Abholen' : null, q.done && !q.claimed, () => DQ.claimWeekly(q.id), q.done && !q.claimed ? 'hot' : ''));
    box.appendChild(el('div', 'pn-sub', 'Lange Aufträge (schwer)'));
    for (const r of REPEATABLE) { const s = Q.repState(r); box.appendChild(row(s.done ? '✔' : '•', esc(r.title), `${s.cur}/${r.n}`, s.done ? 'Abholen' : null, s.done, () => Q.claimRep(r.id), s.done ? 'hot' : '')); }
  } else if (T.type === 'roomgate') {
    const R = ROOMS[T.room]; const c = CS.canUnlock(T.room);
    head(R.name, R.desc); bal();
    box.appendChild(el('div', 'pn-req', `<span class="${P.level >= R.lvl ? 'good' : 'bad'}">Stufe ${R.lvl}+</span> · <span class="${P.gold >= R.gold ? 'good' : 'bad'}">${fmt(R.gold)} G</span>${R.shards ? ` · <span class="${(P.shards || 0) >= R.shards ? 'good' : 'bad'}">${R.shards} Splitter</span>` : ''}`));
    const b = el('button', 'btn ' + (c.ok ? 'gold' : ''), c.ok ? 'Raum freischalten' : c.why); b.disabled = !c.ok; b.onclick = () => CS.unlock(T.room); box.appendChild(b);
    box.appendChild(el('p', 'muted', '<small>Abgrundsplitter droppen zufällig: von Elite, Champions, Wächtern, Bossen und aus Truhen.</small>'));
  } else if (T.type === 'castleguide') {
    head('Zitadellenkarte', 'Tippe „Los“, um am Raumeingang zu erscheinen.'); bal();
    const rooms = G.zone.json.rooms;
    for (const [id, R] of Object.entries(ROOMS)) {
      const open = P.castle[id]; const gate = G.zone.inter.find(i => i.type === 'roomgate' && i.room === id);
      box.appendChild(row(open ? '✔' : '🔒', esc(R.name), open ? 'freigeschaltet' : `St. ${R.lvl} · ${fmt(R.gold)} G${R.shards ? ` · ${R.shards}◆` : ''}`, 'Los', true, () => {
        const rr = rooms[id]; const tx = open ? rr[0] + rr[2] / 2 : gate.x, ty = open ? rr[1] + rr[3] / 2 + 1 : gate.y;
        const [x, y] = G.zone.map.nearestFree(open ? tx : (gate.x + (id === 'altar' ? 1.6 : id === 'trial' ? -1.6 : 0)), open ? ty : (gate.y + (id === 'treasury' || id === 'trophy' ? 1.6 : 0)), 0.35);
        G.player.x = x; G.player.y = y; G.cam.x = x; G.cam.y = y; bus.emit('sfx', 'portal');
      }));
    }
  } else if (T.type === 'nemwall') {
    const S = P.nemesis || { list: [], trophies: [] }, foes = S.list.filter(n => n.alive && (n.rank > 0 || n.defeats || n.fled));
    head('Feindeswand', 'Getötete Erzfeinde hängen als Trophäen (+Schaden und Gold für immer). Die Lebenden warten auf Rache.');
    box.appendChild(el('div', 'pn-big', `Trophäen: <b>${S.trophies.length}</b> · +${S.trophies.reduce((a, t) => a + t.bonus, 0).toFixed(1)} % Schaden und Gold`));
    for (const t of S.trophies) box.appendChild(row('☠', esc(t.name), `${(REALMS[t.realm] || REALMS.forest).short} · Rang ${t.rank} · +${t.bonus.toFixed(1)} %`, null, false, null));
    for (const n of foes) box.appendChild(row('⚔', esc(n.name + (n.title ? ', ' + n.title : '')), `lebt · Rang ${n.rank}${n.stash ? ` · hält ${n.stash} G` : ''}`, null, false, null, 'hot'));
    if (!S.trophies.length && !foes.length) box.appendChild(el('p', 'muted', '<small>Noch leer. Erobere ein Fort in Skjolds Fjorden oder im Alten Wald – sein Kommandant wird dein Erzfeind.</small>'));
  } else if (T.type === 'socket') {
    const cur = P.castle.decor && P.castle.decor[T.sid];
    head(cur ? DECOR[cur].name : 'Dekoplatz', cur ? `Bonus: ${DECOR[cur].txt}. Austauschbar (die alte erstattet den halben Preis).` : 'Richte die Zitadelle ein: Jede Deko gibt einen dauerhaften Bonus.'); bal();
    for (const [id, D] of Object.entries(DECOR)) { if (id === cur) continue; box.appendChild(row('✦', esc(D.name), D.txt, `${fmt(D.gold)}${D.shards ? ` · ${D.shards}◆` : ''}`, P.gold >= D.gold && (P.shards || 0) >= D.shards, () => CS.placeDecor(T.sid, id))); }
  } else if (T.room === 'altar') {
    const l = P.castle.altar, stored = CS.altarStored(), rate = CS.altarRate(), uc = CS.altarUpgCost();
    head(`Goldaltar · St. ${l}`, `${fmt(rate)} G/Stunde, sammelt bis 8 Stunden – auch offline.`); bal();
    box.appendChild(el('div', 'pn-big', `Gesammelt: ${coin(stored)}`));
    const r1 = el('div', 'pn-row2');
    const a = el('button', 'btn gold', 'Abholen'); a.disabled = !stored; a.onclick = () => { CS.altarCollect(1); render(true); };
    const ad = el('button', 'btn ad', 'Abholen ×2'); ad.disabled = !stored; ad.onclick = () => watchRewarded('altar_x2', offerToken('altar_x2', String(P.castle.altarAt)), () => CS.altarCollect(2)).then(() => render(true));
    r1.append(a, ad); box.appendChild(r1);
    if (l < 10) box.appendChild(row('▲', `Altar auf St. ${l + 1} verbessern`, `Ertrag → ${fmt(Math.round((35 + 25 * (l + 1)) * (1 + P.level * 0.08)))}/Stunde`, `${fmt(uc.gold)} · ${uc.shards}◆`, P.gold >= uc.gold && P.shards >= uc.shards, () => CS.altarUpgrade()));
  } else if (T.room === 'trial') {
    const s = CS.seals(); const left = CS.nextIn(s, CS.SEAL_MS);
    head('Halle der Prüfungen', 'Kämpf direkt in der Zitadelle gegen einen Wächter. Schalte AUTO an – der Held kämpft allein.'); bal();
    box.appendChild(el('div', 'pn-big', `Siegel: <b>${s.n}/${CS.SEAL_MAX}</b>${left ? ` <small>· +1 in ${Math.ceil(left / 60000)} min</small>` : ''}`));
    const F = P.story.flags, seen = t => t.type === 'boss' ? !!F.bossKilled : !!(F.eliteKilled || F.bossKilled);   // испытания только против тех, кого герой уже победил в сюжете
    for (const t of CS.TRIALS) if (!seen(t)) { box.appendChild(row('?', 'Unbekannter Gegner', t.type === 'boss' ? 'Öffnet nach dem Sieg über den Abgrundhenker' : 'Öffnet nach dem Sieg über den Medaillonwächter', null, false, () => { })); }
    else box.appendChild(row('⚔', esc(t.name), `Feind St. ${P.level + t.lvl} · nötig St. ${t.req}`, P.level < t.req ? `St. ${t.req}` : 'Kämpfen', P.level >= t.req && s.n > 0 && !G.trial, () => startTrial(t)));
    box.appendChild(el('p', 'muted', `<small>Siegel sind dein Eintritt zu Prüfungen. Sie füllen sich selbst: +1 alle 3 Stunden (max. ${CS.SEAL_MAX}). Ein weiteres Siegel gibt es einmal pro Stunde für Werbung.</small>`));
    box.appendChild(adButton('+1 Siegel', 'seal', 60 * 60e3, () => { s.n++; bus.emit('save'); }, () => render(true)));
  } else if (T.room === 'treasury') {
    head('Abgrundschatzkammer', 'Truhe: ein seltenes Item deiner Klasse, 7 % Chance auf Episch.'); bal();
    box.appendChild(row('▣', 'Abgrundtruhe', `${CS.CHEST_SHARDS} Splitter`, 'Öffnen', (P.shards || 0) >= CS.CHEST_SHARDS, () => CS.openTreasury()));
  } else if (T.room === 'trophy') {
    const l = P.castle.trophy || 0, c = CS.trophyCost();
    head(`Trophäenhalle · St. ${l}`, `Jetzt: +${l * 3} % Schaden, +${l * 5} % Gold.`); bal();
    if (l < 15) box.appendChild(row('♛', `Trophäe St. ${l + 1}`, `+3 % Schaden, +5 % Gold`, `${fmt(c.gold)} · ${c.shards}◆`, P.gold >= c.gold && (P.shards || 0) >= c.shards, () => CS.trophyUpgrade()));
  }
  box.scrollTop = st;
}
function buyUpg(id) {
  const P = G.profile; P.upg = P.upg || {}; const l = P.upg[id] || 0, cost = upgCost(id, l);
  if (earlyLock('upg')) { bus.emit('sfx', 'deny'); return; }
  if (l >= UPGRADES[id].max || upgHave(P, id) < cost) { bus.emit('sfx', 'deny'); if (UPGRADES[id].shards && l < UPGRADES[id].max) bus.emit('toast', { text: `${cost}◆ Abgrundsplitter nötig`, sub: 'Splitter gibt es von Chronik-Bossen, der Ernte, Wochenquests und dem Saisonpfad', kind: 'warn' }); return; }
  { const q = Q.current(); if (q && q.id === 'hw_elvin') P.story.flags.upgBought = true; if (q && q.id === 'surv_elvin') P.story.flags.upgBought2 = true; }   // шаги обучения «Усилить героя у Элвина»
  if (UPGRADES[id].shards) P.shards -= cost; else P.gold -= cost; P.upg[id] = l + 1; G.stats = stats(P); bus.emit('statsChanged'); bus.emit('sfx', 'anvil'); bus.emit('save');
  bus.emit('float', { x: G.player.x, y: G.player.y, text: `${UPGRADES[id].name} ↑`, color: '#9fe38e', z: 2.4 });
}
