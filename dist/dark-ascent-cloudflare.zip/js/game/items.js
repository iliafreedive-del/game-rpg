// Item generation and helpers (Inventory/Equipment domain logic, no DOM).
import { SETS, SET_SLOTS, SET_BASE } from '../data/sets.js';
import { G } from './ctx.js';
import { BASES, BASE, WEAPONS, AFFIXES, AFFIX_GROUP, RARITY, EPICS, CLASSES, SLOTS, RMUL, KIND_PERK } from '../data/items.js';
import { BRANCHES } from '../data/skills.js';
import { rand, rint, weighted, pick, uid } from '../core/util.js';

const slotOf = s => (s === 'ring1' || s === 'ring2') ? 'ring' : s;

export function basesFor(slot, ilvl, wt) {
  const s = slotOf(slot);
  return BASES.filter(b => b.slot === s && b.lvl <= Math.max(1, ilvl) && (!wt || b.wt === wt));
}

const ELEM = { fire: 'fire', cold: 'ice', light: 'light' };
const USELESS = { warrior: ['int'], archer: ['str', 'int'], mage: ['str', 'dex', 'ias'] };
function rollAffixes(item, count, cls) {
  const g = AFFIX_GROUP(item.slot);
  const C = cls && CLASSES[cls];
  const pool = Object.entries(AFFIXES).filter(([k, a]) => a.g.includes(g) && !item.affixes.some(x => x.k === k)
    && (!C || ((!ELEM[k] || C.branches.includes(ELEM[k])) && !USELESS[cls].includes(k))));
  for (let i = 0; i < count && pool.length; i++) {
    const k = weighted(pool.map(([k, a]) => [k, a.w]));
    const idx = pool.findIndex(p => p[0] === k); pool.splice(idx, 1);
    item.affixes.push(rollAffix(k, item.ilvl, cls));
  }
}
export function rollAffix(k, ilvl, cls) {
  const a = AFFIXES[k]; const [lo, hi] = a.r(ilvl);
  const af = { k, v: rint(lo, hi) };
  if (a.branch) af.b = cls ? pick(CLASSES[cls].branches) : pick(BRANCHES).id;
  return af;
}

// opts: {slot, ilvl, rarity, base, wt, epic}
// Редкость растёт вместе с героем: серые и зелёные вещи в начале, синие с 6-го уровня, золотые (эпики) с 12-го — не в первые 10 минут
export const maxRarityFor = lvl => lvl >= 12 ? 3 : lvl >= 6 ? 2 : 1;   // ограничение для выпадения; слияние у кузнеца его обходит
export function makeItem(opts = {}) {
  const lvlNow = G && G.profile && !opts.noClamp ? G.profile.level : 99;
  if (opts.epic && maxRarityFor(lvlNow) < 3) { opts = { ...opts }; delete opts.epic; opts.rarity = 2; }
  if (opts.rarity !== undefined && opts.rarity > maxRarityFor(lvlNow)) opts = { ...opts, rarity: maxRarityFor(lvlNow) };
  const ilvl = Math.max(1, opts.ilvl || 1);
  let base;
  if (opts.epic) base = BASE[opts.epic.base];
  else if (opts.base) base = BASE[opts.base];
  else {
    let slot = opts.slot;
    if (!slot || !SLOTS.includes(slot)) slot = weighted([['weapon', 40], ['head', 20], ['chest', 25], ['amulet', 15]]);
    let cands = basesFor(slot, ilvl, opts.wt);
    if (slot === 'weapon' && opts.cls) cands = cands.filter(b => CLASSES[opts.cls].weapons.includes(b.wt));
    // классу не выпадают вещи, требующие чужую характеристику (магу и лучнику — кольчуга, латы, шлем «на силу»)
    if (opts.cls) { const MAIN = { warrior: 'str', archer: 'dex', mage: 'int' }[opts.cls]; const own = cands.filter(b => !b.req || Object.keys(b.req).every(k => k === MAIN)); if (own.length) cands = own; }
    if (!cands.length) cands = basesFor(slot, 99, opts.wt).filter(b => !opts.cls || slot !== 'weapon' || CLASSES[opts.cls].weapons.includes(b.wt)).sort((a, b) => a.lvl - b.lvl).slice(0, 1);
    // prefer the highest tiers available but keep variety
    base = weighted(cands.map(b => [b, 1 + b.lvl]));
  }
  const rarity = opts.epic ? 3 : (opts.rarity ?? 0);
  const it = { id: uid('i'), base: base.k, slot: base.slot, ilvl, rarity, upg: 0, affixes: [] };
  if (base.wt) {
    const W = WEAPONS[base.wt];
    const lm = 1 + (ilvl - 1) * 0.12;
    it.wt = base.wt;
    it.dmg = [Math.max(1, Math.round(W.dmg[0] * base.mult * lm * (0.9 + rand() * 0.2))), 0];
    it.dmg[1] = Math.max(it.dmg[0] + 1, Math.round(W.dmg[1] * base.mult * lm * (0.9 + rand() * 0.2)));
  }
  if (base.armor) it.armor = Math.round(base.armor * (1 + (ilvl - 1) * 0.1) * (0.9 + rand() * 0.25));
  if (base.block) it.block = base.block;
  if (base.req) it.req = { ...base.req };
  if (opts.epic) {
    it.epic = opts.epic.id; it.name = opts.epic.name; it.effect = opts.epic.effect;
    for (const [k, v] of Object.entries(opts.epic.fixed)) it.affixes.push({ k, v });
    rollAffixes(it, 2, opts.cls);
    if (it.dmg) { it.dmg[0] = Math.round(it.dmg[0] * 1.25); it.dmg[1] = Math.round(it.dmg[1] * 1.25); }
  } else {
    const [a, b] = RARITY[rarity].affixes; rollAffixes(it, rint(a, b), opts.cls);
  }
  it.name = it.name || itemName(it, base);
  applyKindPerk(it);
  return it;
}
// свойство вида (сборка 20): с синей редкости, ×1/×2/×3
export function applyKindPerk(it) {
  it.affixes = it.affixes.filter(a => !a.kp);
  const P = KIND_PERK[it.wt || it.slot], m = [0, 0, 1, 2, 3][it.rarity] || 0;
  if (P && m) it.affixes.unshift({ k: P.k, v: P.v * m, kp: true });
}
export const kindPerkText = it => { const P = KIND_PERK[it.wt || it.slot]; return P ? P.txt : ''; };
// Слияние: три вещи одного слота и редкости → одна следующей редкости. Вид (база) — от первой, уровень и закалка — лучшие из трёх.
export function mergeItems(list, cls) {
  const [a] = list, r = a.rarity + 1; if (r >= RARITY.length) return null;
  const ilvl = Math.max(...list.map(i => i.ilvl)), upg = Math.max(...list.map(i => i.upg || 0));
  const it = makeItem({ base: a.base, ilvl, rarity: r, cls, noClamp: true }); it.rarity = r; it.upg = upg; delete it.req;
  // золотые и мифические получают особый эффект вида (как у вещей боссов); у мифических — ещё и полный набор свойств
  if (r >= 3) { const E = EPICS.find(e => BASE[e.base].slot === a.slot && (!a.wt || BASE[e.base].wt === a.wt)) || EPICS.find(e => BASE[e.base].slot === a.slot) || (a.epic && EPICS.find(e => e.id === a.epic));
    if (E) { it.epic = E.id; it.effect = E.effect; it.name = E.name; } }
  if (r === 4) { rollAffixes(it, Math.max(0, 5 - it.affixes.filter(x => !x.kp).length), cls); it.name = 'Мифический ' + lower(it.name); }
  const keep = list.map(i => i.dmg).filter(Boolean); if (keep.length && it.dmg) it.dmg = [Math.max(it.dmg[0], ...keep.map(d => d[0])), Math.max(it.dmg[1], ...keep.map(d => d[1]))];
  const ka = list.map(i => i.armor || 0); if (it.armor) it.armor = Math.max(it.armor, ...ka);
  if (a.set) it.set = a.set;
  applyKindPerk(it); it.isNew = true;
  return it;
}
export const heroPower = P => Object.values(P.gear).reduce((a, it) => a + (it ? itemPower(it) : 0), 0) + P.level * 25;
// «Сила» вещи — одна цифра для сравнения: урон/защита × редкость × закалка + свойства
export function itemPower(it) {
  const core = it.dmg ? (it.dmg[0] + it.dmg[1]) * 2.2 : (it.armor || 0) * 3.5 + (it.slot === 'amulet' ? 12 + it.ilvl * 3 : 0);
  return Math.round(core * upgMult(it) + it.affixes.length * (6 + it.ilvl * 1.5) + it.ilvl * 4);
}

const PREFIX = { dmgPct: 'Жестокий', ias: 'Быстрый', crit: 'Точный', armor: 'Крепкий', hp: 'Живучий', fire: 'Пылающий', cold: 'Ледяной', light: 'Грозовой', str: 'Могучий', dex: 'Ловкий', int: 'Мудрый', goldFind: 'Счастливый' };
const RARE_A = ['Мрачный', 'Кровавый', 'Древний', 'Проклятый', 'Сумрачный', 'Костяной', 'Железный', 'Вечный'];
const RARE_B = ['Страж', 'Клятва', 'Шёпот', 'Рок', 'Коготь', 'Приговор', 'Завет', 'Оплот'];
function itemName(it, base) {
  if (it.rarity === 1 && it.affixes[0]) { const p = PREFIX[it.affixes[0].k]; return p ? `${agree(p, base.name)} ${lower(base.name)}` : base.name; }
  if (it.rarity >= 2) return `${pick(RARE_A)} ${pick(RARE_B).toLowerCase()} · ${base.name}`;
  return base.name;
}
const lower = s => s.charAt(0).toLowerCase() + s.slice(1);
// crude adjective agreement for feminine/neuter/plural base names
function agree(adj, noun) {
  const n = noun.split(' ').pop();
  const stem = adj.slice(0, -2);
  const soft = adj.endsWith('ий') && !/[кгхжшщч]ий$/.test(adj);
  if (/(и|ы)$/.test(n)) return stem + (soft ? 'ие' : 'ые');
  if (/(а|я)$/.test(n)) return stem + (soft ? 'яя' : 'ая');
  if (/(о|е)$/.test(n)) return stem + (soft ? 'ее' : 'ое');
  return adj;
}

export function makeStarterGear(cls = 'warrior') {
  const base = { warrior: 'short_sword', archer: 'short_bow', mage: 'oak_staff' }[cls];
  const w = makeItem({ base, ilvl: 1, rarity: 0 });
  w.name = { warrior: 'Ржавый меч', archer: 'Старый лук', mage: 'Посох ученика' }[cls];
  if (cls === 'warrior') w.dmg = [4, 7];
  const c = makeItem({ base: 'jerkin', ilvl: 1, rarity: 0 }); c.armor = 4; c.name = { warrior: 'Стёганая куртка', archer: 'Кожаная куртка', mage: 'Дорожная мантия' }[cls];
  delete w.req; delete c.req;
  return { weapon: w, chest: c };
}

// часть сета: шлем/доспех/амулет без требований, защита ×1,6 (наравне с кольчугой и латами), 1–2 свойства сверху бонусов сета
export function makeSetItem(setId, slot, ilvl, cls) {
  const S = SETS[setId]; slot = slot || SET_SLOTS[Math.floor(rand() * SET_SLOTS.length)];
  const it = makeItem({ base: SET_BASE[slot], ilvl, rarity: 1, cls });
  it.set = setId; it.name = S.parts[slot]; it.rarity = 2; delete it.req;
  if (it.armor) it.armor = Math.round(it.armor * 1.6);
  return it;
}
// какой сет выпадет классу: навыки своих ветвей чаще, золото и оплот — реже
export function pickSet(cls) { const own = Object.keys(SETS).filter(k => SETS[k].branch && SETS[k].cls.includes(cls)); const r = rand(); return r < 0.6 ? own[Math.floor(rand() * own.length)] : r < 0.8 ? 'gold' : 'guard'; }
export const baseOf = it => BASE[it.base];
export const iconOf = it => it.wt ? WEAPONS[it.wt].icon : (BASE[it.base].icon || it.slot);
export const rarityColor = it => RARITY[it.rarity].color;
export const upgMult = it => (1 + (it.upg || 0) * 0.1) * (RMUL[it.rarity] || 1);   // закалка и редкость (сборка 20)
export function affixText(a) { const A = AFFIXES[a.k]; if (!A) return ''; return A.branch ? A.name(a.v, (BRANCHES.find(b => b.id === a.b) || {}).name) : A.name(a.v); }
export function epicOf(it) { return it.epic ? EPICS.find(e => e.id === it.epic) : null; }

// Sell value & smith costs (gold sinks scale with level so they stay relevant)
export const PRICE_K = 1.1;   // сборка 20: цены вещей и закалки растут на 10% за уровень вещи — с той же скоростью, что и опыт до уровня
export function sellValue(it) { return Math.round((4 + it.ilvl * 3) * [1, 2.5, 6, 15, 40][it.rarity] * (1 + (it.upg || 0) * 0.3)); }
export function upgradeCost(it) { const u = it.upg || 0; return Math.round((30 + it.ilvl * 12) * Math.pow(1.55, u) * [1, 1.3, 1.7, 2.5, 3.5][it.rarity] * Math.pow(PRICE_K, it.ilvl - 1)); }
export function reforgeCost(it) { return Math.round((50 + it.ilvl * 20) * [1, 1.2, 1.6, 2.4, 3.2][it.rarity] * Math.pow(PRICE_K, it.ilvl - 1)); }
export const MAX_UPG = 10;
