// Daily quests (3 per day) and «Дозор Ордена» — progress while the player is away.
import { G, bus } from './ctx.js';
import { xpToNext } from './stats.js';
import { gainXP } from './loot.js';
import { makeItem } from './items.js';
import { autoEquip } from './character.js';
import { weekNo } from './season.js';
import { gate } from './progress.js';
import { REALMS } from '../data/wild.js';

// сборка 47: задания дня чередуются, как дейлики в WoW: слияние, Жатва, Летопись, форты — только то, что уже открыто по сюжету
const boss = () => !!(G.profile.story.flags && G.profile.story.flags.bossKilled);
const POOL = [
  { id: 'kill', stat: 'kills', n: [30, 60], t: n => `Destrua ${n} inimigos` },
  { id: 'floors', stat: 'floors', n: [1, 3], t: n => `Vença ${n} ${n === 1 ? 'andar' : 'andares'} das Profundezas`, need: P => P.depths && P.depths.best > 0 },
  { id: 'gold', stat: 'gold', n: [150, 400], t: n => `Junte ${n} de ouro` },
  { id: 'upg', stat: 'upgrades', n: [1, 2], t: n => n === 1 ? 'Tempere um item com o ferreiro' : `Tempere itens com o ferreiro ${n} vezes` },
  { id: 'chest', stat: 'chests', n: [2, 4], t: n => `Abra ${n} baús` },
  { id: 'elite', stat: 'elites', n: [1, 3], t: n => `Derrote ${n} inimigos de elite` },
  { id: 'stars', stat: 'stars3', n: [1, 1], t: () => 'Vença um andar com ★★★', need: P => P.depths && P.depths.best > 0 },
  { id: 'merge', stat: 'merges', n: [1, 1], t: () => 'Funda 3 itens em um com o ferreiro' },
  { id: 'surv', stat: 'survSec', n: [300, 300], t: () => 'Sobreviva 5 minutos na Colheita do Abismo', need: () => boss() },
  { id: 'hw', stat: 'hwWins', n: [3, 5], t: n => `Vença ${n} lutas da Crônica de Batalhas` },
  { id: 'fort', stat: 'forts', n: [1, 1], t: () => 'Retome um forte numa expedição (floresta, fiordes ou ermos)', need: () => boss() },
];
bus.on('kill', e => { if (e && e.story === 'wildkeep') { const S = G.profile.stats; S.forts = (S.forts || 0) + 1; } });
// П38 (правки 2): задания по открытым местам — каждый день 2 из 3 ведут в разные уже открытые локации (лес, фьорды, пустоши, храм,
// катакомбы с возрождающимися Хранителем и Палачом), неделя — одно крупное дело в одной из них. Счётчики — P.stats.k_<место>, fort_<поход>
const SPOT = { forest: 'Floresta Antiga', fjord: 'Fiordes', bones: 'Ermos de Ossos', temple: 'Templo em ruínas' };
const opened = r => !gate(r) && G.profile.level >= REALMS[r].reqLevel && !!(G.profile.wild && G.profile.wild[r] && G.profile.wild[r].depth);   // открыт и герой там уже был
const fortsIn = r => { const S = G.profile.wild && G.profile.wild[r]; return (S && S.stat && S.stat.forts) || 0; };
bus.on('kill', e => {
  const P = G.profile; if (!P || !e || e.summoned) return; const S = P.stats, inc = k => { S[k] = (S[k] || 0) + 1; };
  if (G.zoneId === 'wild' && G.wild) { inc('k_' + G.wild.realm); if (e.story === 'wildkeep' || e.story === 'wildboss') inc('fort_' + G.wild.realm); }
  if (G.zoneId === 'catacombs') { inc('k_cata'); if (e.story === 'elite' || e.story === 'boss') inc('k_cataBoss'); }
});
const LOC = [
  ...Object.keys(SPOT).map(r => ({ id: 'l_' + r, loc: 1, stat: 'k_' + r, n: [20, 35], t: n => `${SPOT[r]}: mate ${n} inimigos`, need: () => opened(r) })),
  ...['forest', 'fjord', 'bones'].map(r => ({ id: 'lf_' + r, loc: 1, stat: 'fort_' + r, n: [1, 1], t: () => `${SPOT[r]}: retome ${REALMS[r].fortName.toLowerCase()} mais uma vez`, need: () => opened(r) && fortsIn(r) > 0 })),
  { id: 'l_cata', loc: 1, stat: 'k_cata', n: [20, 35], t: n => `Catacumbas: dê descanso a ${n} mortos-vivos`, need: P => (P.story.done || []).includes('enter') },
  { id: 'l_cboss', loc: 1, stat: 'k_cataBoss', n: [1, 1], t: () => 'Catacumbas: derrote de novo o Guardião ou o Carrasco', need: P => !!P.story.flags.eliteKilled },
];
bus.on('hwWin', () => { const S = G.profile.stats; S.hwWins = (S.hwWins || 0) + 1; });
const dayKey = () => { const d = new Date(); return d.getFullYear() * 10000 + (d.getMonth() + 1) * 100 + d.getDate(); };
function seeded(seed) { let s = seed; return () => (s = (s * 16807) % 2147483647) / 2147483647; }

export function dailyQuests() {
  const P = G.profile, today = dayKey();
  if (!P.dq || P.dq.day !== today) {
    const R = seeded(today % 2147483646 + 1); const ok = q => !q.need || q.need(P);
    const loc = [...LOC].sort(() => R() - 0.5).filter(ok).slice(0, 2), gen = [...POOL].sort(() => R() - 0.5).filter(ok);   // П38: два дела в открытых местах + одно общее
    const list = [...loc, ...gen].slice(0, 3);
    P.dq = { day: today, bonus: false, list: list.map(q => { const n = q.n[0] + Math.floor(R() * (q.n[1] - q.n[0] + 1)); return { id: q.id, stat: q.stat, n, base: P.stats[q.stat] || 0, claimed: false }; }) };
    bus.emit('save');
  }
  return P.dq.list.map(q => { const def = POOL.find(p => p.id === q.id) || LOC.find(p => p.id === q.id); const cur = Math.min(q.n, Math.floor((G.profile.stats[q.stat] || 0) - q.base)); return { ...q, title: def.t(q.n), cur, done: cur >= q.n }; });
}
export const dqReward = () => ({ gold: 40 + G.profile.level * 20, potions: 1 });
export function claimDaily(id) {
  const P = G.profile; const list = dailyQuests(); const q = list.find(x => x.id === id); if (!q || !q.done || q.claimed) return false;
  P.dq.list.find(x => x.id === id).claimed = true; bus.emit('dailyClaimed');
  const r = dqReward(); P.gold += r.gold; P.potions.hp += r.potions;
  bus.emit('toast', { text: 'Missão diária concluída', sub: `+${r.gold} ouro · +${r.potions} poção`, kind: 'good' }); bus.emit('sfx', 'quest');
  if (P.dq.list.every(x => x.claimed) && !P.dq.bonus) {
    P.dq.bonus = true; bus.emit('dailyAllDone'); const it = makeItem({ ilvl: P.level + 1, rarity: 1, cls: P.cls }); delete it.req;
    const e = autoEquip(it); P.gold += 100 * P.level;
    bus.emit('reward', { title: 'Baú Diário', sub: 'Todas as missões diárias concluídas', gold: 100 * P.level, xp: 0, potions: 0, scrolls: 0, skillPts: 0, items: [e] });
  }
  bus.emit('hud'); bus.emit('save'); return true;
}
export const dailyReady = () => G.profile && dailyQuests().some(q => q.done && !q.claimed);

// ---- Dozor: the Order keeps patrolling the depths while you're away (max 8 h)
export const DOZOR_CAP = 8 * 3600e3;
export function dozorPending() {
  const P = G.profile; if (!P.depths || !P.depths.best) return null;
  const last = P.dozorAt || P.saved || Date.now(); const ms = Math.min(DOZOR_CAP, Date.now() - last);
  if (ms < 10 * 60e3) return null;
  const h = ms / 3600e3;
  return { ms, gold: Math.round((30 + 15 * P.depths.best + 10 * P.level) * h), xp: Math.round(xpToNext(P.level) * 0.05 * h) };
}
export function claimDozor(mult = 1) {
  const P = G.profile; const d = dozorPending(); if (!d) return null;
  P.dozorAt = Date.now(); P.gold += d.gold * mult; gainXP(d.xp * mult);
  bus.emit('hud'); bus.emit('save'); return d;
}
export function initDozor() { const P = G.profile; if (!P.dozorAt) P.dozorAt = Date.now(); }

// ---- weekly quests (bigger goals, bigger rewards incl. Abyss shards)
const WPOOL = [
  { id: 'wkill', stat: 'kills', n: 400, t: n => `Destrua ${n} inimigos` },
  { id: 'wfloor', stat: 'floors', n: 8, t: n => `Vença ${n} andares das Profundezas` },
  { id: 'welite', stat: 'elites', n: 10, t: n => `Derrote ${n} inimigos de elite` },
  { id: 'wgold', stat: 'gold', n: 3000, t: n => `Junte ${n} de ouro` },
  { id: 'wupg', stat: 'upgrades', n: 5, t: n => `Tempere itens ${n} vezes` },
  { id: 'wchest', stat: 'chests', n: 15, t: n => `Abra ${n} baús` },
  { id: 'wmerge', stat: 'merges', n: 5, t: n => `Faça ${n} fusões com o ferreiro` },
  { id: 'whw', stat: 'hwWins', n: 15, t: n => `Vença ${n} lutas da Crônica de Batalhas` },
  // П38: крупное дело в одном из открытых мест
  ...Object.keys(SPOT).map(r => ({ id: 'wl_' + r, loc: 1, stat: 'k_' + r, n: 150, t: n => `${SPOT[r]}: mate ${n} inimigos`, need: () => opened(r) })),
  ...['forest', 'fjord', 'bones'].map(r => ({ id: 'wf_' + r, loc: 1, stat: 'fort_' + r, n: 3, t: n => `${SPOT[r]}: tome ${REALMS[r].fortName.toLowerCase()} ${n} vezes`, need: () => opened(r) && fortsIn(r) > 0 })),
  { id: 'wl_cboss', loc: 1, stat: 'k_cataBoss', n: 4, t: n => `Catacumbas: derrote o Guardião ou o Carrasco ${n} vezes`, need: P => !!P.story.flags.eliteKilled },
];
const weekKey = () => weekNo();   // С18: номер недели с эпохи (старый «год·100 + неделя» под Новый год давал две разные недели за два дня)
export const wqReward = () => ({ gold: 150 + G.profile.level * 60, shards: 3 });
export function weeklyQuests() {
  const P = G.profile, wk = weekKey();
  if (P.wq && P.wq.week > 100000) P.wq.week = wk;   // С18: старый формат ключа — неделю не сбрасываем
  if (!P.wq || P.wq.week !== wk) { const R = seeded(wk), ok = q => !q.need || q.need(P), all = [...WPOOL].sort(() => R() - 0.5).filter(ok); const picks = [...all.filter(q => q.loc).slice(0, 1), ...all.filter(q => !q.loc)].slice(0, 3); P.wq = { week: wk, list: picks.map(q => ({ id: q.id, stat: q.stat, n: q.n, base: P.stats[q.stat] || 0, claimed: false })) }; }
  return P.wq.list.map(q => { const def = WPOOL.find(p => p.id === q.id); const cur = Math.min(q.n, Math.floor((P.stats[q.stat] || 0) - q.base)); return { ...q, title: def.t(q.n), cur, done: cur >= q.n }; });
}
export function claimWeekly(id) {
  const P = G.profile, q = weeklyQuests().find(x => x.id === id); if (!q || !q.done || q.claimed) return false;
  P.wq.list.find(x => x.id === id).claimed = true; bus.emit('weeklyClaimed'); const r = wqReward(); P.gold += r.gold; P.shards = (P.shards || 0) + r.shards;
  bus.emit('toast', { text: 'Missão semanal concluída', sub: `+${r.gold} ouro · +${r.shards}◆`, kind: 'good' }); bus.emit('sfx', 'quest'); bus.emit('hud'); bus.emit('save'); return true;
}
