// Удержание (сборка 21): путь сезона, коллекция вещей, испытание недели, «до цели».
// Путь сезона — бесплатный, на календарный месяц: 30 ступеней, очки за любую игру. Новый месяц — новый сезон (награды не сгорают:
// забранное остаётся, незабранное прошлого сезона пропадает). Коллекция — каждая впервые найденная вещь (вид × редкость от зелёной) даёт
// +0,5% к урону и здоровью навсегда. Испытание недели — особый этаж Глубин со своим правилом, рекорд времени — в таблицу Яндекса.
import { G, bus } from './ctx.js';
import { makeItem, maxRarityFor } from './items.js';
import { autoEquip } from './character.js';
import { mergeGroups, mergeCost } from './economy.js';
import { BASES, CLASSES, RARITY } from '../data/items.js';
import { platform } from '../platform/platform.js';

// ---------------------------------------------------------------- путь сезона
export const SEASON_LEVELS = 30;
export const seasonNeed = l => 150 + 5 * l;   // очков на ступень l (1…30): весь путь ≈ 6 800 очков ≈ 70% заданий дня за ~22 дня
const MONTHS = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];
const seasonId = () => { const d = new Date(); return d.getFullYear() * 100 + d.getMonth() + 1; };
export const seasonName = () => MONTHS[new Date().getMonth()];
export function season() {
  const P = G.profile, id = seasonId();
  if (!P.season || P.season.id !== id) P.season = { id, pts: 0, claimed: {} };
  return P.season;
}
export function seasonLevel() { const S = season(); let l = 0, left = S.pts; while (l < SEASON_LEVELS && left >= seasonNeed(l + 1)) { left -= seasonNeed(l + 1); l++; } return { lvl: l, into: left, need: l < SEASON_LEVELS ? seasonNeed(l + 1) : 0 }; }
export function seasonReward(l) {
  if (l % 10 === 0) return { gold: 300, potions: 5, scrolls: 2, item: l === 30 ? 3 : l === 20 ? 3 : 2, label: l === 10 ? 'Item Azul' : 'Item Dourado', big: true };
  if (l % 5 === 0) return { gold: 120, potions: 3, scrolls: 1, fodder: 3, label: '3 itens para fundir e um pergaminho', mid: true };
  return { gold: 50, potions: l % 2 ? 1 : 0, label: 'Ouro' + (l % 2 ? ' e poção' : '') };
}
export function addSeason(n, why) {
  if (!G.profile || !(n > 0)) return; const before = seasonLevel().lvl; season().pts += n; const after = seasonLevel().lvl;
  if (after > before) { bus.emit('toast', { text: `Trilha da Temporada: nível ${after}!`, sub: `Recompensa aguardando: ${seasonReward(after).label} (menu → Trilha da Temporada)`, kind: 'quest' }); bus.emit('sfx', 'levelup'); bus.emit('hud'); }
}
export const seasonClaimable = () => { const S = season(), L = seasonLevel().lvl; let n = 0; for (let l = 1; l <= L; l++) if (!S.claimed[l]) n++; return n; };
export function claimSeason(l) {
  const P = G.profile, S = season(); if (S.claimed[l] || seasonLevel().lvl < l) return false;
  const r = seasonReward(l); S.claimed[l] = Date.now();
  P.gold += r.gold * P.level; P.potions.hp += r.potions || 0; P.scrolls += r.scrolls || 0;
  for (let i = 0; i < (r.fodder || 0); i++) P.bag.push(makeItem({ ilvl: P.level, rarity: 0, cls: P.cls, slot: ['weapon', 'head', 'chest'][i % 3] }));
  if (r.item) { const it = makeItem({ ilvl: P.level, rarity: Math.min(r.item, Math.max(2, maxRarityFor(P.level))), cls: P.cls }); delete it.req; autoEquip(it); }
  bus.emit('toast', { text: `Temporada: recompensa do nível ${l}`, sub: r.label, kind: 'good' }); bus.emit('sfx', 'quest'); bus.emit('hud'); bus.emit('save'); return true;
}
// сборка 47: очки — только за задания (раньше за каждого врага: путь на месяц проходился за вечер).
// Задание дня 100, все три за день +50, вход в игру 10, недельное задание 150. При 70% заданий путь (≈6800 очков) — около 22 дней
export const SEASON_PTS = { daily: 100, dailyAll: 50, login: 10, weekly: 150 };
bus.on('dailyClaimed', () => addSeason(SEASON_PTS.daily));
bus.on('dailyAllDone', () => addSeason(SEASON_PTS.dailyAll));
bus.on('weeklyClaimed', () => addSeason(SEASON_PTS.weekly));
bus.on('loginClaimed', () => addSeason(SEASON_PTS.login));

// ---------------------------------------------------------------- коллекция
export const CODEX_PCT = 0.5;
export const codexKey = it => `${it.base}:${it.rarity}`;
export function codexBases(cls) { const C = CLASSES[cls || 'warrior']; return BASES.filter(b => ['weapon', 'head', 'chest', 'amulet'].includes(b.slot) && (!b.wt || C.weapons.includes(b.wt))); }
export function codexScan() {
  const P = G.profile; if (!P) return 0; P.codex = P.codex || {}; let added = 0;
  for (const it of [...Object.values(P.gear), ...P.bag]) if (it && it.rarity >= 1 && !P.codex[codexKey(it)]) { P.codex[codexKey(it)] = Date.now(); added++;
    bus.emit('toast', { text: `Coleção: ${it.name}`, sub: `Novo registro (${RARITY[it.rarity].name.toLowerCase()}) — +${CODEX_PCT}% de dano e vida para sempre`, kind: 'item', color: RARITY[it.rarity].color }); }
  if (added) bus.emit('codexChanged');
  return added;
}
export const codexCount = P => Object.keys(P.codex || {}).length;
bus.on('itemPicked', () => setTimeout(codexScan, 0)); bus.on('merged', () => setTimeout(codexScan, 0)); bus.on('equipChanged', () => setTimeout(codexScan, 0));

// ---------------------------------------------------------------- испытание недели (Глубины)
export const WEEKLY_RULES = [
  { id: 'swift', name: 'Sombras Velozes', txt: 'Inimigos 30% mais rápidos · ouro ×2', spd: 1.3, gold: 2 },
  { id: 'iron', name: 'Guarda de Ferro', txt: 'Inimigos com +60% de vida · XP ×2', hp: 1.6, xp: 2 },
  { id: 'horde', name: 'Horda', txt: 'O dobro de inimigos · itens caem o dobro', count: 2, items: 2 },
  { id: 'fury', name: 'Fúria', txt: 'Inimigos batem 40% mais forte · ouro e XP ×1,5', dmg: 1.4, gold: 1.5, xp: 1.5 },
];
export const weekNo = () => Math.floor((Date.now() / 864e5 + 3) / 7);   // неделя с понедельника
export const weeklyRule = () => WEEKLY_RULES[weekNo() % WEEKLY_RULES.length];
export function weeklyState() { const P = G.profile, w = weekNo(); if (!P.weekly || P.weekly.week !== w) P.weekly = { week: w, best: 0, done: false }; return P.weekly; }
export const weeklyFloor = lvl => Math.max(2, Math.round((lvl - 1) / 0.85));   // этаж, уровень врагов которого ≈ уровню героя
// Круги Бездны (сборка 45, после Главы IV): выбранный круг делает Глубины злее и богаче.
// Круг 0 — как раньше. Множители на круг k: HP ×1,45^k, урон ×1,28^k, золото и опыт ×(1 + 0,55k), +5k% к шансу вещи.
export const CIRCLE_MAX = 10;
export const circlesOpen = () => !!(G.profile && G.profile.storyDone);
export const circle = () => (circlesOpen() && (G.profile.circle | 0)) || 0;
export const circleHP = k => Math.pow(1.45, k), circleDmg = k => Math.pow(1.28, k), circleRew = k => 1 + 0.55 * k + 0.2 * k * k;   // сборка 49: награда догоняет риск (было линейно: на 3 круге враги ×6,4, награда ×2,65 → теперь ×4,5)
export function setCircle(k) { const P = G.profile; P.circle = Math.max(0, Math.min(CIRCLE_MAX, k | 0)); bus.emit('save'); bus.emit('hud'); }
export const rm = k => ((G.run && G.run.weekly && G.run.weekly[k]) || 1) * ((G.run && G.run.mod && G.run.mod[k]) || 1);   // + модификатор этажа (сборка 49)   // множитель правила недели в текущем забеге
export function finishWeekly(time) {
  const P = G.profile, W = weeklyState(), first = !W.done, rec = !W.best || time < W.best;
  W.done = true; if (rec) W.best = time;
  if (first) { P.gold += 200 * P.level; const it = makeItem({ ilvl: P.level + 1, rarity: Math.max(2, Math.min(3, maxRarityFor(P.level))), cls: P.cls }); delete it.req; autoEquip(it); }
  try { platform.p.setLeaderboardScore && platform.p.setLeaderboardScore('weeklyDepths', Math.round(time * 1000)); } catch { }
  return { first, rec };
}

// ---------------------------------------------------------------- «до цели»: одна ближайшая цель на главном экране
export function nextGoalLine() {
  const P = G.profile; if (!P) return '';
  // П52: напоминание по тем же правилам, что у кузнеца (класс, 🔒, уровень героя для следующей редкости, золото) — раньше звало, когда слить было нельзя
  const groups = mergeGroups().filter(g => !g.capLvl);
  if (groups.some(g => g.can && P.gold >= mergeCost(g.rarity))) return '⚒ Ferreiro: funda 3 itens em 1 melhor';
  const two = groups.find(g => g.n % 3 === 2);
  if (two) return `⚒ Mais 1 item ${['cinza', 'verde', 'azul', 'dourado'][two.rarity]} (${{ weapon: 'arma', head: 'elmo', chest: 'armadura', amulet: 'amuleto' }[two.slot]}) para fundir`;
  const s = seasonLevel(); if (s.lvl < SEASON_LEVELS) return `🏆 Temporada: ${s.into}/${s.need} até o nível ${s.lvl + 1} (${seasonReward(s.lvl + 1).label})`;
  return '';
}
