// Сквозная последовательность игры: что открыто и что делать дальше. Единственное место с правилами «замков».
// 1) выбрать первый навык → 2) катакомбы → 3) Старый Лес (уровень 3) → 4) Палач Бездны (уровень 6) →
// 5) Глубины / Выживание / Фьорды (после босса) → 6) Костяные пустоши (после форта Фьордов, Глава III) →
// 7) Цитадель и Морвен (Глава IV). «Летопись битв» открывается по главам вместе с этим.
import { G, bus } from './ctx.js';
import { STORY } from '../data/quests.js';

export const BOSS_LEVEL = 7;
// сборка 47: уровни зон «как в Diablo». У каждой локации свой коридор уровней врагов [от, до]: внутри коридора враг
// всегда на 1 уровень выше героя (≈ +20–30% к здоровью и урону), ниже «от» не опускается (слабым героем рано не пройти),
// выше «до» не растёт — перекачанный герой получает всё меньше опыта (killXP в loot.js) и уходит дальше.
// Катакомбы до первого прохождения — 1–7 (комната задаёт «от»), Хранитель 6–8, Палач 7–10; Глубины и походы — от уровня этажа/поля до него +3.
export const CATA_MAX = 7;
// П57 (правки 2): перекачанный герой больше не проходит зону «одной левой». Боссы, стражи и сюжетные враги (boss = true) всегда
// на уровень выше героя (без потолка зоны); рядовые — в коридоре, но не ниже «герой − 3» (опыта с них уже ×0,3 — повод идти дальше)
export const bandLevel = (min, max, boss) => { const h = (G.profile && G.profile.level) || 1; return boss ? Math.max(min, h + 1) : Math.max(min, Math.min(max, h + 1), h - 3); };
const F = () => G.profile.story.flags;
export const hasSkill = () => G.profile.slots.some(Boolean) || Object.keys(G.profile.skills).length > 0;
const forts = realm => { const S = G.profile.wild && G.profile.wild[realm]; return S && S.stat ? S.stat.forts || 0 : 0; };

// сборка 47: первые шаги без «ускорителей». Пока герой не прошёл Летопись и не вернулся с золотом к Элвину,
// усиления у Элвина закрыты ('upg'); пока не купил первое зелье у Миры — закрыты Источник силы, Хозяйка Колеса,
// реклама за награды и покупки за рубли ('extra'), Мира — до своего шага ('shop'). Иначе игрок сразу всё вкачивает и ломает баланс.
const stIdx = id => STORY.findIndex(q => q.id === id);
export function earlyLock(kind) {
  const s = G.profile && G.profile.story; if (!s) return false;
  const need = kind === 'upg' ? 'hw_elvin' : kind === 'shop' ? 'meet_merchant' : kind === 'pet' ? 'meet_kofi' : 'elder_task';   // 'pet' — подарок Кофи (сборка 60, П15)
  return s.stage < stIdx(need);
}
// сборка 55: первый урок у Элвина платный (55 зол.): после него остаётся ровно на первое зелье здоровья у Миры (30).
// Пока зелье не куплено, другие покупки, после которых на зелье не хватит, не проходят — шаг обучения не застрянет.
export const POTION_RESERVE = 30;
export const firstLessonCost = () => !G.profile || Object.values(G.profile.skills || {}).some(Boolean) ? 0 : Math.max(0, Math.min(55, (G.profile.gold | 0) - POTION_RESERVE));
export function potionReserve(cost) {   // true — покупка запрещена (и показана подсказка)
  const s = G.profile && G.profile.story, q = s && STORY[s.stage]; if (!q || (q.id !== 'learn_skill' && q.id !== 'meet_merchant')) return false;
  if (q.id === 'meet_merchant' && (G.profile.gold | 0) - cost >= POTION_RESERVE) return false;
  bus.emit('toast', q.id === 'learn_skill' ? { text: 'Primeiro, a primeira aula com Elvin', sub: 'Esse ouro é para a aula e uma poção de vida', kind: 'warn' } : { text: 'Primeiro, uma poção de vida da Mira', sub: 'Esse ouro é para a poção', kind: 'warn' });
  bus.emit('sfx', 'deny'); return true;
}
let lockT = 0;
export function lockToast(kind) {
  if (Date.now() - lockT < 2000) return; lockT = Date.now();
  bus.emit('toast', { text: kind === 'upg' ? 'Melhorias liberam após a Crônica de Batalhas' : 'Libera um pouco mais tarde', sub: 'Termine o tutorial primeiro — siga a seta', kind: 'warn' }); bus.emit('sfx', 'deny');
}
// null — можно, иначе { text, sub }
// сборка 59: обучение не обойти — Летопись, Жатва и катакомбы открываются своим шагом сюжета (раньше вход открывался по навыку,
// и в Жатву/катакомбы можно было зайти до задания: шаг потом засчитывался сам или стрелка вела не туда)
const early = id => G.profile.story && G.profile.story.stage < stIdx(id);
const EARLY = { text: 'Ainda não', sub: 'Primeiro as missões da vila — siga a seta dourada' };
export function gate(name, extra) {
  const P = G.profile;
  if ((name === 'catacombs' && early('find_portal')) || (name === 'survival' && early('surv_try')) || (name === 'hw' && early('hw_try'))) return EARLY;
  switch (name) {
    case 'catacombs': return hasSkill() ? null : { text: 'Escolha uma habilidade primeiro', sub: 'Fale com o mentor na vila (marcado com «+») e aprenda sua primeira habilidade' };
    case 'temple': return null;   // Разрушенный храм (портал с руками): открыт сразу со 2 уровня (уровень проверяет портал)
    case 'forest': return !hasSkill() ? { text: 'Escolha uma habilidade primeiro', sub: 'O mentor da vila ensina as primeiras habilidades' } : !F().medallion && !P.world.hasMedallion ? { text: 'A floresta está fechada por enquanto', sub: 'Leve ao Ancião o Amuleto do Guardião das Catacumbas — ele abre a trilha para a floresta' } : null;
    case 'bones': return !F().bossKilled ? { text: 'Os Ermos estão fechados', sub: 'Primeiro derrote o Carrasco do Abismo nas Catacumbas' } : forts('fjord') < 1 ? { text: 'Os Ermos de Ossos estão fechados', sub: 'Primeiro retome o forte do jarl nos Fiordes — o jötunn moribundo revelará o quarto selo' } : null;
    case 'fjord': return !F().bossKilled ? { text: 'Os Fiordes estão fechados', sub: 'Primeiro derrote o Carrasco do Abismo nas Catacumbas' } : forts('forest') < 1 ? { text: 'Os Fiordes estão fechados', sub: 'Primeiro retome a paliçada dos bandidos na Floresta Antiga' } : null;
    case 'depths': return F().bossKilled ? null : { text: 'Bloqueado por enquanto', sub: 'Primeiro derrote o Carrasco do Abismo nas Catacumbas' };
    case 'survival': return F().bossKilled || !P.survIntro ? null : { text: 'Ancião: «Não dá para segurar o portal da Colheita por mais de três minutos»', sub: 'Ele reabre após você derrotar o Carrasco do Abismo nas Catacumbas' };   // сборка 47: один забег-знакомство до Палача
    case 'bossgate': return P.level >= BOSS_LEVEL ? null : { text: `O selo não cede: requer nível ${BOSS_LEVEL}`, sub: `Você está no ${P.level}. Fique mais forte nas Catacumbas e na Floresta Antiga, melhore o equipamento com o ferreiro` };
    case 'hw': { const s = extra | 0;
      if (!hasSkill()) return { text: 'Primeiro escolha uma habilidade com o mentor' };
      if (s > 10 && !F().bossKilled) return { text: 'Etapa bloqueada', sub: 'Etapas 11+ liberam após derrotar o Carrasco do Abismo nas Catacumbas' };   // сборка 44: 6–10 открыты сразу (было — с 6-го)
      if (s > 30 && forts('forest') < 1) return { text: 'Capítulo «Floresta Antiga» bloqueado', sub: 'Retome a paliçada na Floresta Antiga' };
      if (s > 60 && forts('fjord') < 1) return { text: 'Capítulo «Fiordes» bloqueado', sub: 'Retome o forte nos Fiordes' };
      if (s > 90 && !(P.depths && P.depths.best >= 5)) return { text: 'Capítulo «Penhascos de Cinzas» bloqueado', sub: 'Chegue ao andar 5 das Profundezas' };
      return null; }
  }
  return null;
}
// П37 (правки 2): Старый Лес до победы над Палачом — только первые три поля (там задания старосты: Шатун-людоед, волки);
// дальше в лес и к острогу — после Палача Бездны. null — можно
export const FOREST_FREE = 3;
export function wildDepthGate(realm, depth) {
  if (realm === 'forest' && depth > FOREST_FREE && !(G.profile.story.flags.bossKilled)) return { text: 'O matagal não deixa avançar', sub: `Enquanto o Carrasco do Abismo viver, só é possível ir até o campo ${FOREST_FREE} da floresta. Quebre o selo nas catacumbas` };
  return null;
}
// Текст «что делать дальше» для подсказок
export function nextStep() {
  const P = G.profile;
  if (!hasSkill()) return 'Escolha sua primeira habilidade com o mentor';
  if (!F().medallion && !P.world.hasMedallion) return 'Catacumbas: chave → porta → derrote o Guardião → amuleto ao Ancião';
  if (!F().bossKilled) return P.level < BOSS_LEVEL ? `Chegue ao nível ${BOSS_LEVEL} (Catacumbas, Floresta Antiga)` : 'Derrote o Carrasco do Abismo';
  if (forts('forest') < 1) return 'Retome a paliçada na Floresta Antiga';
  if (forts('fjord') < 1) return 'Retome o forte nos Fiordes';
  if (forts('bones') < 1) return 'Ermos de Ossos: chegue às ruínas e derrote o chefe';
  return 'Vá mais fundo: Profundezas, Colheita do Abismo, Cidadela';
}
