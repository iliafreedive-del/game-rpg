// Объяснялка похода: короткие карточки ровно в тот момент, когда правило впервые важно (1–3 строки, один раз),
// постоянная строка цели и «зацепки» при возвращении в деревню. Флаги показа — profile.wild.hints.
import { G, bus } from './ctx.js';
import { REALMS, WILD_QUESTS, locationName, wildReqLevel } from '../data/wild.js';
import { outsideLeft } from './wild.js';
import { nearestCache, dirWord } from './wildmem.js';
import { hunted, displayName, WEAK } from './nemesis.js';

const HINTS = {
  enter: ['Como funcionam as expedições', ['🎯 Cinco campos seguidos, a sexta área é um forte: mate as feras ao redor para abrir os portões e depois mate o comandante.', '🔒 O portal "Mais Fundo" deste campo fica selado enquanto o líder do campo viver — a seta leva até ele.', '🎒 O ouro cai na sua carga: ele é seu quando o forte é retomado ou você sai por um portal.', '☠ O comandante é seu inimigo pessoal: perca, e ele vai se lembrar de você.']],
  carry: ['Esta é sua carga', ['O ouro ainda não está na bolsa. Morrer o faz perder.', 'Uma carga pesada o deixa lento e atrai inimigos. Retome o forte ou saia por um portal e ela é sua.']],
  nemesis: ['O comandante do forte é um inimigo especial', ['Ele é mais forte que os outros e se lembra de você: se você morrer ou fugir, ele volta ainda mais furioso.', 'Mate o comandante para ganhar um troféu permanente: um pouco mais de dano e ouro.']],
  cache: ['Esconderijo ▣ — um cofre no meio do campo', ['O ouro da expedição fica na sua carga 🎒: enquanto está no campo, a morte o leva, e uma carga pesada o deixa lento e atrai monstros.', 'Vá até o ▣ e toque em "Esconderijo": toda a carga vai de uma vez para a bolsa, mas o esconderijo fica com 15% (25% se o campo se lembrar da sua ganância).', 'Não é preciso se você vai terminar o forte — ele guarda a carga de graça.']],
  echo: ['Ecos dos Caídos', ['Silhuetas translúcidas de heróis são rastros de quem caiu aqui (são ecos, não jogadores reais).', 'Aproxime-se e toque em "Eco": ganhe um pouco de ouro e uma dica de perigo.', 'Se você cair, seu Eco fica no local e devolve ¼ da carga perdida.']],
  dead: ['O que aconteceu', ['Carga perdida — o nêmesis a levou. Derrote-o para recuperar tudo e ganhar um troféu.']],
};
let card = null, queue = [], timer = 0;
const seen = () => { const P = G.profile; P.wild = P.wild || {}; return (P.wild.hints = P.wild.hints || {}); };

function render() {
  if (card || !queue.length) return;
  const [title, lines] = queue.shift();
  card = document.createElement('div');
  card.style.cssText = 'position:fixed;inset:0;z-index:60;background:rgba(0,0,0,.45);display:flex;align-items:center;justify-content:center;pointer-events:auto';
  const inner = document.createElement('div'); inner.style.cssText = 'max-width:340px;width:calc(100% - 24px);background:rgba(20,14,26,.94);border:1px solid #d6a548;border-radius:10px;padding:10px 12px;font:14px/1.35 Georgia,serif;color:#efe2c0;box-shadow:0 4px 18px #000a';
  inner.innerHTML = `<div style="font-weight:700;color:#e8c26a;margin-bottom:4px">${title}</div>${lines.map(l => `<div style="margin:3px 0">${l}</div>`).join('')}`; card.appendChild(inner);
  const b = document.createElement('button'); b.textContent = 'Entendi'; b.className = 'btn sm gold'; b.style.cssText = 'margin-top:6px;pointer-events:auto';
  const close = () => { if (!card) return; card.remove(); card = null; clearTimeout(timer); if (!G.modalOpen) G.paused = false; setTimeout(render, 300); };
  b.onclick = close; inner.appendChild(b); document.body.appendChild(card); if (!G.paused) G.paused = true;   // пока карточка на экране — игра на паузе (враги не бьют, пока вы читаете)
}
export function hint(id) {
  const S = seen(); if (S[id] || !HINTS[id]) return; S[id] = 1; queue.push(HINTS[id]); render(); bus.emit('save');
}
bus.on('zoneEntered', id => { if (card) { card.remove(); card = null; G.paused = false; } queue.length = 0; if (id === 'wild') setTimeout(() => hint('enter'), 700); if (id === 'town') setTimeout(townHooks, 1400); });
bus.on('aggro', e => { if (e.nem) setTimeout(() => hint('nemesis'), 400); });
bus.on('showDeath', () => { if (G.zoneId === 'wild') hint('dead'); });

// Строка цели (под шкалой ноши)
export function goalText() {
  const W = G.wild; if (!W) return '';
  if (W.greed >= 0.5) { const c = nearestCache(); if (c) return `▣ Esconderijo: ${Math.round(c.d)} m ${dirWord(c.it.x - G.player.x, c.it.y - G.player.y)} — guarde sua carga`; }   // коротко: строка висит всё время
  if (G.zone && G.zone.json.wild.kind === 'field' && G.zone.inter.some(i => i.id === 'wild_next' && i.sealed)) return W.realm === 'temple' ? '🔒 "Mais Fundo" está selado: derrote o guardião do santuário no centro do templo (a seta leva até ele)' : '🔒 "Mais Fundo" está selado: derrote o líder do campo (a seta leva até ele)';   // П20
  if (G.zone && G.zone.json.wild.kind === 'field') { const nd = W.depth + 1; return `🎯 Vá ao portal "Mais Fundo" (seta no chão) — próxima área: ${locationName(W.realm, nd)}, Nv. ${wildReqLevel(W.realm, nd)}+`; }
  if (G.zone && G.zone.wildGate && !G.zone.wildGate.open) return `🎯 Portões do forte fechados: mate as feras e acampamentos ao redor (faltam ${outsideLeft()})`;
  if (!W.done) { const k = G.enemies.find(e => (e.story === 'wildkeep' || e.story === 'wildboss') && !e.dead); return k ? `🎯 Retome o forte: mate ${k.nem ? k.nem.name : k.D.name} (a seta leva até ele)` : ''; }
  return '🎯 Forte retomado, o ouro já é seu. Pegue os baús; quando estiver pronto — botão à direita (resumo) ou portal "Mais Fundo" / "Para a Vila"';
}

// Что делать дальше (для окна портала и приветствия в деревне)
export function nextGoal(realm) {
  const RL = REALMS[realm], hs = hunted(realm);
  if (hs.length) { const n = hs.sort((a, b) => b.rank - a.rank)[0]; return `☠ ${displayName(n)} espera por você no forte${n.stash ? ` e guarda ${n.stash} ouro — vingue-se` : ' — vingue-se'}`; }
  const ready = WILD_QUESTS[realm].find(q => { const S = G.profile.wild && G.profile.wild[realm]; if (!S) return false; const v = q.stat === 'depth' ? S.depth || 0 : (S.stat || {})[q.stat] || 0; return v >= q.n && !(S.claimed || {})[q.id]; });
  if (ready) return `🎁 Recompensa pronta: "${ready.title}" — pegue abaixo`;
  const S = G.profile.wild && G.profile.wild[realm];
  let best = null; for (const q of WILD_QUESTS[realm]) { if (S && (S.claimed || {})[q.id]) continue; const v = S ? (q.stat === 'depth' ? S.depth || 0 : (S.stat || {})[q.stat] || 0) : 0; const left = (q.n - v) / q.n; if (!best || left < best.left) best = { q, left, v }; }
  if (best) return `➡ A seguir: "${best.q.title}" — ${best.v}/${best.q.n}`;
  return `➡ Vá mais fundo: ${RL.short}, profundidade ${(S && S.best || 0) + 1}`;
}
function townHooks() {
  if (G.zoneId !== 'town' || !G.profile.tutorial.prologue) return;
  for (const realm of Object.keys(REALMS)) {
    const it = G.zone.inter.find(i => i.id === 'portal_' + realm); if (!it) continue;
    const hs = hunted(realm), S = G.profile.wild && G.profile.wild[realm];
    const ready = S ? WILD_QUESTS[realm].filter(q => { const v = q.stat === 'depth' ? S.depth || 0 : (S.stat || {})[q.stat] || 0; return v >= q.n && !(S.claimed || {})[q.id]; }).length : 0;
    it.plate = REALMS[realm].name + (hs.length ? ' ☠' : '') + (ready ? ' 🎁' : '');
  }
  const realm = Object.keys(REALMS).find(r => hunted(r).length) || null;
  if (realm) bus.emit('toast', { text: nextGoal(realm), sub: `Portal: ${REALMS[realm].name}`, kind: 'quest' });
}
