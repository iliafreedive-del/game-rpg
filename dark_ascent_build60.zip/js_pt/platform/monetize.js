// Monetization & retention: rewarded offers (never in combat), IAP grants with de-duplication,
// interstitial pacing, daily login streak and the "ripening chest" timer.
import { G, bus, inCombat } from '../game/ctx.js';
import { platform, PRODUCTS, gameplay } from './platform.js';
import { makeItem, makeSetItem, pickSet, itemPower, applyKindPerk, MAX_UPG } from '../game/items.js';
import { stats } from '../game/stats.js';
import { autoEquip } from '../game/character.js';
import { uid } from '../core/util.js';
import { pickEpic } from '../game/loot.js';
import { earlyLock, lockToast } from '../game/progress.js';
import { SETS } from '../data/sets.js';
import * as CS from '../game/castle.js';
import { track } from './analytics.js';

const MIN = 60 * 1000;
export const OFFERS = {
  bless: { title: 'Força da Fonte: +25% de ouro e XP por 10 minutos', icon: '✦' },
  xp_boost: { title: '+50% de XP por 15 minutos', icon: '✦' },
  gold_boost: { title: '+50% de ouro por 15 minutos', icon: '⛁' },
  revive: { title: 'Reviver no local', icon: '✚' },
  boss_extra: { title: 'Espólio extra do chefe', icon: '❖' },
  shop_refresh: { title: 'Renovar produtos de graça', icon: '↻' },
  chest_skip: { title: 'Abrir o Baú da Ordem agora', icon: '⧗' },
  daily_double: { title: 'Recompensa diária ×1,5', icon: '×1,5' },
  auto: { title: 'Combate automático por 30 minutos', icon: '▶' },
};
let busy = false;
// token-based single grant: each offer instance gets a token; the reward is applied at most once per token.
export function offerToken(kind, scope = '') { return `${kind}:${scope || uid('o')}`; }
export async function watchRewarded(kind, token, apply) {
  const P = G.profile;
  if (busy) return false;
  if (kind !== 'revive' && earlyLock('extra')) { lockToast('extra'); return false; }   // сборка 47: награды за рекламу — после обучения
  if (P.ads.used[token]) { bus.emit('toast', { text: 'Esta recompensa já foi resgatada', kind: 'warn' }); return false; }
  // в открытом окне на паузе (Летопись битв и т. п.) время мира стоит — «недавний бой» там не считается
  const wasPaused = G.paused, frozen = wasPaused && G.modalOpen;
  if (!frozen && inCombat() && kind !== 'revive' && kind !== 'boss_extra' && kind !== 'order_help') { bus.emit('toast', { text: 'Anúncios indisponíveis em combate', kind: 'warn' }); return false; }
  busy = true; G.paused = true; bus.emit('audioPause', true); gameplay(false);
  let ok = false;
  try { ok = await platform.p.showRewarded(); } catch { ok = false; }
  track('ad_rewarded', { kind, ok: ok ? 1 : 0 });
  busy = false; G.paused = wasPaused; bus.emit('audioPause', false);   // окно на паузе остаётся на паузе; GameplayAPI.start — из main.js, когда игра снова идёт
  if (!ok) { bus.emit('toast', { text: 'Sem recompensa: vídeo não concluído', kind: 'warn' }); return false; }
  if (P.ads.used[token]) return false;  // double-callback guard
  P.ads.used[token] = Date.now(); pruneTokens();
  apply(); bus.emit('save'); bus.emit('hud'); return true;
}
function pruneTokens() { const u = G.profile.ads.used; const ks = Object.keys(u); if (ks.length > 300) ks.sort((a, b) => u[a] - u[b]).slice(0, ks.length - 300).forEach(k => delete u[k]); }

export const offers = {
  xpBoost() { return watchRewarded('xp_boost', offerToken('xp_boost', 'w' + Math.floor(Date.now() / (15 * MIN))), () => { const P = G.profile; P.boosts.xpUntil = Math.max(Date.now(), P.boosts.xpUntil) + 15 * MIN; bus.emit('toast', { text: 'Bônus de XP', sub: '+50% de XP por 15 minutos', kind: 'good' }); }); },
  goldBoost() { return watchRewarded('gold_boost', offerToken('gold_boost', 'w' + Math.floor(Date.now() / (15 * MIN))), () => { const P = G.profile; P.boosts.goldUntil = Math.max(Date.now(), P.boosts.goldUntil) + 15 * MIN; bus.emit('toast', { text: 'Bônus de Ouro', sub: '+50% de ouro por 15 minutos', kind: 'good' }); }); },
  bossExtra(killId, x, y) { return watchRewarded('boss_extra', offerToken('boss_extra', killId), () => { const r = autoEquip(makeItem({ slot: 'weapon', cls: G.profile.cls, ilvl: G.profile.level + 1, rarity: 2 }));
    bus.emit('reward', { title: 'Item extra', sub: 'Recompensa por assistir', gold: 0, xp: 0, potions: 0, scrolls: 0, skillPts: 0, items: [r], now: true }); }); },   // П68: окно с полученной вещью и сравнением, а не молча в сумку
  shopRefresh(onDone) { return watchRewarded('shop_refresh', offerToken('shop_refresh', 'lv' + G.profile.level + '_' + Math.floor(Date.now() / (30 * MIN))), onDone); },
};

// ---- автобой за рекламу (сборка 47): один ролик — 30 минут. Бесплатно в обучении и с покупкой «Без рекламы»
export const AUTO_MIN = 30;
export const autoFree = () => !!(G.profile.iap && G.profile.iap.noAds) || earlyLock('extra');
export const autoLeft = () => Math.max(0, ((G.profile.boosts && G.profile.boosts.autoUntil) || 0) - Date.now());
export const autoOK = () => autoFree() || autoLeft() > 0;
export function autoAd() { return watchRewarded('auto', offerToken('auto', String(Date.now())), () => { const B = G.profile.boosts; B.autoUntil = Math.max(Date.now(), B.autoUntil || 0) + AUTO_MIN * MIN; }); }

// ---- interstitial pacing (only at safe transitions, never in/near combat, disabled by purchase)
let lastInter = Date.now();
export async function maybeInterstitial(reason) {
  const P = G.profile;
  if (P.iap.noAds || platform.name === 'demo' && !P.settings.demoInter) return false;
  // сборка 54: частота меняется флагами в консоли Яндекса без новой версии: inter_gap_min (минут между показами), inter_first_sec (не раньше, сек игры)
  const F = platform.flags || {}, gap = +F.inter_gap_min > 0 ? +F.inter_gap_min : 4, first = +F.inter_first_sec >= 0 && F.inter_first_sec != null ? +F.inter_first_sec : 180;
  if (Date.now() - lastInter < gap * MIN || P.stats.playTime < first) return false;
  lastInter = Date.now(); const wasPaused = G.paused; G.paused = true; bus.emit('audioPause', true); gameplay(false);   // правки по скилам: окно, открытое до рекламы, остаётся на паузе
  try { await platform.p.showInterstitial(); } catch { }
  track('ad_inter', { reason: reason || '' });
  G.paused = wasPaused; bus.emit('audioPause', false); return true;
}

// ---- IAP
export async function buy(productId) {
  const P = G.profile, def = PRODUCTS[productId];
  if (earlyLock('extra')) { lockToast('extra'); return false; }   // сборка 47: покупки — после обучения
  if (def.once && P.iap.tx['once_' + productId]) { bus.emit('toast', { text: 'Este pacote já foi comprado', kind: 'warn' }); return false; }
  if (!def.consumable && P.iap[flagOf(productId)]) { bus.emit('toast', { text: 'Já comprado', kind: 'warn' }); return false; }
  const wasPaused = G.paused; G.paused = true; gameplay(false); const r = await platform.p.purchase(productId); G.paused = wasPaused;
  track(r.ok ? 'buy_ok' : 'buy_cancel', { id: productId });
  if (!r.ok) return false;
  return grantPurchase(productId, r.token);
}
// Лестница снаряжения: платная вещь на одну редкость выше того, что игрок добывает сам, уровня «герой + 3».
// Через 2–3 вечера враги дорастают, и вещь становится обычной — её можно закалять и сливать дальше.
function grantGear(def, pre) {
  const out = (pre || rollGear(def)).map(it => autoEquip(it, true));
  return out;
}
// П24: вещи покупки выпадают заранее — окно предложения показывает именно их (иконка, статы, сравнение с надетым), покупка выдаёт их же.
// Если надетое стало лучше превью — превью перебрасывается, так что предложенная вещь всегда сильнее надетой
export function offerPreview(id) {
  const P = G.profile, def = PRODUCTS[id]; if (!P || !def || (id !== 'starter_pack' && !def.gear)) return null;
  P.iap.preview = P.iap.preview || {};
  let pre = P.iap.preview[id];
  if (pre && pre.lvl === P.level && pre.items.every(it => !P.gear[it.slot] || itemPower(it) > itemPower(P.gear[it.slot]))) return pre.items;
  const items = id === 'starter_pack' ? [starterItem()] : rollGear(def);
  P.iap.preview[id] = { lvl: P.level, items }; bus.emit('save'); return items;
}
function takePreview(id) { const P = G.profile, pre = P.iap.preview && P.iap.preview[id]; if (pre) delete P.iap.preview[id]; return pre && pre.items; }
// синее оружие набора искателя: всегда заметно сильнее надетого (закалка до +20% силы)
function starterItem() {
  const P = G.profile, it = makeItem({ ilvl: Math.max(3, P.level), rarity: 2, slot: 'weapon', cls: P.cls }); delete it.req;
  const cur = P.gear.weapon; let k = 0; if (cur) while (itemPower(it) < itemPower(cur) * 1.2 && k++ < MAX_UPG) it.upg = (it.upg || 0) + 1;
  return it;
}
function rollGear(def) {
  const P = G.profile, cls = P.cls || 'warrior', ilvl = P.level + 3, g = def.gear, out = [];
  // сборка 47: купленная вещь всегда заметно лучше надетой (жалоба: набор за 99 ₽ слабее своих зелёных) — редкость не ниже надетой +1, закалка до +20% силы
  const fix = it => { delete it.req; it.ilvl = ilvl; const cur = P.gear[it.slot];
    if (cur) { it.rarity = Math.max(it.rarity, Math.min(4, cur.rarity + 1)); applyKindPerk(it); let k = 0; while (itemPower(it) < itemPower(cur) * 1.2 && k++ < MAX_UPG) it.upg = (it.upg || 0) + 1; }
    return it; };
  if (g.kind === 'set') {
    const setId = Object.keys(SETS).filter(k => SETS[k].branch && SETS[k].cls.includes(cls))[0] || pickSet(cls);
    for (const slot of ['head', 'chest', 'amulet']) { const it = makeSetItem(setId, slot, ilvl, cls); it.rarity = g.rarity; out.push(fix(it)); }
  } else if (g.kind === 'epic' || g.kind === 'mythic') {
    const it = makeItem({ epic: pickEpic(cls), ilvl, cls, noClamp: true });
    if (g.kind === 'mythic') it.rarity = 4;
    out.push(fix(it));
  }
  return out;
}
export const flagOf = id => ({ gold_perk: 'goldPerk', no_ads: 'noAds', bag_big: 'bagBig' }[id] || id);
export async function grantPurchase(productId, token) {
  const P = G.profile;
  if (P.iap.tx[token]) { await platform.p.consume(token); return false; }   // already granted — just finish the transaction
  P.iap.tx[token] = Date.now();
  switch (productId) {
    case 'starter_pack': { P.gold += 1000; P.potions.hp += 10; P.potions.mp += 5; const items = (takePreview('starter_pack') || [starterItem()]).map(it => autoEquip(it, true)); P.iap.tx['once_starter_pack'] = 1;
      bus.emit('reward', { title: PRODUCTS[productId].title, sub: 'Compra recebida', gold: 1000, xp: 0, potions: 10, mp: 5, scrolls: 0, skillPts: 0, items }); break; }   // П24: окно с тем, что получено
    case 'gold_small': P.gold += 600; break;
    case 'guard_armor': case 'seal_blade': case 'magister_plate': case 'order_weapon': case 'abyss_set': {
      const items = grantGear(PRODUCTS[productId], takePreview(productId)); P.iap.tx['once_' + productId] = 1;
      bus.emit('reward', { title: PRODUCTS[productId].title, sub: 'Compra recebida', gold: 0, xp: 0, potions: 0, scrolls: 0, skillPts: 0, items });
      break; }
    case 'season_pass': P.seasonPass = P.seasonPass || {}; P.seasonPass[new Date().getFullYear() + '-' + (new Date().getMonth() + 1)] = 1; break;
    case 'energy_pack': { const t = CS.torches(); t.n += 50; break; }   // сборка 47: можно сверх запаса
    case 'potion_pack': P.potions.hp += 15; P.potions.mp += 10; break;
    case 'gold_perk': P.iap.goldPerk = true; break;
    case 'no_ads': P.iap.noAds = true; break;
    case 'bag_big': if (!P.iap.bagBig) { P.iap.bagBig = true; P.bagSize += 20; } break;   // повторное восстановление покупки не добавит мест
  }
  bus.emit('save');   // persist grant BEFORE consuming, so a crash cannot lose it
  if (PRODUCTS[productId].consumable) await platform.p.consume(token);
  G.stats = stats(P); bus.emit('hud'); bus.emit('toast', { text: 'Compra recebida', sub: PRODUCTS[productId].title, kind: 'good' }); bus.emit('sfx', 'quest');
  return true;
}
export async function restorePurchases() {
  const list = await platform.p.getPurchases();
  for (const p of list) await grantPurchase(p.productId, p.token);
}

// ---- retention: календарь входа у алтаря богини (сборка 19) + сундук Ордена
// 28 дней по кругу; пропуск дня НЕ сбрасывает прогресс (следующий вход = следующий день календаря).
// Каждый 3-й день награда больше (свиток, зелья), 7/14/21/28 — крупная (вещь). Видно, что будет через 1–3 дня.
export const LOGIN_DAYS = 28;
export function loginReward(d) {   // d — день календаря 1..28
  // правки мамы (М21): награда была «примитивной» — только золото. Теперь каждый 3-й день ещё и осколки Бездны ◆ (они по-настоящему ценные), в большие дни — больше
  if (d % 7 === 0) return { big: true, gold: 120, potions: 3, scrolls: 1, shards: d >= 21 ? 5 : 3, item: d >= 21 ? 3 : 2, label: d >= 21 ? 'Item Dourado' : 'Item Azul' };
  if (d % 3 === 0) return { mid: true, gold: 70, potions: 3, scrolls: 1, shards: 1, label: 'Pergaminho, poções e ◆' };
  return { gold: 35, potions: d % 2 ? 1 : 0, label: 'Ouro' };
}
export const DAILY = Array.from({ length: LOGIN_DAYS }, (_, i) => loginReward(i + 1));
const dayKey = t => { const d = new Date(t); return d.getFullYear() * 10000 + (d.getMonth() + 1) * 100 + d.getDate(); };
export function dailyStatus() {
  const P = G.profile; P.daily = P.daily || { last: 0, streak: 0 };
  const today = dayKey(Date.now()), claimable = P.daily.last !== today, n = P.daily.streak;   // streak — сколько дней календаря уже получено (всего)
  const day = claimable ? n % LOGIN_DAYS + 1 : (n - 1) % LOGIN_DAYS + 1;   // текущий день календаря
  return { claimable, streak: n, day, reward: loginReward(day) };
}
export function claimDaily(double) {
  const P = G.profile; const s = dailyStatus(); if (!s.claimable) return false;
  const r = s.reward, m = double ? 1.5 : 1;   // за рекламу — ×1,5 (сборка 47; было ×2), вещь — одна
  if (r.gold) P.gold += Math.round(r.gold * m * P.level);
  if (r.potions) P.potions.hp += Math.round(r.potions * m);
  if (r.scrolls) P.scrolls += Math.round(r.scrolls * m);
  if (r.shards) P.shards = (P.shards || 0) + Math.round(r.shards * m);
  const items = [];
  if (r.item) for (let i = 0; i < 1; i++) { const it = makeItem({ ilvl: P.level, rarity: r.item, cls: P.cls }); delete it.req; items.push(autoEquip(it)); }
  P.daily.last = dayKey(Date.now()); P.daily.streak = s.streak + 1; bus.emit('loginClaimed');
  // М22: после рекламы (и без неё) — окно с тем, что получено, а не мимолётная строка
  bus.emit('reward', { title: `Presente da Fonte — dia ${s.day} de ${LOGIN_DAYS}`, sub: double ? 'Recompensa por assistir ×1,5' : r.big ? 'Grande recompensa!' : 'Presente diário', gold: r.gold ? Math.round(r.gold * m * P.level) : 0, xp: 0, potions: r.potions ? Math.round(r.potions * m) : 0, scrolls: r.scrolls ? Math.round(r.scrolls * m) : 0, shards: r.shards ? Math.round(r.shards * m) : 0, skillPts: 0, items, now: true });
  bus.emit('sfx', 'quest'); bus.emit('hud'); bus.emit('save'); return true;
}

// ---- благословение богини за рекламу: +25% золота и опыта, +15% к выпадению вещей (сборка 47; было +50% / +25%); 10 минут за просмотр, не больше 30 подряд
export const BLESS_MIN = 10, BLESS_CAP = 30;
// сборка 47: не больше 3 просмотров в день (30 минут), иначе реклама подряд качает героя быстрее игры
export const BLESS_DAY = 3;
export function blessToday() { const P = G.profile, d = dayKey(Date.now()); P.ads.bless = P.ads.bless && P.ads.bless.d === d ? P.ads.bless : { d, n: 0 }; return P.ads.bless.n; }
export const blessLeft = () => Math.max(0, ((G.profile.boosts && G.profile.boosts.blessUntil) || 0) - Date.now());
export const blessed = () => blessLeft() > 0;
export function blessing() {
  if (blessLeft() > (BLESS_CAP - BLESS_MIN) * MIN) { bus.emit('toast', { text: 'O poder da Fonte já está no máximo', sub: `No máximo ${BLESS_CAP} minutos seguidos`, kind: 'warn' }); return Promise.resolve(false); }
  if (blessToday() >= BLESS_DAY) { bus.emit('toast', { text: 'A Fonte de Poder descansa até amanhã', sub: `No máximo ${BLESS_DAY} vezes por dia`, kind: 'warn' }); return Promise.resolve(false); }
  return watchRewarded('bless', offerToken('bless'), () => { const P = G.profile; blessToday(); P.ads.bless.n++; P.boosts.blessUntil = Math.max(Date.now(), P.boosts.blessUntil || 0) + BLESS_MIN * MIN; P.boosts.blessWarned = false;
    bus.emit('toast', { text: 'Poder da Fonte!', sub: '+25% de ouro e XP, +15% de itens — 10 minutos. Ao combate!', kind: 'good' }); bus.emit('sfx', 'levelup'); });
}
// напоминание за минуту до конца и по окончании (вызывается раз в секунду из hud.js)
export function blessTick() {
  const P = G.profile, B = P.boosts; if (!B || !B.blessUntil) return;
  const left = B.blessUntil - Date.now();
  if (left > 0 && left < 60000 && !B.blessWarned) { B.blessWarned = true; bus.emit('toast', { text: 'O poder da Fonte está acabando — um minuto!', sub: 'Volte à Fonte de Poder na praça para prolongar', kind: 'quest' }); }
  if (left <= 0 && B.blessWarned !== 'done') { B.blessWarned = 'done'; bus.emit('toast', { text: 'O poder da Fonte se esgotou', sub: 'A Fonte de Poder na praça da vila concederá mais', kind: 'info' }); bus.emit('save'); }
}
export const CHEST_TIME = 4 * 60 * MIN;
export function chestStatus() { const P = G.profile; P.orderChest = P.orderChest || { readyAt: Date.now() + 20 * MIN }; const left = P.orderChest.readyAt - Date.now(); return { ready: left <= 0, left }; }
export function openOrderChest(viaAd) {
  const P = G.profile; const s = chestStatus();
  if (!s.ready && !viaAd) return false;
  let got; { const it = makeItem({ ilvl: P.level + 1, rarity: Math.random() < 0.25 ? 2 : 1, cls: P.cls }); delete it.req; got = autoEquip(it); }   // сборка 47: обычно зелёная, синяя — 1 из 4
  P.gold += 40 * P.level; P.orderChest.readyAt = Date.now() + CHEST_TIME;
  bus.emit('reward', { title: 'Baú da Ordem aberto!', sub: viaAd ? 'Recompensa por assistir' : 'Baú da Ordem', gold: 40 * P.level, xp: 0, potions: 0, scrolls: 0, skillPts: 0, items: [got], now: true });   // М22: окно с вещью и сравнением
  bus.emit('sfx', 'chest'); bus.emit('hud'); bus.emit('save'); return true;
}
export function chestSkip() { const s = chestStatus(); if (s.ready) return openOrderChest(); return watchRewarded('chest_skip', offerToken('chest_skip', String(G.profile.orderChest.readyAt)), () => openOrderChest(true)); }
