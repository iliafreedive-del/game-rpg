// Обучение (сборка 45): без окон на паузе. Над нужной кнопкой появляется «палец» и одна строка текста,
// игра при этом идёт. Кнопки боя появляются тогда, когда они впервые нужны (profile.tutorial.un).
// Сборка 49 (карусель «8 приёмов обучения»): вопроса «Показать подсказки?» больше нет — подсказки включены всегда
// и выключаются в «Справке» (меню); рывок учит медленный скелет-учитель в склепе; зелье — после боя; каждая подсказка
// попадает в журнал «Справки», а ключевые моменты первых минут — в метки времени (profile.tutorial.ms).
import { G, bus } from '../game/ctx.js';
import { $, el, esc, ICO } from '../core/util.js';
import { STORY } from '../data/quests.js';
import { once as anOnce } from '../platform/analytics.js';
import { UPGRADES, upgCost } from '../data/upgrades.js';
import { skillCost, canLearn } from '../game/character.js';
import { earlyLock } from '../game/progress.js';

const touch = () => matchMedia('(pointer:coarse)').matches;
const T = () => { const P = G.profile; P.tutorial = P.tutorial || {}; P.tutorial.tips = P.tutorial.tips || {}; P.tutorial.un = P.tutorial.un || {}; return P.tutorial; };
// какие кнопки боя уже открыты: пустая ячейка навыка, зелье маны, рывок, «АВТО» и свиток мешают в первые минуты
export const unlocked = k => { const t = T(); return !!(t.un[k] || t.off || !t.on); };
export function unlock0(k) { const t = T(); if (t.un[k]) return false; t.un[k] = 1; bus.emit('save'); bus.emit('uiUnlock', k); return true; }
export const unlock = unlock0;
export function unlockAll() { const t = T(); for (const k of ['dodge', 'pot', 'potMP', 'sk', 'auto', 'scroll']) t.un[k] = 1; }

// ---------------------------------------------------------------- журнал подсказок и метки времени (сборка 49)
// журнал: что игроку уже объясняли — «Справка» в меню показывает его, чтобы перечитать одно, не перезапуская обучение
function logHint(text) { const t = T(), L = (t.log = t.log || []); if (L.includes(text)) return; L.push(text); if (L.length > 60) L.shift(); }
export const hintLog = () => (T().log || []).slice();
// «Считайте минуты»: минута игры, на которой игрок впервые дошёл до ключевого момента
export const MILESTONES = [['kill1', 'Primeiro Abate'], ['crypt', 'Escapou da Cripta'], ['quest1', 'Primeira Missão Entregue'], ['lvl2', 'Nível 2'],
  ['skill1', 'Primeira Habilidade'], ['cata', 'Entrou nas Catacumbas'], ['death1', 'Primeira Morte'], ['lvl5', 'Nível 5'], ['boss', 'Carrasco do Abismo Derrotado']];
export function mark(k) { const P = G.profile; if (!P) return; const t = T(), ms = (t.ms = t.ms || {}); if (ms[k] != null) return; ms[k] = Math.round(P.stats.playTime || 0); anOnce('ms_' + k, { sec: ms[k] }); bus.emit('save'); }
export const milestones = () => T().ms || {};
export const hintsOn = () => { const t = T(); return t.on !== false && !t.off; };
export function setHints(on) { const t = T(); t.on = !!on; t.off = !on; if (!on) { hideHand(); unlockAll(); } bus.emit('save'); bus.emit('hud'); }

// ---------------------------------------------------------------- палец + строка подсказки
let hand = null, line = null, handKey = null, handUntil = 0, handWin = null, zoomLine = false;   // handWin — подсказка внутри окна (живёт, пока элемент на экране)
const rectOf = id => { const e = typeof id === 'string' ? $(id) : id; if (!e || e.offsetParent === null) return null; const r = e.getBoundingClientRect(); return r.width ? r : null; };
export function hideHand() { if (hand) { hand.remove(); hand = null; } if (line) { line.remove(); line = null; } handKey = null; handWin = null; zoomLine = false; }
// показать палец над элементом (или просто строку, если элемента нет)
// кнопка только что открылась: подождать кадр, пока HUD её покажет, иначе «палец» не найдёт место
export const pointSoon = (sel, text, o) => setTimeout(() => pointAt(sel, text, o), 150);
export function pointAt(sel, text, { key = null, time = 9, mid = false, force = false, win = false } = {}) {
  const t = T(); if (t.off && !force) return false;
  if (force && (hand || line)) return false;   // напоминание не перебивает подсказку обучения
  if (key && t.tips[key]) return false;
  const r = sel ? rectOf(sel) : null;
  if (sel && !r) return false;
  if (key) { t.tips[key] = 1; bus.emit('save'); anOnce('hint_' + key); }
  logHint(text);
  hideHand();
  if (r) { hand = el('div', 'hand'); hand._sel = sel; placeHand(r); document.body.appendChild(hand); }
  line = el('div', 'hint-line ' + (mid || !r ? 'mid' : 'bot'), (key === 'shards' ? ICO.big : '') + text); document.body.appendChild(line);   // П44: крупный осколок в подсказке про осколки
  handKey = key || sel || text; handUntil = performance.now() + time * 1000; handWin = win && sel ? (typeof sel === 'string' ? $(sel) : sel) : null;
  bus.emit('sfx', 'quest');
  return true;
}
// правки мамы (М16): палец ставился один раз и оставался на месте, когда кнопка уезжала (поворот телефона, вырез Android, появился трекер) —
// и показывал на золото с кристаллами. Теперь палец следует за своей кнопкой
function placeHand(r) { hand.style.left = (r.left + r.width / 2) + 'px'; hand.style.top = (r.top + r.height / 2) + 'px'; }
function followHand() { if (!hand || !hand._sel) return; const r = rectOf(hand._sel); if (r) placeHand(r); }
addEventListener('resize', () => setTimeout(followHand, 120));
// подсказка исчезает сама: по времени, по нажатию нужной кнопки или по событию
function handTick() {
  if (!hand && !line) return;
  followHand();
  // сборка 60: подсказка внутри окна (win) не гаснет от самого окна — гаснет, когда её кнопка исчезла; строка о зуме гаснет, как только открыто окно или панель NPC (П7)
  if (performance.now() > handUntil || G.cinema || (handWin ? !handWin.isConnected : G.modalOpen) || (zoomLine && G.panelTarget)) hideHand();
}

// ---------------------------------------------------------------- что и когда открывать
let revealAt = 0;   // не больше одной новой кнопки раз в 3 с: иначе подсказки перебивают друг друга
function revealTick() {
  const P = G.profile, pl = G.player, S = G.stats, t = T(); if (!P || !pl || !S || t.off || pl.dead || G.modalOpen) return;   // сборка 59: мёртвому подсказки не нужны; сборка 60: и пока открыто окно (подарок старосты — умение — показываем после окна награды)
  if (performance.now() < revealAt) return;
  const unlock = k => { revealAt = performance.now() + 3000; return unlock0(k); };
  const dz = G.zoneId !== 'town' && G.zoneId !== 'castle';
  // рывок: первый сильный замах врага (красный круг) или третий бой
  if (!t.un.dodge && dz && (G.enemies || []).some(e => !e.dead && e.aggro && e.teleg)) { unlock('dodge'); pointSoon('btnDodge', touch() ? 'Investida! Toque para saltar para longe de um golpe' : 'Investida: Shift — salte para longe de um golpe'); return; }
  if (!t.un.dodge && (P.stats.kills || 0) >= 3) { unlock('dodge'); pointSoon('btnDodge', 'Esta é a investida — ela esquiva de um golpe'); return; }
  // зелье здоровья: когда стало мало жизни
  // зелье здоровья: «новое — без угрозы» — учим после боя, когда рядом никого; посреди драки — только если совсем плохо
  const fight = (G.enemies || []).some(e => !e.dead && e.aggro);
  if (!t.un.pot && P.potions.hp > 0 && (pl.hp < S.maxHP * 0.6 && !fight || pl.hp < S.maxHP * 0.3)) { unlock('pot'); pointSoon('potHP', fight ? 'Vida baixa! Toque na poção vermelha' : 'A poção vermelha cura. Toque nela — a luta acabou, hora de se curar'); return; }
  // навыки и мана: как только выучен первый навык
  if (!t.un.sk && P.slots.some(Boolean)) { unlock('sk'); unlock('potMP'); pointSoon('sk0', 'Sua habilidade! Toque nela em combate'); return; }
  // «АВТО»: после 10 побед в подземелье
  if (!t.un.auto && dz && (P.stats.kills || 0) >= 10) { unlock('auto'); pointSoon('btnAuto', 'AUTO: o herói luta sozinho'); return; }
  // свиток возврата
  if (!t.un.scroll && (G.zoneId === 'catacombs' || G.zoneId === 'wild' || G.zoneId === 'depths') && P.scrolls > 0) { unlock('scroll'); pointSoon('btnScroll', 'Pergaminho de retorno — volta para casa na hora'); return; }
}
// подсказки по месту: кнопка действия, староста, наставник, портрет, торговка, слияние
let zoneTicks = 0, zoomTicks = 0;
function placeTick() {
  const P = G.profile, t = T(); zoneTicks = G.zoneId === 'town' ? 0 : zoneTicks + 1;
  // зум камеры: сборка 59 — подсказка в деревне, в катакомбах и в Жатве (по разу в каждой), а не через 15 минут где-то в подземелье.
  // В деревне — когда пролог позади и герой постоял ~6 с без окон; в катакомбах и Жатве — через ~6 с после входа, если рядом нет боя
  // сборка 60 (П7): сначала в первом подземелье (катакомбы), потом один раз в деревне; не поверх окна и не поверх панели NPC (Элвин)
  { const zk = { town: 'town', catacombs: 'cata' }[G.zoneId], zs = (t.zoomAt = t.zoomAt || {});
    zoomTicks = zk && !G.modalOpen && !G.panelTarget && !G.hwOpen && !hand && !line ? zoomTicks + 1 : 0;
    const calm = !(G.enemies || []).some(e => !e.dead && e.aggro);
    if (zk && !zs[zk] && !t.zoomSeen && zoomTicks > 14 && calm && (G.zoneId !== 'town' || zs.cata)) { zs[zk] = 1; bus.emit('save');
      // своя фраза в каждом месте — не повтор одной и той же строки
      const how = touch() ? { in: 'afaste dois dedos na tela', out: 'junte dois dedos' } : { in: 'roda do mouse para a frente', out: 'roda do mouse para trás' };
      const txt = { town: `Lembre-se: dá para aproximar (${how.in}) ou afastar (${how.out}) a câmera — de longe se vê mais`, cata: `Dá para aproximar (${how.in}) ou afastar (${how.out}) a câmera — afaste para ver mais ao redor` }[zk];   // М3
      if (t.off || !t.on) bus.emit('toast', { text: txt, kind: 'info' }); else { if (pointAt(null, txt, { time: 9 })) zoomLine = true; return; } } }
  if (t.off || !t.on || G.modalOpen) return;
  const once = (key, sel, text) => !t.tips[key] && pointAt(sel, text, { key });   // сборка 49: объявлено до первого использования (раньше — ошибка в консоли каждые 0,4 с)
  const q = G.profile.story && STORY[G.profile.story.stage];
  // сборка 47: саркофаг с ключом — многие пробегали мимо
  if (q && q.id === 'medallion' && !P.world.hasKey && G.focus && G.focus.type === 'sarc' && once('sarc', 'btnAct', 'Um sarcófago! Abra-o — um deles guarda a chave da porta do amuleto')) return;
  if (q && q.id === 'medallion' && !P.world.hasKey && G.zoneId === 'catacombs' && once('sarc0', null, 'A chave está escondida em um dos sarcófagos — abra-os')) return;
  // правки мамы (М11): стрелку и магу в первом подземелье — как воевать: выстрел, отход, выстрел (кайт), а не стоять лицом к лицу
  if (G.stats && G.stats.ranged && (G.zoneId === 'catacombs' || G.zoneId === 'depths') && (G.enemies || []).some(e => !e.dead && e.aggro) &&
    once('kite', null, G.profile.cls === 'mage' ? 'Você é mago: ataque de longe. Inimigo chegou perto — corra para trás e pare, o herói ataca sozinho. Recua — ataca — recua' : 'Você é arqueiro: atire de longe. Inimigo chegou perto — corra para trás e pare, o herói atira sozinho. Recua — atira — recua')) return;
  if (!$('btnLead').classList.contains('hidden') && once('lead', 'btnLead', 'Não sabe para onde ir? Toque em "Guie-me" — o herói corre até o objetivo')) return;
  if ((P.shards || 0) > 0 && once('shards', 'goldBox', '◆ roxos são fragmentos do Abismo, uma moeda rara. Gaste com sabedoria: pets com Kofi, "Precisão" com Elvin')) return;
  if (!$('btnAct').classList.contains('hidden')) {
    const f = G.focus;
    if (once('act', 'btnAct', f && f.type === 'portal' ? 'Toque para entrar no portal' : 'Toque para falar ou abrir')) return;
  }
  if (G.zoneId === 'town' && P.story.stage >= 1 && once('hero', 'portrait', 'Toque no retrato — equipamento, habilidades e missões')) return;
  if (P.bag && P.bagSize && P.bag.length >= P.bagSize - 2 && G.zoneId === 'town' && once('sell', null, 'Bolsa quase cheia: Mira, a Mercadora, tem o botão "Vender cinzas"')) return;
}

// ---------------------------------------------------------------- напоминания первых уровней (правки мамы)
// М15 — мало здоровья: зелье (и что вне боя здоровье восстанавливается само); М17 — умение готово, а герой бьёт только автоатакой;
// М19 — золота хватает на покупку у Элвина. Каждое — не чаще своего интервала, только до 8 уровня и если подсказки не выключены
const nagT = {}; let lastSkillT = 0, goldNoted = 0;
const nag = (k, gap) => { const now = performance.now(); if (now - (nagT[k] || -1e9) < gap * 1000) return false; nagT[k] = now; return true; };
export function elvinBuy() {   // самая дешёвая покупка у Элвина, на которую хватает золота: { text, cost } или null
  const P = G.profile; if (!P || earlyLock('upg')) return null; let best = null;
  if (P.skillPts > 0) for (const id of Object.keys(P.skills || {})) if (P.skills[id] && canLearn(id).ok) { const c = skillCost(id); if (P.gold >= c && (!best || c < best.cost)) best = { text: 'melhorar habilidade', cost: c }; }
  for (const [id, U] of Object.entries(UPGRADES)) { if (U.shards) continue; const l = (P.upg && P.upg[id]) || 0; if (l >= U.max) continue; const c = upgCost(id, l); if (P.gold >= c && (!best || c < best.cost)) best = { text: `«${U.name}»`, cost: c }; }
  return best;
}
function remindTick() {
  const P = G.profile, pl = G.player, S = G.stats; if (!P || !pl || pl.dead || !S || !hintsOn() || P.level >= 8 || G.modalOpen || G.cinema || G.surv) return;
  const fight = (G.enemies || []).some(e => !e.dead && e.aggro), dz = G.zoneId !== 'town' && G.zoneId !== 'castle';
  if (P.slots.some(id => id && (pl.cds[id] || 0) > 0)) lastSkillT = performance.now();
  if (dz && unlocked('pot') && pl.hp < S.maxHP * 0.4 && P.potions.hp > 0 && (pl.cds.pot_hp || 0) <= 0 && nag('pot', 40)) {
    pointAt('potHP', fight ? 'Vida baixa! Toque na poção vermelha' : 'Vida baixa. Beba uma poção ou fique fora de combate — a vida se recupera sozinha', { time: 5, force: true }); return; }
  if (dz && S.ranged && P.level < 6 && T().tips.kite && (G.enemies || []).some(e => !e.dead && e.aggro && !e.D.proj && Math.hypot(e.x - pl.x, e.y - pl.y) < 1.6 + e.r) && pl.hp < S.maxHP * 0.7 && nag('kite', 90)) {
    pointAt(null, 'Inimigo colado — corra uns passos para trás e pare: de longe você bate sem levar troco', { time: 4, force: true }); return; }   // М11
  const id = P.slots.find(Boolean), b = $('sk0');
  if (dz && fight && id && unlocked('sk') && (pl.cds[id] || 0) <= 0 && pl.mp >= 20 && performance.now() - lastSkillT > 45000 && b && b.offsetParent && nag('skill', 70)) {
    pointAt('sk0', 'Habilidade pronta! Toque nela — bate muito mais forte que o ataque normal', { time: 5, force: true }); return; }
  if (G.zoneId === 'town' && !fight) { const e = elvinBuy();
    if (e && P.gold >= goldNoted + 100 && nag('elvin', 120)) { goldNoted = P.gold; bus.emit('toast', { text: `Ouro suficiente para Elvin: ${e.text} — ${e.cost} ouro`, sub: 'Herói mais forte, lutas mais fáceis. O mentor fica perto dos bonecos de treino (ícone "+")', kind: 'quest' }); }
    if (!e) goldNoted = Math.min(goldNoted, P.gold); }
}

export async function intro() {
  const t = T(); if (t.introDone) return; t.introDone = true; bus.emit('save');
  // первые секунды в склепе: только движение. Остальному учим по ходу.
  if (G.run && G.run.floor === 0) return;   // сборка 49: в склепе это говорит пролог (tutorialTick в game.js) — без повтора
  pointAt('joyZone', touch() ? 'Deslize o dedo pela tela — o herói anda. Toque num lugar — ele corre até lá' : 'Mova-se: WASD ou segure o botão direito do mouse', { time: 10 });
}

export function initTutorial() {
  bus.on('tutorialRestart', () => { const t = T(); t.on = true; t.off = false; t.introDone = false; t.tips = {}; t.un = {}; intro(); });
  bus.on('tutHand', o => pointAt(o.sel, o.text, o));
  bus.on('zoneEntered', () => { zoomTicks = 0; });   // сборка 59: подсказку о зуме считать заново в каждой локации
  bus.on('camZoom', () => { if (G.profile) { T().zoomSeen = 1; bus.emit('save'); } });   // уже нашёл зум сам — подсказка не нужна
  // нажал подсказанную кнопку — палец убираем сразу
  for (const id of ['btnDodge', 'potHP', 'potMP', 'btnAuto', 'btnScroll', 'btnAct', 'portrait', 'sk0']) { const e = $(id); if (e) e.addEventListener('pointerdown', hideHand); }
  setInterval(() => { if (!G.profile || !G.zoneReady) return; handTick(); if (G.cinema) return; revealTick(); placeTick(); remindTick(); }, 400);   // во время облёта камеры подсказок нет
  // сборка 47: первая вещь из добычи — где её надеть и сравнить
  bus.on('itemPicked', () => setTimeout(() => pointAt('portrait', 'Novo item na bolsa! Toque no retrato → "Bolsa": equipe e compare com o atual', { key: 'bag1', time: 10 }), 600));
  // первое зелье в награду — откуда они берутся
  bus.on('reward', r => { if (r.potions) setTimeout(() => pointAt(null, 'Poções de vida são recompensas de missões e vendidas por Mira, a Mercadora', { key: 'potgot', time: 7 }), 1500); });
  bus.on('questComplete', q => {
    if (q.id !== 'meet_merchant') return;   // Мира: научить зелью и рывку
    // сборка 49: «одно новое за раз» — объясняем только то, чего игрок ещё не видел (обычно оба уже открыты в склепе)
    const newPot = unlock0('pot'), newDodge = unlock0('dodge');
    if (newPot) pointSoon('potHP', touch() ? 'Botão vermelho — poção de vida. Toque em combate quando a vida estiver baixa' : 'Poção de vida: tecla Q ou o botão vermelho. Beba em combate quando a vida estiver baixa', { time: 7 });
    if (newDodge) setTimeout(() => pointAt('btnDodge', touch() ? 'Investida! Toque para saltar para longe do golpe inimigo (círculo vermelho)' : 'Investida: Shift — salte para longe do golpe inimigo (círculo vermelho)', { key: 'dodge2', time: 8 }), newPot ? 8000 : 300);
  });
  bus.on('panel', it => { if (!it || it.id !== 'trainer') return; setTimeout(() => { if (G.profile.skillPts > 0) pointAt('tBtnSkills', 'Toque em "Habilidades" — é lá que se aprendem', { key: 'tbtn' }); }, 400); });
  // сборка 60 (П32): окно героя — портрет → «Герой» → сумка и сравнение. Учим на шаге «Осмотреть снаряжение»
  const gearStep = () => { const q = G.profile && STORY[G.profile.story.stage]; return q && q.id === 'hero_gear'; };
  const portraitHint = () => { if (gearStep() && !G.modalOpen) pointAt('portrait', 'Toque no retrato — é a janela do herói', { time: 12 }); };
  bus.on('questNew', q => { if (q && q.id === 'hero_gear') setTimeout(function again(n = 0) { if (G.modalOpen && n < 30) return setTimeout(() => again(n + 1), 700); portraitHint(); }, 900); });
  bus.on('menuOpened', () => { T().tips.hero = 1; if (gearStep()) pointAt(document.querySelector('.menu-tile[data-w="inventory"]'), '"Herói" — itens equipados e bolsa', { time: 12, win: true }); });
  bus.on('invOpened', () => {
    if (!hintsOn()) return; const t = T(); if (t.tips.inv1) return; t.tips.inv1 = 1; bus.emit('save');
    const g = document.querySelector('.eq-grid .eq-slot') || document.querySelector('.eq-doll .eq-slot');
    pointAt(g, 'À esquerda, o que está equipado; à direita, a bolsa. Toque num item: ▲ — melhor que o equipado, ▼ — pior. Lá também ficam "Equipar" e "Vender"', { time: 12, win: true });
  });
  bus.on('skillsOpened', () => setTimeout(() => { const b = document.querySelector('.tal-learn.ok'); if (b) pointAt(b, 'Toque em "Aprender"', { key: 'learn', win: true }); }, 350));
  // метки времени «первых минут» (видно в «Справке»: тестер присылает скриншот)
  bus.on('kill', () => mark('kill1'));
  bus.on('questComplete', () => mark('quest1'));
  bus.on('levelUp', () => { const L = G.profile.level; if (L >= 2) mark('lvl2'); if (L >= 5) mark('lvl5'); });
  bus.on('skillsChanged', () => { if (Object.values(G.profile.skills || {}).some(Boolean)) mark('skill1'); });
  bus.on('zoneEntered', id => { if (id === 'town' && G.profile.tutorial.prologue) mark('crypt'); if (id === 'catacombs') mark('cata'); });
  bus.on('playerDeath', () => { mark('death1'); hideHand(); });
  bus.on('bossDefeated', () => mark('boss'));
  // сборка 60 (П13): первая синяя душа в Жатве — короткая пауза и стрелка над ней (стрелку рисует survival.js)
  bus.on('survGemTip', () => { const t = T(); t.tips.survGem = 1; bus.emit('save'); if (!hintsOn()) return;
    G.paused = true; pointAt(null, '💎 Uma alma azul! Pegue-a — almas evoluem suas habilidades nesta Colheita', { time: 5, mid: true });
    setTimeout(() => { if (!G.modalOpen && G.surv) G.paused = false; }, 1800); });
  bus.on('mergeReady', () => pointAt(null, 'Três itens iguais! Goran, o Ferreiro, os funde em um melhor', { key: 'merge', time: 8 }));
}
