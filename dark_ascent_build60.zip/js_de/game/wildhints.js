// Объяснялка похода: короткие карточки ровно в тот момент, когда правило впервые важно (1–3 строки, один раз),
// постоянная строка цели и «зацепки» при возвращении в деревню. Флаги показа — profile.wild.hints.
import { G, bus } from './ctx.js';
import { REALMS, WILD_QUESTS, locationName, wildReqLevel } from '../data/wild.js';
import { outsideLeft } from './wild.js';
import { nearestCache, dirWord } from './wildmem.js';
import { hunted, displayName, WEAK } from './nemesis.js';

const HINTS = {
  enter: ['So funktionieren Feldzüge', ['🎯 Fünf Felder am Stück, das sechste Gebiet ist ein Fort: Töte die Bestien ringsum, damit sich das Tor öffnet, dann töte den Kommandanten.', '🔒 Das Portal „Tiefer“ bleibt versiegelt, solange der Anführer des Feldes lebt — der Pfeil führt zu ihm.', '🎒 Gold fällt in deine Beute: Sie gehört dir, sobald das Fort erobert ist oder du per Portal gehst.', '☠ Der Kommandant ist dein persönlicher Feind: Verlierst du, merkt er sich dich.']],
  carry: ['Das ist deine Beute', ['Das Gold ist noch nicht in deinem Beutel. Stirbst du, ist es weg.', 'Schwere Beute bremst dich und lockt Feinde an. Erobere das Fort oder geh per Portal – dann gehört sie dir.']],
  nemesis: ['Der Fort-Kommandant ist ein besonderer Feind', ['Er ist stärker als die meisten und merkt sich dich: Stirbst oder fliehst du, kehrt er noch wütender zurück.', 'Töte den Kommandanten für eine dauerhafte Trophäe: etwas mehr Schaden und Gold.']],
  cache: ['Versteck ▣ – eine Bank mitten im Feld', ['Feldzug-Gold liegt in deiner Beute 🎒: Im Feld nimmt der Tod es dir, und schwere Beute bremst dich und lockt Mobs an.', 'Geh zu ▣ und tippe „Versteck“: Deine ganze Beute geht sofort in den Beutel, doch das Versteck nimmt 15 % (25 %, wenn das Feld deine Gier kennt).', 'Unnötig, wenn du das Fort schaffst – es sichert deine Beute gratis.']],
  echo: ['Echos der Gefallenen', ['Durchscheinende Heldensilhouetten sind Spuren derer, die hier fielen (nur Echos, keine echten Spieler).', 'Geh hin und tippe „Echo“: etwas Gold und ein Hinweis auf Gefahr.', 'Fällst du selbst, bleibt dein Echo dort und gibt ¼ der verlorenen Beute zurück.']],
  dead: ['Was geschah', ['Beute verloren – dein Erzfeind hat sie. Besiege ihn, um alles plus eine Trophäe zurückzubekommen.']],
};
let card = null, queue = [], timer = 0;
const seen = () => { const P = G.profile; P.wild = P.wild || {}; return (P.wild.hints = P.wild.hints || {}); };

function render() {
  if (card || !queue.length) return;
  const [title, lines] = queue.shift();
  card = document.createElement('div');
  card.style.cssText = 'position:fixed;inset:0;z-index:60;background:rgba(0,0,0,.45);display:flex;align-items:center;justify-content:center;pointer-events:auto';
  const inner = document.createElement('div'); inner.style.cssText = 'max-width:340px;width:calc(100% - 24px);background:rgba(20,14,26,.94);border:1px solid #d6a548;border-radius:10px;padding:10px 12px;font:14px/1.35 Georgia,serif;color:#efe2c0;box-shadow:0 4px 18px #000a';
  inner.innerHTML = `<div style="font-weight:700;color:#e8c26a;margin-bottom:4px">${title}</div>${lines.map(l => `<div style="margin:3px 0">${l}</div>`).join('')}`; card.appendChild(inner);
  const b = document.createElement('button'); b.textContent = 'Verstanden'; b.className = 'btn sm gold'; b.style.cssText = 'margin-top:6px;pointer-events:auto';
  const close = () => { if (!card) return; card.remove(); card = null; clearTimeout(timer); if (!G.modalOpen) G.paused = false; setTimeout(render, 300); };
  b.onclick = close; inner.appendChild(b); document.body.appendChild(card); if (!G.paused) G.paused = true;   // пока карточка на экране — игра на паузе (враги не бьют, пока вы читаете)
}
export function hint(id) {
  const S = seen(); if (S[id] || !HINTS[id]) return; S[id] = 1; queue.push(HINTS[id]); render(); bus.emit('save');
}
bus.on('zoneEntered', id => { if (card) { card.remove(); card = null; G.paused = false; } queue.length = 0; if (id === 'wild') setTimeout(() => hint('enter'), 700); if (id === 'town') setTimeout(townHooks, 1400); });
bus.on('aggro', e => { if (e.nem) setTimeout(() => hint('nemesis'), 400); });
bus.on('showDeath', () => { if (G.zoneId === 'wild') hint('dead'); });

// Строка цели (под шкалой ноши)
export function goalText() {
  const W = G.wild; if (!W) return '';
  if (W.greed >= 0.5) { const c = nearestCache(); if (c) return `▣ Versteck: ${Math.round(c.d)} m ${dirWord(c.it.x - G.player.x, c.it.y - G.player.y)} – sichere deine Beute`; }   // коротко: строка висит всё время
  if (G.zone && G.zone.json.wild.kind === 'field' && G.zone.inter.some(i => i.id === 'wild_next' && i.sealed)) return W.realm === 'temple' ? '🔒 „Tiefer“ ist versiegelt: Besiege den Wächter des Heiligtums in der Tempelmitte (der Pfeil führt zu ihm)' : '🔒 „Tiefer“ ist versiegelt: Besiege den Anführer des Feldes (der Pfeil führt zu ihm)';   // П20
  if (G.zone && G.zone.json.wild.kind === 'field') { const nd = W.depth + 1; return `🎯 Geh zum Portal „Tiefer“ (Pfeil am Boden) – nächstes Gebiet: ${locationName(W.realm, nd)}, St. ${wildReqLevel(W.realm, nd)}+`; }
  if (G.zone && G.zone.wildGate && !G.zone.wildGate.open) return `🎯 Fort-Tore zu: Töte die Bestien und Lager ringsum (noch ${outsideLeft()})`;
  if (!W.done) { const k = G.enemies.find(e => (e.story === 'wildkeep' || e.story === 'wildboss') && !e.dead); return k ? `🎯 Erobere das Fort: Töte ${k.nem ? k.nem.name : k.D.name} (der Pfeil führt zu ihm)` : ''; }
  return '🎯 Fort erobert, das Gold gehört dir. Sammle die Truhen; wenn du bereit bist – Knopf rechts (Bilanz) oder Portal „Tiefer“ / „Ins Dorf“';
}

// Что делать дальше (для окна портала и приветствия в деревне)
export function nextGoal(realm) {
  const RL = REALMS[realm], hs = hunted(realm);
  if (hs.length) { const n = hs.sort((a, b) => b.rank - a.rank)[0]; return `☠ ${displayName(n)} erwartet dich im Fort${n.stash ? ` und hält ${n.stash} G – räche dich` : ' – räche dich'}`; }
  const ready = WILD_QUESTS[realm].find(q => { const S = G.profile.wild && G.profile.wild[realm]; if (!S) return false; const v = q.stat === 'depth' ? S.depth || 0 : (S.stat || {})[q.stat] || 0; return v >= q.n && !(S.claimed || {})[q.id]; });
  if (ready) return `🎁 Belohnung bereit: „${ready.title}“ – unten abholen`;
  const S = G.profile.wild && G.profile.wild[realm];
  let best = null; for (const q of WILD_QUESTS[realm]) { if (S && (S.claimed || {})[q.id]) continue; const v = S ? (q.stat === 'depth' ? S.depth || 0 : (S.stat || {})[q.stat] || 0) : 0; const left = (q.n - v) / q.n; if (!best || left < best.left) best = { q, left, v }; }
  if (best) return `➡ Als Nächstes: „${best.q.title}“ – ${best.v}/${best.q.n}`;
  return `➡ Geh tiefer: ${RL.short}, Tiefe ${(S && S.best || 0) + 1}`;
}
function townHooks() {
  if (G.zoneId !== 'town' || !G.profile.tutorial.prologue) return;
  for (const realm of Object.keys(REALMS)) {
    const it = G.zone.inter.find(i => i.id === 'portal_' + realm); if (!it) continue;
    const hs = hunted(realm), S = G.profile.wild && G.profile.wild[realm];
    const ready = S ? WILD_QUESTS[realm].filter(q => { const v = q.stat === 'depth' ? S.depth || 0 : (S.stat || {})[q.stat] || 0; return v >= q.n && !(S.claimed || {})[q.id]; }).length : 0;
    it.plate = REALMS[realm].name + (hs.length ? ' ☠' : '') + (ready ? ' 🎁' : '');
  }
  const realm = Object.keys(REALMS).find(r => hunted(r).length) || null;
  if (realm) bus.emit('toast', { text: nextGoal(realm), sub: `Portal: ${REALMS[realm].name}`, kind: 'quest' });
}
