// Сквозная последовательность игры: что открыто и что делать дальше. Единственное место с правилами «замков».
// 1) выбрать первый навык → 2) катакомбы → 3) Старый Лес (уровень 3) → 4) Палач Бездны (уровень 6) →
// 5) Глубины / Выживание / Фьорды (после босса) → 6) Костяные пустоши (после форта Фьордов, Глава III) →
// 7) Цитадель и Морвен (Глава IV). «Летопись битв» открывается по главам вместе с этим.
import { G, bus } from './ctx.js';
import { STORY } from '../data/quests.js';

export const BOSS_LEVEL = 7;
// сборка 47: уровни зон «как в Diablo». У каждой локации свой коридор уровней врагов [от, до]: внутри коридора враг
// всегда на 1 уровень выше героя (≈ +20–30% к здоровью и урону), ниже «от» не опускается (слабым героем рано не пройти),
// выше «до» не растёт — перекачанный герой получает всё меньше опыта (killXP в loot.js) и уходит дальше.
// Катакомбы до первого прохождения — 1–7 (комната задаёт «от»), Хранитель 6–8, Палач 7–10; Глубины и походы — от уровня этажа/поля до него +3.
export const CATA_MAX = 7;
// П57 (правки 2): перекачанный герой больше не проходит зону «одной левой». Боссы, стражи и сюжетные враги (boss = true) всегда
// на уровень выше героя (без потолка зоны); рядовые — в коридоре, но не ниже «герой − 3» (опыта с них уже ×0,3 — повод идти дальше)
export const bandLevel = (min, max, boss) => { const h = (G.profile && G.profile.level) || 1; return boss ? Math.max(min, h + 1) : Math.max(min, Math.min(max, h + 1), h - 3); };
const F = () => G.profile.story.flags;
export const hasSkill = () => G.profile.slots.some(Boolean) || Object.keys(G.profile.skills).length > 0;
const forts = realm => { const S = G.profile.wild && G.profile.wild[realm]; return S && S.stat ? S.stat.forts || 0 : 0; };

// сборка 47: первые шаги без «ускорителей». Пока герой не прошёл Летопись и не вернулся с золотом к Элвину,
// усиления у Элвина закрыты ('upg'); пока не купил первое зелье у Миры — закрыты Источник силы, Хозяйка Колеса,
// реклама за награды и покупки за рубли ('extra'), Мира — до своего шага ('shop'). Иначе игрок сразу всё вкачивает и ломает баланс.
const stIdx = id => STORY.findIndex(q => q.id === id);
export function earlyLock(kind) {
  const s = G.profile && G.profile.story; if (!s) return false;
  const need = kind === 'upg' ? 'hw_elvin' : kind === 'shop' ? 'meet_merchant' : kind === 'pet' ? 'meet_kofi' : 'elder_task';   // 'pet' — подарок Кофи (сборка 60, П15)
  return s.stage < stIdx(need);
}
// сборка 55: первый урок у Элвина платный (55 зол.): после него остаётся ровно на первое зелье здоровья у Миры (30).
// Пока зелье не куплено, другие покупки, после которых на зелье не хватит, не проходят — шаг обучения не застрянет.
export const POTION_RESERVE = 30;
export const firstLessonCost = () => !G.profile || Object.values(G.profile.skills || {}).some(Boolean) ? 0 : Math.max(0, Math.min(55, (G.profile.gold | 0) - POTION_RESERVE));
export function potionReserve(cost) {   // true — покупка запрещена (и показана подсказка)
  const s = G.profile && G.profile.story, q = s && STORY[s.stage]; if (!q || (q.id !== 'learn_skill' && q.id !== 'meet_merchant')) return false;
  if (q.id === 'meet_merchant' && (G.profile.gold | 0) - cost >= POTION_RESERVE) return false;
  bus.emit('toast', q.id === 'learn_skill' ? { text: 'Zuerst die erste Lektion bei Elvin', sub: 'Dieses Gold ist für die Lektion und einen Heiltrank', kind: 'warn' } : { text: 'Zuerst einen Heiltrank bei Mira', sub: 'Dieses Gold ist für den Trank', kind: 'warn' });
  bus.emit('sfx', 'deny'); return true;
}
let lockT = 0;
export function lockToast(kind) {
  if (Date.now() - lockT < 2000) return; lockT = Date.now();
  bus.emit('toast', { text: kind === 'upg' ? 'Upgrades nach der Schlachtchronik' : 'Wird bald freigeschaltet', sub: 'Schließ zuerst das Tutorial ab – folge dem Pfeil', kind: 'warn' }); bus.emit('sfx', 'deny');
}
// null — можно, иначе { text, sub }
// сборка 59: обучение не обойти — Летопись, Жатва и катакомбы открываются своим шагом сюжета (раньше вход открывался по навыку,
// и в Жатву/катакомбы можно было зайти до задания: шаг потом засчитывался сам или стрелка вела не туда)
const early = id => G.profile.story && G.profile.story.stage < stIdx(id);
const EARLY = { text: 'Noch zu früh', sub: 'Erst die Aufgaben im Dorf — folge dem goldenen Pfeil' };
export function gate(name, extra) {
  const P = G.profile;
  if ((name === 'catacombs' && early('find_portal')) || (name === 'survival' && early('surv_try')) || (name === 'hw' && early('hw_try'))) return EARLY;
  switch (name) {
    case 'catacombs': return hasSkill() ? null : { text: 'Wähle zuerst eine Fähigkeit', sub: 'Sprich mit dem Mentor im Dorf (Zeichen «+») und lerne deine erste Fähigkeit' };
    case 'temple': return null;   // Разрушенный храм (портал с руками): открыт сразу со 2 уровня (уровень проверяет портал)
    case 'forest': return !hasSkill() ? { text: 'Wähle zuerst eine Fähigkeit', sub: 'Der Mentor im Dorf lehrt erste Fähigkeiten' } : !F().medallion && !P.world.hasMedallion ? { text: 'Der Wald ist noch verschlossen', sub: 'Bring dem Ältesten das Amulett des Wächters aus den Katakomben – es öffnet den Waldpfad' } : null;
    case 'bones': return !F().bossKilled ? { text: 'Die Öde ist verschlossen', sub: 'Besiege zuerst den Abgrundhenker in den Katakomben' } : forts('fjord') < 1 ? { text: 'Die Knochenöde ist verschlossen', sub: 'Erobere zuerst das Fort des Jarls in den Fjorden – der sterbende Jötunn verrät das vierte Siegel' } : null;
    case 'fjord': return !F().bossKilled ? { text: 'Die Fjorde sind verschlossen', sub: 'Besiege zuerst den Abgrundhenker in den Katakomben' } : forts('forest') < 1 ? { text: 'Die Fjorde sind verschlossen', sub: 'Erobere zuerst die Räuberpalisade im Alten Wald' } : null;
    case 'depths': return F().bossKilled ? null : { text: 'Noch verschlossen', sub: 'Besiege zuerst den Abgrundhenker in den Katakomben' };
    case 'survival': return F().bossKilled || !P.survIntro ? null : { text: 'Ältester: «Das Ernte-Portal hält keine drei Minuten offen»', sub: 'Es öffnet sich wieder, wenn du den Abgrundhenker in den Katakomben besiegst' };   // сборка 47: один забег-знакомство до Палача
    case 'bossgate': return P.level >= BOSS_LEVEL ? null : { text: `Das Siegel weicht nicht: Stufe ${BOSS_LEVEL} nötig`, sub: `Du bist ${P.level}. Werde stärker in Katakomben und Altem Wald, verbessere Ausrüstung beim Schmied` };
    case 'hw': { const s = extra | 0;
      if (!hasSkill()) return { text: 'Wähle zuerst eine Fähigkeit beim Mentor' };
      if (s > 10 && !F().bossKilled) return { text: 'Etappe gesperrt', sub: 'Etappen ab 11 nach dem Sieg über den Abgrundhenker in den Katakomben' };   // сборка 44: 6–10 открыты сразу (было — с 6-го)
      if (s > 30 && forts('forest') < 1) return { text: 'Kapitel «Alter Wald» gesperrt', sub: 'Erobere die Palisade im Alten Wald' };
      if (s > 60 && forts('fjord') < 1) return { text: 'Kapitel «Fjorde» gesperrt', sub: 'Erobere das Fort in den Fjorden' };
      if (s > 90 && !(P.depths && P.depths.best >= 5)) return { text: 'Kapitel «Aschenklippen» gesperrt', sub: 'Erreiche Ebene 5 der Tiefen' };
      return null; }
  }
  return null;
}
// П37 (правки 2): Старый Лес до победы над Палачом — только первые три поля (там задания старосты: Шатун-людоед, волки);
// дальше в лес и к острогу — после Палача Бездны. null — можно
export const FOREST_FREE = 3;
export function wildDepthGate(realm, depth) {
  if (realm === 'forest' && depth > FOREST_FREE && !(G.profile.story.flags.bossKilled)) return { text: 'Das Dickicht lässt dich nicht weiter', sub: `Solange der Abgrundhenker lebt, kommst du im Wald nur bis Feld ${FOREST_FREE}. Brich das Siegel in den Katakomben` };
  return null;
}
// Текст «что делать дальше» для подсказок
export function nextStep() {
  const P = G.profile;
  if (!hasSkill()) return 'Wähle deine erste Fähigkeit beim Mentor';
  if (!F().medallion && !P.world.hasMedallion) return 'Katakomben: Schlüssel → Tür → Wächter besiegen → Amulett zum Ältesten';
  if (!F().bossKilled) return P.level < BOSS_LEVEL ? `Erreiche Stufe ${BOSS_LEVEL} (Katakomben, Alter Wald)` : 'Besiege den Abgrundhenker';
  if (forts('forest') < 1) return 'Erobere die Palisade im Alten Wald';
  if (forts('fjord') < 1) return 'Erobere das Fort in den Fjorden';
  if (forts('bones') < 1) return 'Knochenöde: Erreiche die Ruinen und besiege den Häuptling';
  return 'Geh tiefer: Tiefen, Abgrundernte, Zitadelle';
}
