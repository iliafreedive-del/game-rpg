// Немезис форта + «Ноша».
// Командир форта — личный враг героя: живёт в сохранении (profile.nemesis), помнит поражения и бегство,
// растёт в ранге, копит украденную добычу. Убитый — оставляет трофей с постоянным бонусом.
// «Ноша»: золото в походе копится в рюкзаке и становится вашим, только когда форт отбит или вы вышли через
// портал. Смерть теряет ношу (её забирает немезис). Тяжёлая ноша замедляет и привлекает мобов.
import { G, bus } from './ctx.js';
import * as L from './loot.js';
import { rand, rint, pick } from '../core/util.js';
import { REALMS } from '../data/wild.js';
import { hint, goalText } from './wildhints.js';

const FIRST = { temple: ['Arkas', 'Welimir', 'Korvin', 'Sarat', 'Mordag', 'Elric', 'Taris', 'Ingvar'], bones: ['Grom', 'Durkasch', 'Karg', 'Mugar', 'Zarg', 'Toruk', 'Urgasch', 'Brosk'], fjord: ['Hrolf', 'Björn', 'Ulv', 'Thorgrim', 'Ragnar', 'Gunnar', 'Sveinn', 'Ivar'], forest: ['Prochor', 'Luka', 'Terenti', 'Gawrila', 'Jermak', 'Kondrat', 'Sachar', 'Ignat'] };
const EPI = { temple: ['Der Schänder', 'der Gesichtslose', 'der Aschgraue', 'der Eidbrecher', 'Steinherz', 'Gebrochene Krone'], bones: ['Blutzahn', 'Knochennager', 'Fetzenfell', 'Bruchhauer', 'Sandfresser', 'Schädelbrecher'], fjord: ['Knochenbrecher', 'Zweiblut', 'Eisbart', 'Wolfsbruder', 'Zahnreißer', 'Schwarzhorn'], forest: ['Seelenfresser', 'Schlitzohr', 'Dickichtmann', 'Wolfshirte', 'Einauge', 'Krummmesser'] };
export const RANK_TITLE = ['', 'Heldentöter', 'Geißel von Stillfurt', 'der Schreckliche', 'Dunkler Fürst'];
export const TRAITS = {
  iron: { name: 'Eisenhaut', txt: 'Rüstung +40 %', apply: e => { e.armor = Math.round(e.armor * 1.4); } },
  brute: { name: 'Rohling', txt: 'Schaden +25 %', apply: e => { e.dmgMul *= 1.25; } },
  swift: { name: 'Flinkfuß', txt: 'Tempo +20 %', apply: e => { e.spdBonus = 1.2; } },
  vampire: { name: 'Blutsauger', txt: 'heilt sich durch Treffer', apply: e => { e.vamp = 0.3; } },
  horn: { name: 'Hornist', txt: 'ruft doppelt so oft Hilfe', apply: e => { e.hornMul = 0.5; } },
};
export const WEAK = { fire: 'Feuer', cold: 'Kälte', light: 'Blitz', phys: 'blanken Stahl' };
const WEAK_ELEM = ['fire', 'cold', 'light', 'phys'];

export const nemState = (P = G.profile) => (P.nemesis = P.nemesis || { seq: 0, list: [], trophies: [] });
export const displayName = n => `${n.name}${n.title ? ', ' + n.title : ''}`;
const titleOf = n => RANK_TITLE[Math.min(RANK_TITLE.length - 1, n.rank)] || '';

function create(realm) {
  const S = nemState(), keys = Object.keys(TRAITS), t1 = pick(keys), t2 = pick(keys.filter(k => k !== t1));
  const weak = pick(WEAK_ELEM.filter(w => w !== (realm === 'fjord' ? 'cold' : 'phys')));   // ледяной ярл не слаб к холоду
  const n = { id: ++S.seq, realm, name: `${pick(FIRST[realm])} ${pick(EPI[realm])}`, title: '', rank: 0, traits: [t1, t2], weak, stash: 0, alive: true, defeats: 0, fled: 0 };
  S.list.push(n); return n;
}
// Какой немезис встретит героя в этом форте: охотящийся (с рангом) в приоритете, иначе новый.
export function pickNemesis(realm) {
  const S = nemState(), alive = S.list.filter(n => n.alive && n.realm === realm);
  const hunters = alive.filter(n => n.rank > 0);
  if (hunters.length) return hunters.sort((a, b) => b.rank - a.rank)[0];
  if (alive.length >= 3) return pick(alive);
  return create(realm);
}
export function applyNemesis(e, n) {
  e.nem = n; e.name = displayName(n) + (n.rank ? ' ' + '☠'.repeat(Math.min(n.rank, 4)) : '');
  const r = Math.min(n.rank, 5); e.maxHP = Math.round(e.maxHP * (1 + 0.2 * r)); e.hp = e.maxHP; e.dmgMul *= 1 + 0.1 * r;
  for (const t of n.traits) TRAITS[t].apply(e);
}
function announce(e) {
  const n = e.nem; if (!n) return;
  const line = n.rank ? (n.defeats ? `«Ich erinnere mich an dich, Held! Du fielst durch meine Hand.»` : `«Schon wieder du? Letztes Mal bist du geflohen!»`) : `«Dieses Land gehört mir.»`;
  bus.emit('toast', { text: `${displayName(n)}`, sub: `${line} Stark gegen ${n.traits.map(t => TRAITS[t].name).join(', ')}. `, kind: 'quest' });
}
bus.on('aggro', e => { if (e.nem && !e.nemMet) { e.nemMet = true; announce(e); } });

// ---- ноша
export const carryCap = () => 150 + 110 * (G.zone && G.zone.json.level || 1);   // ~40–60% золота полного зачистки поля (см. tools/qa/wild/econ.mjs)
export function refreshCarry() {
  const W = G.wild; if (!W) return;
  if (W.carry > 0) hint('carry');
  const g = Math.min(1, (W.carry || 0) / carryCap()); W.greed = g; W.slow = 1 - 0.18 * g; W.noise = 1 + 0.7 * g;
  bus.emit('wildCarry');
}
export function addCarry(n) { G.wild.carry = (G.wild.carry || 0) + n; refreshCarry(); }
export function bankCarry(reason) {
  const W = G.wild, P = G.profile; if (!W || !W.carry) return 0;
  const n = W.carry; W.carry = 0; P.gold += n; P.stats.gold += n; bus.emit('gold', n); refreshCarry();
  bus.emit('toast', { text: `Beute gesichert: +${n} G`, sub: reason, kind: 'good' }); bus.emit('hud'); return n;
}
const liveNem = () => G.enemies.find(e => e.nem && !e.dead && e.aggro);

bus.on('playerDeath', () => {
  const W = G.wild; if (G.zoneId !== 'wild' || !W) return; W.died = true;
  const lost = W.carry || 0; W.carry = 0; refreshCarry(); bus.emit('wildDied', { lost, x: G.player.x, y: G.player.y });
  const e = liveNem(), n = e && e.nem;
  if (n) { n.rank++; n.defeats++; n.stash += lost; n.title = titleOf(n); }
  if (lost || n) setTimeout(() => bus.emit('toast', { text: lost ? `Beute verloren: ${lost} G` : 'Du bist gefallen', sub: n ? `${displayName(n)} nahm die Beute und wurde stärker (Rang ${n.rank})` : '', kind: 'warn' }), 1500);
  bus.emit('save');
});
// выход из похода: ноша банкуется, бегство от живого немезиса усиливает его
export function onLeaveWild() {
  const W = G.wild; if (!W) return;
  if (!W.died) {
    bus.emit('wildLeave', { carry: W.carry || 0, cap: carryCap() });
    const e = liveNem(); if (e) { const n = e.nem; n.rank++; n.fled++; n.title = titleOf(n); bus.emit('toast', { text: `${n.name} lacht, als du fliehst`, sub: `Er wurde stärker (Rang ${n.rank})`, kind: 'warn' }); }
    bankCarry('Du hast den Feldzug verlassen');
  }
}
export function onNemesisKilled(e) {
  const n = e.nem, S = nemState(); n.alive = false; n.killedAt = Date.now();
  const bonus = 1 + 0.5 * Math.min(5, n.rank);   // С19: трофей растёт до 5-го ранга, как и сам немезида S.trophies.push({ id: n.id, name: displayName(n), realm: n.realm, rank: n.rank, bonus });
  if (n.stash) { for (let i = 0; i < 5; i++) L.dropGold(e.x, e.y, n.stash / 5 / (G.stats.goldFind ? 1 + G.stats.goldFind / 100 : 1)); }
  bus.emit('toast', { text: `Trophäe: ${displayName(n)}`, sub: `Dauerhaft: +${bonus.toFixed(1)} % Schaden und Gold${n.stash ? `. ${n.stash} G zurückgeholt` : ''}`, kind: 'good' }); bus.emit('sfx', 'epicDrop');
  { const P = G.profile, it = L.rollDrop((P.level || 1) + 1 + Math.min(3, n.rank), [0, 0, 80, 20]);   // сборка 49: вещь с именем немезиса — у неё есть история
    it.name = `${it.name} «${n.name}»`; it.from = { who: displayName(n), where: (REALMS[n.realm] && REALMS[n.realm].name) || '', t: Date.now(), nem: true }; L.dropItem(e.x, e.y, it); }
  n.stash = 0; import('./stats.js').then(m => { G.stats = m.stats(G.profile); bus.emit('statsChanged'); });
}
export const trophyBonus = P => (P.nemesis ? P.nemesis.trophies.reduce((a, t) => a + Math.min(3.5, t.bonus), 0) : 0);
export const hunted = realm => nemState().list.filter(n => n.alive && n.realm === realm && n.rank > 0);

// ---- полоса «Ноша»
let bar = null, goalTimer = 0;
function ensureBar() {
  if (bar) return bar; bar = document.createElement('div'); bar.id = 'carryBar';
  // сборка 38: вид — в css (#carryBar): маленькая плашка слева под полосами здоровья, не посередине экрана
  bar.style.display = 'none';
  bar.innerHTML = '<div class="t"></div><div class="cb"><i></i></div><div class="g"></div>';
  document.body.appendChild(bar); return bar;
}
// кнопка справа: форт отбит — «Итог / выход» (не выскакивает окном сама)
let exitBtn = null;
function drawExit() {
  const W = G.wild, show = G.zoneId === 'wild' && W && W.done && W.result;
  if (!exitBtn) {
    exitBtn = document.createElement('button'); exitBtn.id = 'wildExit'; exitBtn.className = 'btn gold';
    exitBtn.innerHTML = '<span class="we-ar">▶▶</span><b>Fort erobert</b><small>Bilanz & Ausgang</small>';
    exitBtn.onclick = () => { if (G.wild && G.wild.result) bus.emit('wildCleared', G.wild.result); };
    document.body.appendChild(exitBtn);
  }
  exitBtn.style.display = show && !G.modalOpen ? 'flex' : 'none';
  // под миникартой (раньше стояла поверх неё); если миникарта скрыта — у правого края под трекером
  if (show) { const mm = document.getElementById('minimap'), r = mm && mm.offsetParent !== null ? mm.getBoundingClientRect() : null; exitBtn.style.top = (r && r.height ? Math.round(r.bottom + 8) : 150) + 'px'; }
}
function drawBar() {
  drawExit();
  const b = ensureBar(), W = G.wild;
  if (G.zoneId !== 'wild' || !W) { b.style.display = 'none'; return; }
  b.style.display = 'block'; const pct = Math.round((W.greed || 0) * 100);
  b.querySelector('.t').textContent = `🎒 Beute: ${W.carry || 0} G${pct > 8 ? ` · Gier ${pct} %` : ''}`;
  b.querySelector('i').style.width = pct + '%';
  // цель похода — только несколько секунд после того, как сменилась, потом прячется (не висит на экране постоянно)
  const g = b.querySelector('.g'), gt = goalText();
  if (g.textContent !== gt) { g.textContent = gt; g.classList.add('show'); clearTimeout(goalTimer); goalTimer = setTimeout(() => g.classList.remove('show'), 7000); }
}
bus.on('wildCarry', drawBar); bus.on('zoneEntered', drawBar); bus.on('hud', drawBar);
