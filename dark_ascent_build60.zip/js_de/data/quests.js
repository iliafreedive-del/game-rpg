// Chapter I «Пробуждение под катакомбами». Objectives are checked by game/quests.js
// against real counters/flags — nothing is credited for actions the player did not perform.
export const CHAPTER = 'Kapitel I. Der letzte Siegelwächter';
export const CHAPTERS = { 1: CHAPTER, 2: 'Kapitel II. Schatten hinter der Schwelle', 3: 'Kapitel III. Knochen der Riesen', 4: 'Kapitel IV. Morvens Zitadelle' };
export const chapterOf = q => CHAPTERS[(q && q.chapter) || 1];
export const STORY = [
  // сборка 60 (П3): первое умение дарит староста (свиток приёма Ордена) — бесплатно, за стартовое очко навыка. Второго уровня до Летописи нет:
  // опыт задач обучения не переводит героя на 2-й уровень (quests.js grant), уровень 2 — в Летописи (herospath.js)
  { id: 'talk_elder', title: 'Sprich mit dem Ältesten', text: 'Ältester Edric wartet am Platz bei der Kirche.', obj: { talk: 'elder' }, reward: { xp: 10, potions: 2, skill: 'first', items: [{ slot: 'weapon', tier: 1, rarity: 1, names: { warrior: 'Klinge des Milizionärs', archer: 'Bogen des Jägers', mage: 'Stab des Kräuterkundigen' } }] }, where: 'town', target: 'elder' },
  // сборка 38: после старосты — к наставнику за первым навыком, потом обратно к старосте за заданием в катакомбы
  // сборка 60 (П32): окно героя — портрет слева вверху → «Герой»: надетое, сумка, сравнение вещей
  { id: 'hero_gear', title: 'Ausrüstung ansehen', text: 'Tippe oben links aufs Heldenporträt, dann auf „Held“: Dort sind angelegte Items und Tasche. Tippe auf ein Item – du siehst, ob es besser (▲) oder schlechter (▼) als das angelegte ist.', obj: { flag: 'invSeen' }, reward: { xp: 5, gold: 5 }, where: 'town' },
  { id: 'learn_skill', title: 'Wähle eine Fähigkeit beim Mentor', text: 'Mentor Elvin steht an der Trainingspuppe. Lerne bei ihm deine erste Fähigkeit – danach bleibt genau genug für einen Heiltrank.', obj: { skill: true }, reward: { xp: 20 }, where: 'town', target: 'trainer' },
  // сборка 55: зелье — сразу после первого навыка (остаётся ровно 30 золота на него), только потом Летопись: иначе золото уходило Элвину и шаг «купить зелье» застревал
  { id: 'meet_merchant', title: 'Kauf einen Trank bei Händlerin Mira', text: 'Händlerin Mira verkauft Heiltränke. Kauf einen: Im Kampf heilt er dich. Danach stell dich der Chronik der Schlachten.', obj: { flag: 'potBought' }, reward: { xp: 5, potions: 1 }, where: 'town', target: 'merchant' },
  // сборка 43: после навыка — «Летопись битв» (автобои), пока герой не проиграет; потом староста отправляет качаться в катакомбы
  // сборка 60 (П8, П10): в первой Летописи третья победа даёт 2-й уровень; «Сбежать» — с 3-го боя, отступление тоже завершает шаг
  { id: 'hw_try', title: 'Stell dich der Schlachtchronik', text: 'Der Bogen „Schlachtchronik“ steht am Platz. Der Kampf läuft automatisch – meistere Etappen, solange deine Kraft reicht: Siege bringen Gold und EP, der dritte eine neue Stufe.', obj: { hwTry: true }, reward: { xp: 20, gold: 95 }, where: 'town', target: 'herospath' },
  // сборка 47: после Летописи — снова к Элвину (золото из Летописи → усиление), потом к Мире за зельем и рывком; только потом открывается остальное
  { id: 'hw_elvin', title: 'Stärke deinen Helden bei Elvin', text: 'Die Chronik zeigte: Du bist noch schwach. Bring das Gold zu Mentor Elvin (bei den Übungspuppen, folge dem Pfeil) und gib es für eins von beiden aus: Steigere den Rang einer Fähigkeit (Knopf „Fähigkeiten“) oder kauf das Upgrade „Schlagkraft“ / „Robustheit“. Beides zählt.', obj: { flag: 'upgBought' }, reward: { xp: 20 }, where: 'town', target: 'trainer' },
  // сборка 47: пробная Жатва Бездны на 3 минуты — показать режим в начале; потом портал закрывается до победы над Палачом
  { id: 'surv_try', title: 'Überstehe die Abgrundernte', text: 'Der Älteste hat das Portal der Abgrundernte geöffnet. Halte so lange durch, wie du kannst: Der Held greift selbst an, du läufst nur und sammelst Kristalle.', obj: { flag: 'survTried' }, reward: { xp: 20 }, where: 'town', target: 'portal_survival' },
  { id: 'surv_elvin', title: 'Noch ein Upgrade bei Elvin', text: 'Gold aus der Ernte – wieder zu Mentor Elvin. Kauf noch ein Upgrade oder steigere den Rang einer Fähigkeit – beides zählt.', obj: { flag: 'upgBought2' }, reward: { xp: 20 }, where: 'town', target: 'trainer' },
  { id: 'elder_task', title: 'Kehr zum Ältesten zurück', text: 'Die Chronik war zu schwer. Ältester Edric sagt dir, wo du EP sammeln kannst.', obj: { talk: 'elder' }, reward: { xp: 20, gold: 20 }, where: 'town', target: 'elder' },
  // сборка 60 (П15): перед катакомбами староста отправляет к караванщику Кофи — тот дарит первого питомца (раньше Кофи дарил его сразу)
  { id: 'meet_kofi', title: 'Besuche Karawanenhändler Kofi', text: 'Karawanenhändler Kofi lagert an der Weggabelung zur Öde. Der Älteste sagt, er hat ein Geschenk für deine Reise.', obj: { kofi: true }, reward: { xp: 20 }, where: 'town', target: 'caravan' },
  { id: 'find_portal', title: 'Finde das Portal', text: 'Das alte Ordensportal steht im Nordwesten des Dorfes.', obj: { near: 'portal_town' }, reward: { xp: 20 }, where: 'town', target: 'portal_town' },
  { id: 'enter', title: 'Betritt die Katakomben', text: 'Tritt ins Portal, um in die Katakomben hinabzusteigen.', obj: { enter: 'catacombs' }, reward: { xp: 30, scrolls: 2, gold: 20 }, where: 'town', target: 'portal_town' },
  { id: 'kill20', title: 'Vernichte 20 Skelette', text: 'Untote kriechen aus dem Ossarium. Bring 20 Skelette zur Ruhe und kehr dann für eine Belohnung zum Ältesten zurück.', obj: { count: 'skeletons', n: 20 }, turnIn: true, reward: { xp: 150, gold: 40, skillPts: 1, items: [{ slot: 'chest', tier: 2, rarity: 1, names: { warrior: 'Ordenskettenhemd', archer: 'Rüstung des Fährtenlesers', mage: 'Mantel des Beschwörers' } }] }, where: 'catacombs' },
  // П34 (правки 2): «100 золота» убрано из цепочки — теперь это долгий контракт кузнеца «5000 золота» на доске (REPEATABLE r_gold5000)
  { id: 'medallion', title: 'Bring das Amulett des Wächters', text: 'Der Älteste bittet dich, das Amulett des Wächters zu holen. Der Türschlüssel ist in einem der Sarkophage der Katakomben versteckt – öffne sie; hinter der Osttür bewacht der Wächter das Amulett – besiege ihn zuerst.', obj: { flag: 'medallion' }, turnIn: true, reward: { xp: 250, gold: 120, skillPts: 1, items: [{ slot: 'amulet', tier: 1, rarity: 1, names: { warrior: 'Amulett des Wächters', archer: 'Amulett des Wächters', mage: 'Amulett des Wächters' } }] }, where: 'catacombs', target: 'medallion' },
  // П37 (правки 2): Старый Лес открылся — у старосты для него два дела (поле 1–3; дальше в лес — после Палача, progress.js wildDepthGate)
  { id: 'f_bear', title: 'Der Menschenfresser-Bär im Alten Wald', text: 'Die Jäger von Stillfurt kehren nicht aus dem Alten Wald zurück: Auf dem Feld am Portal streift ein Menschenfresser-Bär umher. Betritt das grüne Portal, töte das Biest und kehre dann zum Dorfältesten zurück.', obj: { flag: 'forestBear' }, turnIn: true, reward: { xp: 300, gold: 250, potions: 2, items: [{ slot: 'chest', tier: 2, rarity: 1, names: { warrior: 'Kettenhemd der Waldwacht', archer: 'Jacke der Waldwacht', mage: 'Robe der Waldwacht' } }] }, where: 'town', target: 'portal_forest' },
  { id: 'f_wolves', title: 'Das Wolfsrudel', text: 'Die Grauwölfe des Alten Waldes reißen das Vieh am Dorfrand. Töte 10 Wölfe – die Rudel kehren immer wieder auf die Felder zurück, die Jagd endet nie. Dann zum Dorfältesten.', obj: { count: 'wolves', n: 10 }, turnIn: true, reward: { xp: 250, gold: 220, scrolls: 2, shards: 3 }, where: 'town', target: 'portal_forest' },  { id: 'reach_gate', title: 'Erreiche das versiegelte Tor', text: 'Das versiegelte Tor östlich der Wachhalle führt zum Hort des Henkers.', obj: { near: 'gate' }, reward: { xp: 60, potions: 3 }, where: 'catacombs', target: 'gate' },
  { id: 'open_gate', title: 'Öffne den Weg zum Boss', text: 'Das Siegel weicht nur einem Helden der Stufe 7. Werde stärker in den Katakomben und im Alten Wald.', obj: { flag: 'gateOpen' }, reward: { xp: 60, skillPts: 1 }, where: 'catacombs', target: 'gate' },
  { id: 'boss', title: 'Besiege den Abgrundhenker', text: 'Der Abgrundhenker wartet in der Arena. Achte auf seine Ausholbewegungen – seinen Hieben kannst du ausweichen.', obj: { flag: 'bossKilled' }, reward: { xp: 300, gold: 150, items: [{ slot: 'weapon', epic: true }] }, where: 'catacombs', target: 'boss' },
  { id: 'return', title: 'Kehr ins Dorf zurück', text: 'Nach dem Tod des Henkers hat sich ein Portal nach Hause geöffnet.', obj: { enter: 'town' }, reward: { xp: 50, gold: 50 }, where: 'catacombs', target: 'portal_return' },
  { id: 'finish', title: 'Hol dir die Belohnung beim Ältesten', text: 'Erzähl Edric von deinem Sieg.', obj: { talk: 'elder' }, reward: { xp: 250, gold: 300, items: [{ slot: 'chest', tier: 3, rarity: 2, names: { warrior: 'Stillfurter Plattenpanzer', archer: 'Stillfurter Umhang', mage: 'Stillfurter Gewand' } }] }, where: 'town', target: 'elder' },
  // ---- Глава II «Тени за порогом» (сборка 16): ведёт по уже открытому миру — Фьорды, Старый Лес, Глубины, Летопись, форты.
  // obj: wild {realm, n} — дойти до n-й локации похода (n = 7 — пройти через первый форт); depths n — рекорд Глубин; hw n — пройден этап Летописи
  // сборка 47: сначала Старый Лес — Фьорды закрыты до его форта, а стрелка вела во Фьорды
  // сборка 47: цепочка к Глубинам — синий портал открывается после Палача, но к нему не вело ни одно задание
  { id: 'c2_stone', chapter: 2, title: 'Zeig Elvin den Stein des Henkers', text: 'Aus der Asche des Abgrundhenkers fiel ein blauer Stein, kalt wie Eis. Mentor Elvin kennt die Zeichen des Ordens – zeig ihm den Stein.', obj: { talk: 'trainer' }, reward: { xp: 120, gold: 100 }, where: 'town', target: 'trainer' },
  { id: 'c2_depths_portal', chapter: 2, title: 'Finde das blaue Portal', text: 'Elvin: „Das ist der Schlüsselstein der Tiefen – der alten Ordensmine unter den Katakomben. Das blaue Portal im Dorf schlief hundert Jahre, doch der Stein weckt es.“ Folge dem Pfeil.', obj: { near: 'portal_depths' }, reward: { xp: 60, potions: 1 }, where: 'town', target: 'portal_depths' },
  { id: 'c2_depths3', chapter: 2, title: 'Erreiche Ebene 3 der Tiefen', text: 'Der Henker kam von unten, aus den Tiefen. Finde heraus, wie tief der Abgrund reicht: Schaff drei Ebenen. Neue Ebenen brauchen keine Fackel, solange du siegst.', obj: { depths: 3 }, reward: { xp: 300, gold: 200 }, where: 'town', target: 'portal_depths' },
  { id: 'c2_forest_fort', chapter: 2, title: 'Erobere das Fort im Alten Wald', text: 'Fünf Felder im Alten Wald, das sechste ist das Fort. Räum die Lager, öffne das Tor, besiege den Kommandanten und geh „Tiefer“.', obj: { wild: { realm: 'forest', n: 7 } }, reward: { xp: 450, gold: 450, shards: 5 }, where: 'town', target: 'portal_forest' },
  { id: 'c2_fjord_portal', chapter: 2, title: 'Finde das Eisportal', text: 'Das Portal zu Skjolds Fjorden liegt im Nordosten des Dorfes, hinter dem Weinberg, am Bach. Folge dem Pfeil.', obj: { near: 'portal_fjord' }, reward: { xp: 60, gold: 80, potions: 2 }, where: 'town', target: 'portal_fjord' },
  { id: 'c2_fjord3', chapter: 2, title: 'Schaff drei Fjord-Felder', text: 'Betritt das Eisportal und schaff drei Felder am Stück (über die Portale „Tiefer“).', obj: { wild: { realm: 'fjord', n: 4 } }, reward: { xp: 260, gold: 260, shards: 3 }, where: 'town', target: 'portal_fjord' },
  { id: 'c2_depths5', chapter: 2, title: 'Erreiche Ebene 5 der Tiefen', text: 'Das blaue Portal ist im Dorf. Neue Ebenen brauchen keine Fackel, solange du siegst.', obj: { depths: 5 }, reward: { xp: 300, gold: 300, items: [{ slot: 'amulet', set: 1 }] }, where: 'town', target: 'portal_depths' },
  { id: 'c2_hw10', chapter: 2, title: 'Schlachtchronik: 10 Etappen', text: 'Der Bogen „Schlachtchronik“ steht am Platz. Kämpfe laufen automatisch: dein Held gegen 2–4 Feinde, 1 ⚡ pro Kampf.', obj: { hw: 10 }, reward: { xp: 350, gold: 350, items: [{ slot: 'head', set: 1 }] }, where: 'town', target: 'herospath' },
  { id: 'c2_depths10', chapter: 2, title: 'Erreiche Ebene 10 der Tiefen', text: 'Ab Ebene 8 werden Feinde schneller stärker: Verbessere deinen Helden beim Mentor und härte Ausrüstung beim Schmied.', obj: { depths: 10 }, reward: { xp: 600, gold: 600, shards: 8 }, where: 'town', target: 'portal_depths' },
  { id: 'c2_fjord_fort', chapter: 2, title: 'Erobere das Fjord-Fort', text: 'Das Eisfort des Jarls liegt hinter fünf Fjord-Feldern: Lager ringsum, Tor, Kommandant.', obj: { wild: { realm: 'fjord', n: 7 } }, reward: { xp: 800, gold: 800, items: [{ slot: 'weapon', tier: 3, rarity: 2 }] }, where: 'town', target: 'portal_fjord' },
  { id: 'c2_finish', chapter: 2, title: 'Berichte dem Ältesten', text: 'Edric wartet auf Nachricht von den Fjorden und dem Wald.', obj: { talk: 'elder' }, reward: { xp: 900, gold: 1000, shards: 10, items: [{ slot: 'chest', set: 1 }] }, where: 'town', target: 'elder' },
  // ---- Глава III «Кости великанов» (сборка 45): четвёртая печать в Костяных пустошах
  { id: 'c3_portal', chapter: 3, title: 'Finde das Knochenportal', text: 'Der sterbende Jötunn sagte, das vierte Siegel liege in der Öde. Ein Portal aus Schädeln und Rippen steht im linken Teil des Dorfes.', obj: { near: 'portal_bones' }, reward: { xp: 700, gold: 400, potions: 3 }, where: 'town', target: 'portal_bones' },
  { id: 'c3_fields3', chapter: 3, title: 'Schaff drei Felder der Öde', text: 'Rote Steppe, Schädeltal, dornige Schluchten. Geh durch die Portale „Tiefer“.', obj: { wild: { realm: 'bones', n: 4 } }, reward: { xp: 900, gold: 700, shards: 5 }, where: 'town', target: 'portal_bones' },
  { id: 'c3_scorpid', chapter: 3, title: 'Töte drei Panzerskorpione', text: 'Panzerskorpione hausen ab Tiefe 3 in den Schluchten. Schmied Goran braucht ihr Chitin.', obj: { wildStat: { realm: 'bones', key: 'k_b_scorpid', n: 3 } }, turnIn: true, turnTo: 'smith', reward: { xp: 900, gold: 600, items: [{ slot: 'head', tier: 3, rarity: 2 }] }, where: 'town' },
  { id: 'c3_depths15', chapter: 3, title: 'Erreiche Ebene 15 der Tiefen', text: 'Das Siegel hält durch die Kraft seines Wächters. Sammle sie in den Tiefen.', obj: { depths: 15 }, reward: { xp: 1200, gold: 1000, shards: 8 }, where: 'town', target: 'portal_depths' },
  { id: 'c3_fort', chapter: 3, title: 'Erobere die Alten Ruinen', text: 'Hinter fünf Feldern der Öde liegen die Ruinen von Häuptling Blutzahn. Räum die Lager, öffne das Tor, besiege den Häuptling.', obj: { wild: { realm: 'bones', n: 7 } }, reward: { xp: 1600, gold: 1400, items: [{ slot: 'weapon', set: 1 }] }, where: 'town', target: 'portal_bones' },
  { id: 'c3_boss', chapter: 3, title: 'Besiege den Knochenkoloss', text: 'Das vierte Siegel bewacht der Erwachte Knochenkoloss tief in der Öde (jedes 12. Gebiet).', obj: { flag: 'seal_bones' }, reward: { xp: 2400, gold: 2000, shards: 12, items: [{ slot: 'weapon', epic: true }] }, where: 'town', target: 'portal_bones' },
  { id: 'c3_elvin', chapter: 3, title: 'Sprich mit Mentor Elvin', text: 'Deine Erinnerung ist ganz zurück. Elvin schuldet dir eine Erklärung.', obj: { talk: 'trainer' }, reward: { xp: 1200, gold: 800, skillPts: 1 }, where: 'town', target: 'trainer' },
  // ---- Глава IV «Цитадель Морвена»: финал
  { id: 'c4_castle', chapter: 4, title: 'Betritt die Ordenszitadelle', text: 'Morven hat die Zitadelle geöffnet. Das Portal steht im linken Teil des Dorfes.', obj: { enter: 'castle' }, reward: { xp: 1200, gold: 800, potions: 5 }, where: 'town', target: 'portal_castle' },
  { id: 'c4_hw30', chapter: 4, title: 'Schlachtchronik: 30 Etappen', text: 'Die Ordenschronik verzeichnet auch deine alten Kämpfe. Schaff 30 Etappen und lies, was dort über dich steht.', obj: { hw: 30 }, reward: { xp: 1800, gold: 1200, items: [{ slot: 'head', set: 1 }] }, where: 'town', target: 'herospath' },
  { id: 'c4_depths20', chapter: 4, title: 'Erreiche Ebene 20 der Tiefen', text: 'Morven hält die Zitadelle mit der Macht des Abgrunds. Je tiefer du ihn kennst, desto weniger hilft er ihm.', obj: { depths: 20 }, reward: { xp: 2200, gold: 1800, shards: 12 }, where: 'town', target: 'portal_depths' },
  { id: 'c4_trial', chapter: 4, title: 'Besiege Morven in der Halle der Prüfungen', text: 'Halle der Prüfungen der Zitadelle: Wähle die Prüfung „Großmeister Morven“. Braucht ein Prüfungssiegel (füllt sich von selbst).', obj: { flag: 'morven' }, reward: { xp: 4000, gold: 4000, shards: 25, items: [{ slot: 'weapon', epic: true }, { slot: 'chest', set: 1 }] }, where: 'town', target: 'portal_castle' },
  { id: 'c4_finish', chapter: 4, title: 'Berichte Edric und Elvin', text: 'Der Abgrund ist versiegelt. Das Dorf muss es erfahren.', obj: { talk: 'elder' }, reward: { xp: 5000, gold: 5000, shards: 30, items: [{ slot: 'amulet', epic: true }] }, where: 'town', target: 'elder' },
];

// Ежедневные и недельные задания — js/game/daily.js; здесь — «долгие» контракты доски: прогресс идёт сам после принятия.
export const REPEATABLE = [
  { id: 'r_kill100', title: 'Vernichte 300 Monster', stat: 'kills', n: 300, reward: { gold: 700, xp: 900 } },
  { id: 'r_walk1000', title: 'Leg 4000 Meter zurück', stat: 'meters', n: 4000, reward: { gold: 400, potions: 5 } },
  { id: 'r_gold1000', title: 'Sammle 4000 Gold', stat: 'gold', n: 4000, reward: { gold: 700, xp: 600 } },
  { id: 'r_elite5', title: 'Töte 15 Elitegegner', stat: 'elites', n: 15, reward: { gold: 900, items: [{ slot: 'weapon', tier: 2, rarity: 2 }] } },
  { id: 'r_chest10', title: 'Öffne 30 Truhen', stat: 'chests', n: 30, reward: { gold: 500, potions: 5 } },
  // П34 (правки 2): кузнецу на серебро — 5000 золота, только добытого в бою (подобранного с врагов и сундуков и вынесенного из похода; не реклама, не покупки, не награды)
  { id: 'r_gold5000', once: true, title: 'Silber für Goran: 5000 Gold erbeuten', stat: 'gold', n: 5000, reward: { gold: 1500, xp: 1500, shards: 5, items: [{ slot: 'weapon', tier: 2, rarity: 2, noClamp: true, names: { warrior: 'Gorans versilberte Klinge', archer: 'Gorans versilberter Bogen', mage: 'Gorans versilberter Stab' } }] } },
  { id: 'r_boss', title: 'Besiege einen Boss, ohne zu sterben', stat: 'bossNoDeath', n: 1, reward: { gold: 600, xp: 600, items: [{ slot: 'weapon', epic: true }] } },
];


export const DIALOG = {
  elder: {
    0: ['Endlich! Du bist aus der Gruft gekommen – und dort war hundert Jahre niemand. Ich bin Edric, der Älteste von Stillfurt.',
        'Unter dem Dorf sperrte der Orden den Abgrund mit vier Siegeln ein. Heute Nacht brach das erste, und aus den Katakomben krochen Tote.',
        'Du weißt selbst nicht, wer du bist? Die Fassung an deinem Hals ist das Amulett eines Siegelwächters. Vier Fassungen, alle leer.',
        'Für solche Fälle hat der Orden eine Schriftrolle mit einer Wächtertechnik hinterlassen. Lies sie – dein Körper erinnert sich von selbst.',
        'Jetzt schau in deine Tasche und Ausrüstung – tippe auf dein Porträt. Dann zu Händlerin Mira für einen Trank.'],
    skill: ['Zuerst zu Mentor Elvin. Ohne Fähigkeit hältst du nicht durch.'],
    hero_gear: ['Sieh nach, was du trägst: Tippe oben links auf dein Porträt, dann auf „Held“.'],
    meet_kofi: ['Karawanenhändler Kofi wartet an seinem Wagen an der Gabelung. Schau bei ihm vorbei – dann ab in die Katakomben.'],
    shop: ['Du hast jetzt eine Fähigkeit. Geh zur Händlerin Mira und kauf einen Heiltrank – im Kampf rettet er dich. Dein Gold reicht für genau einen.'],
    hw: ['Fähigkeit hast du, Trank auch – zeig, was du kannst. Der Bogen „Schlachtchronik“ steht am Platz: Dort läuft der Kampf von selbst. Mach weiter, solange deine Kraft reicht: Siege bringen Gold und EP, der dritte eine neue Stufe. Danach zu Elvin: Er zeigt dir, wie du stärker wirst.'],
    task: ['Die Ernte gesehen? Länger halte ich das Portal nicht offen. Es öffnet sich erst wieder, wenn der Henker in den Katakomben fällt.',
           'Elvin hat dich gestärkt, Mira hat Tränke – du bist bereit. Aber noch zu schwach: Du musst leveln.',
           'Steig in die Ordenskatakomben hinab – das Portal liegt im Nordwesten, hinter der Mühle. Dort ist das erste Siegel, und dort erfährst du, wer es bricht.',
           'Aber schau zuerst bei Karawanenhändler Kofi vorbei – sein Wagen steht an der Gabelung. Er hat dir ein Geschenk für den Weg versprochen: In den Katakomben schadet ein Begleiter nicht.',
           'Versiegelst du es neu, öffnet sich der Weg zu den anderen drei: Wald, Fjorde, Öde.'],
    // сборка 59: шаги обучения между Летописью и катакомбами — раньше староста говорил про катакомбы, где герой ещё не был
    hw_elvin: ['Die Chronik hat gezeigt, wo du schwach bist. Bring das Gold zu Mentor Elvin — er verkauft dir eine Verstärkung.'],
    surv_try: ['Ich habe das Portal der Abgrundernte einen Spalt geöffnet — folge dem goldenen Pfeil. Lange halte ich es nicht: etwa drei Minuten.', 'Dort kämpft der Held von selbst. Deine Aufgabe: laufen und Kristalle sammeln. Halte durch, so lange du kannst.'],
    surv_elvin: ['Hat dir die Ernte Gold gebracht? Bring es zu Elvin — noch eine Verstärkung schadet nicht.'],
    find_portal: ['Das Portal zu den Katakomben liegt im Nordwesten des Dorfes, hinter der Mühle. Folge dem goldenen Pfeil.'],
    mid: ['Die Katakomben sind tief. Wird es hart, kehr zurück. Schmied Goran verbessert deine Waffe, und Mira verkauft Tränke.'],
    f_bear: ['Ich habe das Amulett – und der Pfad in den Alten Wald ist offen. Das grüne Portal steht im Dorf.', 'Nur kehren die Jäger nicht zurück: Direkt am Portal streift ein Menschenfresser-Bär umher. Töte ihn und komm wieder.'],
    f_wolves: ['Die Wölfe des Alten Waldes reißen das Vieh am Dorfrand. Erlege ein Dutzend – sie kommen immer wieder, Arbeit gibt es genug.'],
    after_medallion: ['Ich habe das Amulett – also lässt sich das Siegel noch öffnen … Doch dahinter liegt, was der Orden vor Ewigkeiten wegsperrte. Das Siegel lässt nur einen Helden der Stufe 7 durch.'],
    turnin: {
      kill20: ['Zwanzig Skelette zur Ruhe gebracht! Die Leute atmen auf.', 'Hier dein Lohn: eine Rüstung, die wir für so einen Tag aufbewahrt haben.'],
      f_bear: ['Der Menschenfresser ist tot? Die Jäger gehen wieder in den Wald. Nimm diese Rüstung der Waldwacht.', 'Aber im Wald sind noch Wölfe – hörst du sie am Dorfrand heulen?'],
      f_wolves: ['Zehn Wölfe – das Rudel ist gelichtet, das Vieh ist sicher. Hier ist deine Belohnung.', 'Geh nicht tiefer in den Wald, solange der Henker lebt: Das Dickicht gehorcht dem Abgrund. Brich das Siegel in den Katakomben.'],
      medallion: ['Das Amulett des Wächters … Du hast den Wächter besiegt! Der Hüter des Ordens hat endlich Ruhe.', 'Behalt es – an dir nützt es mehr als auf meinem Tisch.'],
    },
    finish: ['Du bist zurück, und die Dunkelheit unter dem Dorf ist verstummt. Der Abgrundhenker ist gefallen, das erste Siegel ist wieder heil!',
             'Und der Stein in deiner Fassung leuchtet. Es stimmt also: Du bist der Wächter.',
             'Drei Siegel bleiben: im Wald, in den Fjorden und in der Öde. Und am Anschlagbrett beim Platz gibt es immer Arbeit für dich.',
             'Noch etwas: Hast du einen blauen Stein aus der Asche des Henkers geholt? Zeig ihn Elvin – er kennt die Zeichen des Ordens.'],
    done: ['Vier Siegel heil, der Abgrund versiegelt, Morven besiegt. Stillfurt steht für immer in deiner Schuld.', 'Das Anschlagbrett wartet auf Helden, und die Abgrundkreise auf alle, denen das nicht reicht.'],
  },
  smith: { turnin: { gold100: 'Hundert Gold! Ich gieße Silber gegen Untote. Nimm diesen Helm und schau vorbei: Ich verschmelze drei Items zu einem besseren.' }, hello: ['Goran, der Schmied. Untote sind zäh – Stahl muss zäher sein.', 'Bring mir Waffe oder Rüstung, und ich mache sie besser. Der Preis steigt mit jeder Härtungsstufe.'] },
  merchant: { hello: ['Mira, zu Diensten! Tränke, Schriftrollen und ein fairer Preis für deine Beute.'] },
  trainer: { hello: ['Ich bin Elvin, Mentor des Ordens. Feuer, Eis und Blitz gehorchen denen, die lernen.', 'Ich lehre dich die Grundlagen der Magie und helfe dir gegen Gebühr, deinen Weg neu zu wählen.'],
    // Глава III: герой вспомнил всё и приходит к Элвину за объяснением (сцена — js/data/story.js MEMORIES.elvin)
    // сборка 47: начало цепочки к Глубинам (задание c2_stone)
    stone: ['Ein blauer Stein aus dem Herzen des Henkers … Lass sehen. Das ist der Schlüsselstein der Tiefen – der alten Ordensmine unter den Katakomben.',
            'Der Henker hat das Siegel nicht bewacht. Er kam von unten, aus den Tiefen. Der Abgrund nagt also von dort an den Siegeln.',
            'Das blaue Portal im Dorf schlief hundert Jahre. Mit dem Stein wird es antworten. Steig drei Ebenen hinab, dann sehen wir, wie tief er reicht.'],
    confess: ['Du erinnerst dich. Ich wusste, dieser Tag würde kommen.', 'Ja, ich habe dich in Schlaf versetzt. Morven hätte dich noch in jener Nacht getötet, doch schlafend fand er dich nie.', 'Er hat die Ordenszitadelle geöffnet und erwartet dich dort. Geh. Ich habe dich alles gelehrt, was ich wusste.'] },
};
