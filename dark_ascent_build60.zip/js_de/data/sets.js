// Сеты (сборка 16): три части — шлем, доспех, амулет (без требований, любой класс). Бонус за 2 и за 3 надетые части.
// Сеты навыков дают +ранги ветви (как свойство «+к навыкам»), остальные — обычные свойства (goldFind, hp, armorPct, dmgPct…).
// Части точатся у кузнеца как обычные вещи. Выпадают вместо части редких вещей и из сундуков Ордена (js/game/loot.js).
export const SET_SLOTS = ['head', 'chest', 'amulet'];
export const SET_BASE = { head: 'cap', chest: 'jerkin', amulet: 'amulet' };
export const SETS = {
  sword: { name: 'Klingeneid', branch: 'sword', cls: ['warrior'], parts: { head: 'Eideshelm', chest: 'Eidesbrigantine', amulet: 'Eidessiegel' }, b2: { skills: 1 }, b3: { skills: 1, dmgPct: 15 } },
  fire: { name: 'Asche des Ordens', branch: 'fire', cls: ['warrior', 'mage'], parts: { head: 'Aschenkapuze', chest: 'Aschenmantel', amulet: 'Aschenglut' }, b2: { skills: 1 }, b3: { skills: 1, dmgPct: 15 } },
  bow: { name: 'Rabenfeder', branch: 'bow', cls: ['archer'], parts: { head: 'Federmaske', chest: 'Federumhang', amulet: 'Rabenkralle' }, b2: { skills: 1 }, b3: { skills: 1, dmgPct: 15 } },
  ice: { name: 'Winterschneide', branch: 'ice', cls: ['archer', 'mage'], parts: { head: 'Schneidenkrone', chest: 'Schneidenpelz', amulet: 'Schneideneiszapfen' }, b2: { skills: 1 }, b3: { skills: 1, dmgPct: 15 } },
  light: { name: 'Sturmauge', branch: 'light', cls: ['mage'], parts: { head: 'Sturmreif', chest: 'Sturmgewand', amulet: 'Sturmauge' }, b2: { skills: 1 }, b3: { skills: 1, dmgPct: 15 } },
  gold: { name: 'Glücklicher Sucher', cls: ['warrior', 'archer', 'mage'], parts: { head: 'Hut des Suchers', chest: 'Jacke des Suchers', amulet: 'Münze des Suchers' }, b2: { goldFind: 30 }, b3: { goldFind: 40, hp: 40 } },
  guard: { name: 'Bollwerk von Stillfurt', cls: ['warrior', 'archer', 'mage'], parts: { head: 'Bollwerkhelm', chest: 'Bollwerkrüstung', amulet: 'Bollwerksiegel' }, b2: { hp: 90 }, b3: { armorPct: 30, hp: 60 } },
};
// текст бонуса для карточки
const NAMES = { goldFind: v => `+${v} % Gold`, hp: v => `+${v} Leben`, armorPct: v => `+${v} % Abwehr`, dmgPct: v => `+${v} % Schaden`, crit: v => `+${v} % Krit-Chance` };
export function bonusText(set, b) { const S = SETS[set]; return Object.entries(b).map(([k, v]) => k === 'skills' ? `+${v} auf alle Fähigkeiten des Zweigs` : NAMES[k] ? NAMES[k](v) : `${k} +${v}`).join(', '); }
