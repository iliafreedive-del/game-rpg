// «Походы»: открытые локации-поля с порталов деревни — Фьорды Скъёльда, Старый Лес и Костяные пустоши.
// Здесь только данные: мобы, миры, настроение по глубине, задания. Логика — world/wildgen.js, game/wildai.js, game/wild.js.
//
// Поля мобов: from/filter/size — временная графика (перекраска существующих спрайтов), tele — телеграф атаки
// {shape: cone|circle|line, at: self|target, r, arc, w, rift(фиолетовый), elem, slow, mult}.

const T = (shape, o) => ({ shape, ...o });

export const WILD_MOBS = {
  // ------------------------------------------------------------- Фьорды
  f_draugr: { realm: 'fjord', name: 'Draugr-Schildträger', from: 'skel_warrior', filter: 'hue-rotate(170deg) saturate(.8) brightness(1.1)', size: 1.1, ai: 'melee', hp: 40, dmg: [4, 7], speed: 2.2, range: 1.2, cd: 2.0, impact: 0.55, xp: 16, gold: [3, 8], armor: 14, radius: 0.36, fps: { walk: 10, attack: 10 } },
  f_wolf: { realm: 'fjord', name: 'Eiswolf', from: 'beast', filter: 'saturate(.12) brightness(1.5)', size: 0.96, ai: 'pack', hp: 20, dmg: [3, 5], speed: 4.3, range: 1.1, cd: 2.2, impact: 0.5, xp: 12, gold: [1, 4], armor: 3, radius: 0.34, onHit: 'slow', fps: { walk: 16, attack: 12 }, tele: { lunge: T('line', { r: 3.4, w: 0.6 }) } },
  f_berserk: { realm: 'fjord', name: 'Berserker', from: 'skel_warrior', filter: 'sepia(1) saturate(3.5) hue-rotate(-35deg) brightness(1.05)', size: 1.12, ai: 'charge', hp: 36, dmg: [5, 9], speed: 3.1, range: 1.2, cd: 1.5, impact: 0.5, xp: 20, gold: [3, 9], armor: 5, radius: 0.36, charge: { r: 4.2, w: 0.8, cd: 5.5, speed: 8.5, mult: 1.3 }, fury: 0.5, fps: { walk: 13, attack: 12 }, tele: { lunge: T('line', { r: 4.2, w: 0.8 }) } },
  f_hag: { realm: 'fjord', name: 'Schneehexe', from: 'skel_mage', filter: 'hue-rotate(150deg) brightness(1.3) saturate(.9)', size: 1.0, ai: 'caster', hp: 26, dmg: [5, 8], elem: 'cold', onHit: 'slow', speed: 2.1, range: 8, keep: 6, cd: 2.8, impact: 0.55, xp: 24, gold: [5, 12], armor: 2, radius: 0.32, proj: 'shard', fps: { attack: 8 } },
  f_jotun: { realm: 'fjord', name: 'Jötunnriese', from: 'beast', filter: 'hue-rotate(160deg) saturate(.6) brightness(1.55)', size: 1.75, ai: 'giant', hp: 150, dmg: [10, 15], speed: 1.8, range: 2.0, cd: 2.4, impact: 0.6, xp: 70, gold: [15, 35], armor: 14, radius: 0.62, onHit: 'slow', fps: { walk: 8, attack: 7 }, tele: { attack: T('cone', { r: 2.8, arc: 100, mult: 1.0 }), attack2: T('circle', { at: 'target', r: 2.1, mult: 1.2, rift: true, elem: 'cold', slow: 2 }) } },
  f_jarl: { realm: 'fjord', name: 'Jarl Hrolf Knochenbrecher', from: 'elite', filter: 'hue-rotate(160deg) brightness(1.2) saturate(.9)', size: 1.18, elite: true, ai: 'jarl', hp: 300, dmg: [10, 15], speed: 2.6, range: 1.8, cd: 1.8, impact: 0.6, xp: 220, gold: [90, 140], armor: 22, radius: 0.52, minion: ['f_draugr', 'f_berserk'], fps: { walk: 10, attack: 10, attack2: 10 }, tele: { attack: T('cone', { r: 2.7, arc: 80 }), attack2: T('circle', { at: 'self', r: 2.6, mult: 0.9 }) } },
  f_boss: { realm: 'fjord', name: 'Jötunn Skjold', from: 'boss', filter: 'hue-rotate(165deg) brightness(1.25) saturate(.8)', size: 1.2, boss: true, ai: 'wildboss', hp: 800, dmg: [12, 18], speed: 2.4, range: 2.5, cd: 1.7, impact: 0.6, xp: 700, gold: [260, 340], armor: 28, radius: 0.8, onHit: 'slow', minion: ['f_wolf', 'f_wolf', 'f_draugr'], novaElem: 'cold', fps: { walk: 9, attack: 10, attack2: 10, slam: 11, roar: 9 }, tele: { attack: T('cone', { r: 3.4, arc: 75 }), attack2: T('circle', { at: 'self', r: 3.2, mult: 0.9 }), slam: T('circle', { at: 'target', r: 2.2, mult: 1.3, rift: true, elem: 'cold', slow: 2.5 }) } },

  // ------------------------------------------------------------- Старый Лес
  w_boar: { realm: 'forest', name: 'Hauer', from: 'beast', filter: 'sepia(1) saturate(1.6) brightness(.8)', size: 0.88, ai: 'charge', hp: 38, dmg: [6, 10], speed: 2.9, range: 1.2, cd: 1.8, impact: 0.5, xp: 17, gold: [2, 7], armor: 7, radius: 0.4, charge: { r: 5.5, w: 0.9, cd: 4.5, speed: 9.5, mult: 1.5, crashStun: 1.4 }, fps: { walk: 12, attack: 12 }, tele: { lunge: T('line', { r: 5.5, w: 0.9 }) } },
  w_wolf: { realm: 'forest', name: 'Grauwolf', from: 'beast', filter: 'saturate(.1) brightness(.85)', size: 0.96, ai: 'pack', hp: 18, dmg: [3, 5], speed: 4.3, range: 1.1, cd: 2.2, impact: 0.5, xp: 11, gold: [1, 4], armor: 2, radius: 0.34, fps: { walk: 16, attack: 12 }, tele: { lunge: T('line', { r: 3.4, w: 0.6 }) } },
  w_poacher: { realm: 'forest', name: 'Wilderer', from: 'skel_archer', filter: 'sepia(1) saturate(1.8) brightness(.85)', size: 1.05, ai: 'archer', hp: 22, dmg: [4, 7], speed: 2.4, range: 8.5, keep: 5.5, cd: 2.0, impact: 0.66, xp: 16, gold: [4, 10], armor: 3, radius: 0.32, proj: 'arrow', fps: { attack: 9 } },
  w_leshy: { realm: 'forest', name: 'Waldschrat', from: 'skel_mage', filter: 'hue-rotate(75deg) saturate(1.7) brightness(.9)', size: 1.22, ai: 'root', hp: 46, dmg: [6, 10], speed: 2.0, range: 8, keep: 6, cd: 3.3, impact: 0.6, xp: 30, gold: [6, 14], armor: 6, radius: 0.36, fps: { attack: 8 }, tele: { attack: T('circle', { at: 'target', r: 1.8, mult: 1.0, rift: true, slow: 2.2 }) } },
  w_bear: { realm: 'forest', name: 'Streunender Bär', from: 'beast', filter: 'sepia(.8) brightness(.55) saturate(1.2)', size: 1.4, ai: 'giant', hp: 120, dmg: [9, 14], speed: 2.3, range: 1.9, cd: 2.2, impact: 0.55, xp: 60, gold: [10, 26], armor: 12, radius: 0.6, enrage: 0.5, fps: { walk: 9, attack: 9 }, tele: { attack: T('cone', { r: 2.4, arc: 95, mult: 1.0 }), attack2: T('circle', { at: 'self', r: 2.2, mult: 1.1 }) } },
  w_ataman: { realm: 'forest', name: 'Anführer Schlitzohr', from: 'elite', filter: 'sepia(1) saturate(2.2) hue-rotate(-20deg) brightness(.95)', size: 1.12, elite: true, ai: 'jarl', hp: 280, dmg: [9, 14], speed: 2.7, range: 1.8, cd: 1.7, impact: 0.6, xp: 200, gold: [80, 130], armor: 18, radius: 0.5, minion: ['w_poacher', 'w_wolf', 'w_wolf'], fps: { walk: 10, attack: 10, attack2: 10 }, tele: { attack: T('cone', { r: 2.6, arc: 80 }), attack2: T('circle', { at: 'self', r: 2.4, mult: 0.9 }) } },
  w_boss: { realm: 'forest', name: 'Herr des Dickichts', from: 'boss', filter: 'hue-rotate(90deg) saturate(1.5) brightness(.9)', size: 1.25, boss: true, ai: 'wildboss', hp: 720, dmg: [12, 17], speed: 2.5, range: 2.5, cd: 1.7, impact: 0.6, xp: 650, gold: [240, 320], armor: 24, radius: 0.8, minion: ['w_wolf', 'w_wolf', 'w_boar'], novaElem: 'phys', fps: { walk: 9, attack: 10, attack2: 10, slam: 11, roar: 9 }, tele: { attack: T('cone', { r: 3.4, arc: 75 }), attack2: T('circle', { at: 'self', r: 3.2, mult: 0.9 }), slam: T('circle', { at: 'target', r: 2.2, mult: 1.3, rift: true, slow: 2.5 }) } },
  // ------------------------------------------------------------- Костяные пустоши (сборка 17: дикари и скорпион пока на временных моделях — заменятся в сборке 18)
  b_raider: { realm: 'bones', name: 'Reißzahn-Schlitzer', from: 'skel_warrior', filter: 'sepia(1) saturate(2.4) hue-rotate(-25deg) brightness(.95)', size: 1.12, ai: 'melee', hp: 34, dmg: [4, 7], speed: 2.5, range: 1.2, cd: 1.8, impact: 0.55, xp: 15, gold: [3, 8], armor: 8, radius: 0.38, fps: { walk: 11, attack: 11 } },
  b_thrower: { realm: 'bones', name: 'Reißzahn-Werfer', from: 'skel_archer', filter: 'sepia(1) saturate(2) hue-rotate(-20deg) brightness(.95)', size: 1.05, ai: 'archer', hp: 22, dmg: [4, 7], speed: 2.4, range: 8, keep: 5.5, cd: 2.1, impact: 0.66, xp: 15, gold: [4, 10], armor: 3, radius: 0.34, proj: 'bone', fps: { attack: 9 } },
  b_hyena: { realm: 'bones', name: 'Tüpfelhyäne', from: 'beast', filter: 'sepia(1) saturate(1.3) brightness(1.05)', size: 0.78, ai: 'pack', hp: 17, dmg: [3, 5], speed: 4.4, range: 1.1, cd: 2.1, impact: 0.5, xp: 11, gold: [1, 4], armor: 2, radius: 0.33, fps: { walk: 16, attack: 12 }, tele: { lunge: T('line', { r: 3.4, w: 0.6 }) } },
  b_boar: { realm: 'bones', name: 'Wüsteneber', from: 'beast', filter: 'sepia(1) saturate(2) hue-rotate(-15deg) brightness(.9)', size: 0.9, ai: 'charge', hp: 36, dmg: [6, 9], speed: 2.9, range: 1.2, cd: 1.8, impact: 0.5, xp: 16, gold: [2, 7], armor: 7, radius: 0.4, charge: { r: 5.5, w: 0.9, cd: 4.5, speed: 9.5, mult: 1.5, crashStun: 1.4 }, fps: { walk: 12, attack: 12 }, tele: { lunge: T('line', { r: 5.5, w: 0.9, mult: 1.5 }) } },
  b_shaman: { realm: 'bones', name: 'Knochennager-Schamane', from: 'skel_mage', filter: 'sepia(1) saturate(2.6) hue-rotate(-30deg) brightness(1)', size: 1.08, ai: 'root', hp: 40, dmg: [6, 9], speed: 2.0, range: 8, keep: 6, cd: 3.2, impact: 0.6, xp: 28, gold: [6, 14], armor: 5, radius: 0.34, fps: { attack: 8 }, tele: { attack: T('circle', { at: 'target', r: 1.8, mult: 1.0, rift: true, slow: 2.0 }) } },
  b_scorpid: { realm: 'bones', name: 'Panzerskorpion', from: 'beast', filter: 'sepia(1) saturate(1.5) hue-rotate(-30deg) brightness(.7)', size: 1.45, ai: 'giant', hp: 125, dmg: [9, 14], speed: 2.2, range: 1.9, cd: 2.2, impact: 0.55, xp: 62, gold: [10, 26], armor: 18, radius: 0.62, onHit: 'slow', fps: { walk: 10, attack: 9 }, tele: { attack: T('cone', { r: 2.4, arc: 90, mult: 1.0 }), attack2: T('circle', { at: 'self', r: 2.6, mult: 1.3 }) } },
  b_chief: { realm: 'bones', name: 'Häuptling Blutzahn', from: 'elite', filter: 'sepia(1) saturate(2.6) hue-rotate(-25deg) brightness(.95)', size: 1.15, elite: true, ai: 'jarl', hp: 290, dmg: [9, 14], speed: 2.6, range: 1.8, cd: 1.7, impact: 0.6, xp: 210, gold: [85, 135], armor: 20, radius: 0.52, minion: ['b_raider', 'b_hyena', 'b_hyena'], fps: { walk: 10, attack: 10, attack2: 10 }, tele: { attack: T('cone', { r: 2.2, arc: 110, mult: 1.0 }), attack2: T('circle', { at: 'self', r: 2.8, mult: 1.4 }) } },
  b_boss: { realm: 'bones', name: 'Erwachter Knochenkoloss', from: 'boss', filter: 'sepia(1) saturate(1.2) brightness(1.1)', size: 1.3, boss: true, ai: 'wildboss', hp: 760, dmg: [12, 18], speed: 2.4, range: 2.5, cd: 1.7, impact: 0.6, xp: 680, gold: [250, 330], armor: 26, radius: 0.85, minion: ['b_hyena', 'b_hyena', 'b_raider'], novaElem: 'phys', fps: { walk: 9, attack: 10, attack2: 10, slam: 11, roar: 9 }, tele: { attack: T('cone', { r: 3.4, arc: 75 }), attack2: T('circle', { at: 'self', r: 3.2, mult: 0.9 }), slam: T('circle', { at: 'target', r: 2.2, mult: 1.3, rift: true, slow: 2.5 }) } },
  // ------------------------------------------------------------- Разрушенный храм (портал с руками, со 2 уровня). model3d — чья 3D-модель
  // показывается, пока нет своих моделей из пака храма (мелкие мобы, 5 мини-боссов, большие боссы — заменятся по паку)
  t_warden: { realm: 'temple', name: 'Ruinenwächter', from: 'skel_warrior', model3d: 'skel_warrior', filter: 'saturate(.3) brightness(1.15)', size: 1.05, ai: 'melee', hp: 26, dmg: [3, 5], speed: 2.4, range: 1.2, cd: 1.9, impact: 0.55, xp: 11, gold: [2, 6], armor: 6, radius: 0.36, fps: { walk: 11, attack: 11 } },
  t_archer: { realm: 'temple', name: 'Felsbrocker', from: 'skel_archer', model3d: 'skel_archer', filter: 'saturate(.3) brightness(1.15)', size: 1.0, ai: 'archer', hp: 19, dmg: [3, 5], speed: 2.2, range: 8, keep: 5.5, cd: 2.2, impact: 0.66, xp: 11, gold: [3, 7], armor: 4, radius: 0.36, proj: 'rock', fps: { attack: 9 } },   // правки 2 (П18): Валунник бросает камни, не синюю ледышку
  t_hound: { realm: 'temple', name: 'Steinwolf', from: 'beast', model3d: 'bone_wolf', filter: 'saturate(.1) brightness(1.3)', size: 0.94, ai: 'pack', hp: 14, dmg: [2, 4], speed: 4.2, range: 1.1, cd: 2.2, impact: 0.5, xp: 9, gold: [1, 3], armor: 2, radius: 0.33, fps: { walk: 16, attack: 12 }, tele: { lunge: T('line', { r: 3.4, w: 0.6 }) } },
  t_ghoul: { realm: 'temple', name: 'Steinerner Panzerreiter', from: 'ghoul', model3d: 'ghoul', filter: 'hue-rotate(40deg) saturate(.6)', size: 1.0, ai: 'charge', hp: 24, dmg: [4, 6], speed: 2.8, range: 1.2, cd: 1.8, impact: 0.5, xp: 12, gold: [2, 6], armor: 3, radius: 0.36, charge: { r: 4.0, w: 0.8, cd: 5.5, speed: 8, mult: 1.25 }, fps: { walk: 12, attack: 12 }, tele: { lunge: T('line', { r: 4.0, w: 0.8 }) } },
  t_priest: { realm: 'temple', name: 'Windgeist', from: 'skel_mage', model3d: 'skel_mage', filter: 'sepia(.6) saturate(1.4) brightness(1.1)', size: 1.0, ai: 'root', hp: 30, dmg: [4, 7], speed: 2.0, range: 8, keep: 6, cd: 3.3, impact: 0.6, xp: 18, gold: [4, 10], armor: 3, radius: 0.34, fps: { attack: 8 }, tele: { attack: T('circle', { at: 'target', r: 1.8, mult: 1.0, rift: true, slow: 2.0 }) } },
  t_golem: { realm: 'temple', name: 'Steingolem', from: 'beast', model3d: 'f_jotun', filter: 'saturate(0) brightness(1.2)', size: 1.55, ai: 'giant', hp: 95, dmg: [7, 11], speed: 1.9, range: 1.9, cd: 2.3, impact: 0.6, xp: 45, gold: [8, 20], armor: 14, radius: 0.58, fps: { walk: 8, attack: 8 }, tele: { attack: T('cone', { r: 2.4, arc: 95, mult: 1.0 }), attack2: T('circle', { at: 'self', r: 2.6, mult: 1.2 }) } },
  // сборка 59: каменные звери пака «каменная»
  t_boar: { realm: 'temple', name: 'Steinkeiler', from: 'beast', model3d: 'w_boar', filter: 'saturate(0) brightness(1.3)', size: 0.9, ai: 'charge', hp: 34, dmg: [5, 8], speed: 2.8, range: 1.2, cd: 1.9, impact: 0.5, xp: 15, gold: [2, 7], armor: 9, radius: 0.42, charge: { r: 5.0, w: 0.9, cd: 5, speed: 9, mult: 1.4, crashStun: 1.2 }, fps: { walk: 12, attack: 12 }, tele: { lunge: T('line', { r: 5.0, w: 0.9 }) } },
  t_lion: { realm: 'temple', name: 'Steinlöwe', from: 'beast', model3d: 'w_wolf', filter: 'saturate(0) brightness(1.3)', size: 1.05, ai: 'melee', hp: 44, dmg: [6, 9], speed: 3.4, range: 1.4, cd: 1.9, impact: 0.55, xp: 20, gold: [3, 8], armor: 8, radius: 0.46, fps: { walk: 14, attack: 12 } },
  t_stag: { realm: 'temple', name: 'Steinhirsch', from: 'beast', model3d: 'w_wolf', filter: 'saturate(0) brightness(1.3)', size: 1.4, ai: 'charge', hp: 30, dmg: [4, 7], speed: 3.6, range: 1.3, cd: 2.0, impact: 0.5, xp: 15, gold: [2, 6], armor: 5, radius: 0.4, charge: { r: 6.0, w: 0.8, cd: 5.5, speed: 10, mult: 1.3 }, fps: { walk: 14, attack: 12 }, tele: { lunge: T('line', { r: 6.0, w: 0.8 }) } },
  // пять мини-боссов храма: по одному в святилище каждого из пяти лабиринтов
  t_mb_gate: { realm: 'temple', name: 'Torwächter des Tempels', from: 'elite', model3d: 'elite_guard', filter: 'saturate(.3) brightness(1.15)', size: 1.12, elite: true, mini: true, ai: 'jarl', hp: 170, dmg: [6, 10], speed: 2.5, range: 1.8, cd: 1.8, impact: 0.6, xp: 90, gold: [35, 60], armor: 14, radius: 0.5, minion: ['t_warden', 't_hound'], fps: { walk: 10, attack: 10, attack2: 10 }, tele: { attack: T('cone', { r: 2.1, arc: 90, mult: 1.0 }), attack2: T('circle', { at: 'self', r: 2.4, mult: 1.3 }) } },
  t_mb_relic: { realm: 'temple', name: 'Wächterlöwe', from: 'elite', model3d: 'elite_warlord', filter: 'sepia(.5) brightness(1.1)', size: 1.14, elite: true, mini: true, ai: 'jarl', hp: 180, dmg: [6, 10], speed: 2.4, range: 1.9, cd: 1.8, impact: 0.6, xp: 95, gold: [35, 60], armor: 16, radius: 0.52, minion: ['t_warden', 't_archer'], fps: { walk: 10, attack: 10, attack2: 10 }, tele: { attack: T('cone', { r: 2.2, arc: 95, mult: 1.0 }), attack2: T('circle', { at: 'self', r: 2.5, mult: 1.3 }) } },
  t_mb_paladin: { realm: 'temple', name: 'Steinstier', from: 'elite', model3d: 'f_jarl', filter: 'saturate(.4) brightness(1.1)', size: 1.14, elite: true, mini: true, ai: 'jarl', hp: 190, dmg: [7, 11], speed: 2.6, range: 1.8, cd: 1.7, impact: 0.6, xp: 100, gold: [40, 65], armor: 18, radius: 0.52, minion: ['t_warden', 't_ghoul'], fps: { walk: 10, attack: 10, attack2: 10 }, tele: { attack: T('cone', { r: 2.1, arc: 90, mult: 1.0 }), attack2: T('circle', { at: 'self', r: 2.4, mult: 1.3 }) } },
  t_mb_hierophant: { realm: 'temple', name: 'Steinkönig', from: 'elite', model3d: 'w_ataman', filter: 'sepia(.6) saturate(1.3)', size: 1.12, elite: true, mini: true, ai: 'jarl', hp: 175, dmg: [7, 11], speed: 2.5, range: 1.8, cd: 1.8, impact: 0.6, xp: 100, gold: [40, 65], armor: 14, radius: 0.5, minion: ['t_priest', 't_hound', 't_hound'], fps: { walk: 10, attack: 10, attack2: 10 }, tele: { attack: T('cone', { r: 2.1, arc: 90, mult: 1.0 }), attack2: T('circle', { at: 'self', r: 2.4, mult: 1.3 }) } },
  t_mb_sentinel: { realm: 'temple', name: 'Steinerner Wachposten', from: 'elite', model3d: 'b_chief', filter: 'saturate(0) brightness(1.2)', size: 1.16, elite: true, mini: true, ai: 'jarl', hp: 210, dmg: [7, 12], speed: 2.3, range: 1.9, cd: 1.9, impact: 0.6, xp: 110, gold: [45, 70], armor: 20, radius: 0.54, minion: ['t_warden', 't_archer', 't_hound'], fps: { walk: 10, attack: 10, attack2: 10 }, tele: { attack: T('cone', { r: 2.2, arc: 95, mult: 1.0 }), attack2: T('circle', { at: 'self', r: 2.5, mult: 1.3 }) } },
  // большие боссы храма: Осквернитель — в святилище шестого уровня, Падший бог — на двенадцатом
  t_lord: { realm: 'temple', name: 'Herr des Heiligtums', from: 'elite', model3d: 'w_boss', filter: 'saturate(.3) brightness(1.05)', size: 1.2, elite: true, ai: 'jarl', hp: 300, dmg: [9, 14], speed: 2.5, range: 2.2, cd: 1.8, impact: 0.6, xp: 220, gold: [90, 140], armor: 20, radius: 0.7, minion: ['t_warden', 't_priest', 't_hound'], fps: { walk: 9, attack: 10, attack2: 10 }, tele: { attack: T('cone', { r: 2.6, arc: 100, mult: 1.0 }), attack2: T('circle', { at: 'self', r: 2.8, mult: 1.3 }) } },
  t_boss: { realm: 'temple', name: 'Gefallener Gott des Tempels', from: 'boss', model3d: 'b_boss', filter: 'saturate(.2) brightness(1.2)', size: 1.3, boss: true, ai: 'wildboss', hp: 760, dmg: [12, 18], speed: 2.4, range: 2.5, cd: 1.7, impact: 0.6, xp: 680, gold: [250, 330], armor: 26, radius: 0.85, minion: ['t_warden', 't_hound', 't_golem'], novaElem: 'phys', fps: { walk: 9, attack: 10, attack2: 10, slam: 11, roar: 8 }, tele: { attack: T('cone', { r: 2.8, arc: 110, mult: 1.0 }), attack2: T('circle', { at: 'self', r: 3.2, mult: 1.2 }), slam: T('circle', { at: 'target', r: 2.4, mult: 1.5 }) } },
};

export const REALMS = {
  fjord: {
    id: 'fjord', name: 'Skjolds Fjorde', short: 'Fjorde', portalColor: [150, 210, 255], portal: 'portal_spire', reqLevel: 5, baseLevel: 5,
    blurb: 'Verschneite Küsten, gefrorene Buchten und Jötunnfesten. Draugr, Eiswölfe und Schneehexen halten die eroberten Forts.',
    pool: [['f_draugr', 1], ['f_wolf', 1], ['f_berserk', 1], ['f_hag', 2], ['f_jotun', 3]],   // [тип, с какой глубины]
    commander: 'f_jarl', boss: 'f_boss', fortName: 'Erobertes Fort',
    // настроение по глубине (меняется каждые 2 уровня): пол, свет, туман, частицы
    moods: [
      { name: 'Küste', ground: [226, 234, 242], alt: [214, 226, 238], water: [58, 98, 140], tint: null, dark: false, fog: [10, 14, 24], particles: { c: [245, 250, 255], rate: 18, vz: -1.2, g: 0.2, size: 2.5, life: 2.4 }, lake: 0.10 },
      { name: 'Gletscher', ground: [200, 218, 235], alt: [190, 210, 230], water: [40, 78, 125], tint: 'rgba(90,140,200,0.16)', dark: false, fog: [8, 14, 30], particles: { c: [225, 240, 255], rate: 34, vz: -2.0, g: 0.3, size: 2.5, life: 1.8 }, lake: 0.18 },
      { name: 'Hallen der Jötnar', ground: [150, 176, 214], alt: [140, 166, 206], water: [22, 44, 90], tint: 'rgba(40,80,170,0.30)', dark: true, fog: [4, 8, 24], particles: { c: [150, 230, 255], rate: 22, vz: 0.5, g: -0.1, size: 3, life: 2.2 }, lake: 0.22 },
    ],
  },
  forest: {
    id: 'forest', name: 'Alter Wald', short: 'Wald', portalColor: [120, 230, 120], portal: 'portal_gate', reqLevel: 3, baseLevel: 3,
    blurb: 'Ein dichter Wald hinter dem Dorf. Eber, Wölfe und Bären; Wilderer beherrschen die Pfade, und im Dickicht streift ein Waldschrat umher.',
    pool: [['w_boar', 1], ['w_wolf', 1], ['w_poacher', 1], ['w_leshy', 2], ['w_bear', 3]],
    commander: 'w_ataman', boss: 'w_boss', fortName: 'Räuberpalisade',
    moods: [
      { name: 'Waldrand', ground: [70, 104, 48], alt: [58, 90, 40], water: [48, 84, 96], tint: null, dark: false, fog: [4, 10, 4], particles: { c: [255, 240, 170], rate: 8, vz: 0.4, g: -0.1, size: 2.5, life: 2.2 }, lake: 0.05 },
      { name: 'Dickicht', ground: [52, 82, 40], alt: [42, 70, 34], water: [34, 64, 74], tint: 'rgba(10,40,20,0.25)', dark: false, fog: [2, 8, 4], particles: { c: [190, 255, 160], rate: 14, vz: 0.5, g: -0.1, size: 2.5, life: 2.4 }, lake: 0.08 },
      { name: 'Sumpfwildnis', ground: [40, 62, 40], alt: [32, 52, 36], water: [26, 52, 56], tint: 'rgba(10,30,30,0.32)', dark: true, fog: [2, 7, 8], particles: { c: [200, 255, 120], rate: 16, vz: 0.3, g: -0.1, size: 3, life: 2.8 }, lake: 0.16 },
    ],
  },
  bones: {
    id: 'bones', name: 'Knochenöde', short: 'Öde', portalColor: [255, 150, 70], portal: 'portal_bone', reqLevel: 12, baseLevel: 12,   // сборка 45: пустоши — Глава III, после форта Фьордов (уровни подняты с временных 2/3)
    blurb: 'Rote Halbwüste zwischen den Knochen uralter Riesen. Wilde mit Reißzähnen hausen in Hütten aus Fell und Rippen; in den Schluchten lauern Hyänen, Eber und Skorpione. Hinter den Feldern liegen die Alten Ruinen.',
    pool: [['b_raider', 1], ['b_hyena', 1], ['b_boar', 1], ['b_thrower', 1], ['b_shaman', 2], ['b_scorpid', 3]],
    commander: 'b_chief', boss: 'b_boss', fortName: 'Alte Ruinen',
    moods: [
      { name: 'Rote Steppe', ground: [176, 102, 58], alt: [160, 92, 52], water: [48, 98, 104], tint: null, dark: false, fog: [24, 12, 6], particles: { c: [255, 220, 170], rate: 10, vz: 0.2, g: 0.05, size: 2.5, life: 2.6 }, lake: 0.02 },
      { name: 'Staubige Schluchten', ground: [168, 96, 56], alt: [150, 86, 50], water: [44, 90, 98], tint: 'rgba(160,80,30,0.12)', dark: false, fog: [26, 12, 6], particles: { c: [240, 200, 150], rate: 22, vz: 0.1, g: 0.02, size: 2.5, life: 2.4 }, lake: 0.02 },
      { name: 'Riesenfriedhof', ground: [140, 80, 54], alt: [124, 70, 48], water: [34, 70, 80], tint: 'rgba(120,40,40,0.22)', dark: true, fog: [20, 8, 8], particles: { c: [255, 170, 110], rate: 14, vz: 0.4, g: -0.05, size: 3, life: 2.6 }, lake: 0.0 },
    ],
  },
  temple: {
    id: 'temple', name: 'Verfallener Tempel', short: 'Tempel', portalColor: [255, 214, 150], portal: 'portal_hands', reqLevel: 2, baseLevel: 2,
    blurb: 'Ein uralter Steintempel, zerborsten und von Büschen überwuchert. Seine Gänge verschieben sich jedes Mal. Im Heiligtum jedes Labyrinths wartet ein Wächter.',
    pool: [['t_warden', 1], ['t_hound', 1], ['t_archer', 1], ['t_stag', 1], ['t_boar', 2], ['t_ghoul', 2], ['t_priest', 2], ['t_lion', 3], ['t_golem', 3]],
    minis: ['t_mb_gate', 't_mb_relic', 't_mb_paladin', 't_mb_hierophant', 't_mb_sentinel'],   // мини-босс святилища по номеру лабиринта (1–5)
    commander: 't_lord', boss: 't_boss', fortName: 'Tempelheiligtum',
    moods: [
      { name: 'Äußerer Hof', ground: [150, 142, 120], alt: [138, 130, 110], water: [48, 84, 96], tint: null, dark: false, fog: [10, 10, 8], particles: { c: [255, 240, 200], rate: 8, vz: 0.3, g: -0.05, size: 2.5, life: 2.4 }, lake: 0 },
      { name: 'Überwucherte Galerien', ground: [128, 132, 104], alt: [116, 120, 96], water: [40, 74, 84], tint: 'rgba(30,50,20,0.14)', dark: false, fog: [6, 10, 6], particles: { c: [210, 255, 170], rate: 12, vz: 0.4, g: -0.1, size: 2.5, life: 2.4 }, lake: 0 },
      { name: 'Inneres Heiligtum', ground: [112, 104, 96], alt: [100, 94, 88], water: [30, 54, 70], tint: 'rgba(60,40,90,0.22)', dark: true, fog: [8, 6, 14], particles: { c: [255, 210, 140], rate: 14, vz: 0.5, g: -0.1, size: 3, life: 2.6 }, lake: 0 },
    ],
  },
};
// Цикл похода: пять разных открытых полей подряд, в конце каждого — портал «Вглубь» (следующее поле требует уровня);
// шестая локация — захваченный форт (сцена с отбиванием форта). Каждый второй форт — босс.
export const FIELDS_PER_FORT = 5;
export const FORT_EVERY = FIELDS_PER_FORT + 1, BOSS_EVERY = FORT_EVERY * 2;
export const isWildFort = d => d % FORT_EVERY === 0;
export const isWildBoss = d => d % BOSS_EVERY === 0;
export const FIELD_NAMES = {
  forest: ['Waldrand', 'Birkenhain', 'Felsige Bäche', 'Tiefer Kiefernwald', 'Windbruch'],
  bones: ['Rote Steppe', 'Schädeltal', 'Dornige Schluchten', 'Riesenrücken', 'Staubige Hügelgräber'],
  temple: ['Äußerer Hof', 'Säulengang', 'Überwucherter Kreuzgang', 'Halle der Gelübde', 'Zerborstenes Kirchenschiff'],
  fjord: ['Uferstreifen', 'Eisfeld', 'Windschlucht', 'Gefrorene Bucht', 'Jötunngräber'],
};
export const fieldVariant = d => isWildFort(d) ? FIELDS_PER_FORT : (d - 1) % FORT_EVERY;
export const locationName = (realm, d) => isWildFort(d) ? REALMS[realm].fortName : FIELD_NAMES[realm][fieldVariant(d)];
export const wildReqLevel = (realm, d) => Math.max(1, wildLevel(realm, d) - 2);
export const moodOf = (realm, depth) => REALMS[realm].moods[Math.min(2, Math.floor((depth - 1) / 2))];
export const wildLevel = (realm, depth) => REALMS[realm].baseLevel + Math.floor((depth - 1) * 0.9 + Math.max(0, depth - 6) * 0.4);   // за первым фортом — круче

// Задания походов. Прогресс — счётчики P.wild.stat[realm] (реальные события). Награда забирается в окне портала.
const R = (slot, tier, rarity, names) => ({ slot, tier, rarity, names });
export const WILD_QUESTS = {
  temple: [
    { id: 'tm_kill', title: 'Säubert die Ruinen', text: 'Tötet 15 Kreaturen des Verfallenen Tempels.', stat: 'kills', n: 15, reward: { xp: 90, gold: 60, potions: 2 } },
    { id: 'tm_chest', title: 'Gaben der Alten', text: 'Öffnet 5 Truhen im Tempel.', stat: 'chests', n: 5, reward: { xp: 90, gold: 80, items: [R('head', 1, 1, { warrior: 'Templerhelm', archer: 'Pilgerkapuze', mage: 'Priesterreif' })] } },
    { id: 'tm_mini', title: 'Wächter der Heiligtümer', text: 'Besiegt 3 Minibosse in den Heiligtümern der Labyrinthe.', stat: 'minis', n: 3, reward: { xp: 200, gold: 120, skillPts: 1 } },
    { id: 'tm_deep', title: 'Zum Inneren Heiligtum', text: 'Erreiche Tiefe 3.', stat: 'depth', n: 3, reward: { xp: 180, gold: 100, potions: 3 } },
    { id: 'tm_fort', title: 'Der Schänder', text: 'Durchquert fünf Labyrinthe und besiegt den Tempelschänder.', stat: 'forts', n: 1, reward: { xp: 220, gold: 120, items: [R('weapon', 1, 2, { warrior: 'Templerschwert', archer: 'Pilgerbogen', mage: 'Priesterstab' })] } },
    { id: 'tm_boss', title: 'Der gefallene Gott', text: 'Besiegt den Gefallenen Gott des Tempels (Tiefe 12).', stat: 'bosses', n: 1, reward: { xp: 520, gold: 350, items: [{ slot: 'weapon', epic: true }] } },
  ],
  bones: [
    { id: 'bn_kill', title: 'Blut im Sand', text: 'Töte 15 Kreaturen in der Knochenöde.', stat: 'kills', n: 15, reward: { xp: 140, gold: 80, potions: 2 } },
    { id: 'bn_chest', title: 'Reißzahn-Beute', text: 'Öffne 5 Truhen in der Knochenöde.', stat: 'chests', n: 5, reward: { xp: 130, gold: 110, items: [R('head', 1, 1, { warrior: 'Hauerhelm', archer: 'Fährtenleser-Stirnband', mage: 'Wirbelkrone' })] } },
    { id: 'bn_fort', title: 'Alte Ruinen', text: 'Schaff fünf Felder und besiege den Häuptling in den Ruinen.', stat: 'forts', n: 1, reward: { xp: 240, gold: 130, items: [R('weapon', 1, 2, { warrior: 'Blutzahns Hackmesser', archer: 'Rippenbogen', mage: 'Schamanenstab' })] } },
    { id: 'bn_scorpid', title: 'Panzer und Stachel', text: 'Töte 3 Panzerskorpione.', stat: 'k_b_scorpid', n: 3, reward: { xp: 280, gold: 160, skillPts: 1 } },
    { id: 'bn_deep', title: 'Zum Riesenfriedhof', text: 'Erreiche Tiefe 3.', stat: 'depth', n: 3, reward: { xp: 260, gold: 140, potions: 3 } },
    { id: 'bn_boss', title: 'Der Koloss schläft', text: 'Besiege den Erwachten Knochenkoloss (Ruinen-Boss, Tiefe 12).', stat: 'bosses', n: 1, reward: { xp: 560, gold: 370, items: [{ slot: 'weapon', epic: true }] } },
  ],
  fjord: [
    { id: 'fj_kill', title: 'Erstes Blut an der Küste', text: 'Töte 15 Kreaturen in den Fjorden.', stat: 'kills', n: 15, reward: { xp: 180, gold: 90, potions: 2 } },
    { id: 'fj_chest', title: 'Beute der Jarle', text: 'Öffne 5 Truhen in den Fjorden.', stat: 'chests', n: 5, reward: { xp: 150, gold: 120, items: [R('head', 2, 1, { warrior: 'Hermelinhelm', archer: 'Skiläuferkapuze', mage: 'Schneesturmkrone' })] } },
    { id: 'fj_fort', title: 'Reiß die Fahne vom Fort', text: 'Erobere das Fort zurück: Töte seinen Kommandanten.', stat: 'forts', n: 1, reward: { xp: 260, gold: 140, items: [R('weapon', 2, 2, { warrior: 'Küstenaxt', archer: 'Fjordbogen', mage: 'Raureifstab' })] } },
    { id: 'fj_jotun', title: 'Riesentöter', text: 'Töte 3 Jötunnriesen.', stat: 'k_f_jotun', n: 3, reward: { xp: 320, gold: 180, skillPts: 1 } },
    { id: 'fj_deep', title: 'Tiefer, zu den Gletschern', text: 'Erreiche Tiefe 3.', stat: 'depth', n: 3, reward: { xp: 300, gold: 150, potions: 3 } },
    { id: 'fj_boss', title: 'König der Fjorde', text: 'Besiege Jötunn Skjold (Fort-Boss, Tiefe 12).', stat: 'bosses', n: 1, reward: { xp: 600, gold: 400, items: [{ slot: 'weapon', epic: true }] } },
  ],
  forest: [
    { id: 'fr_kill', title: 'Jagd am Waldrand', text: 'Töte 15 Waldkreaturen.', stat: 'kills', n: 15, reward: { xp: 120, gold: 70, potions: 2 } },
    { id: 'fr_chest', title: 'Verstecke der Wilderer', text: 'Öffne 5 Truhen im Alten Wald.', stat: 'chests', n: 5, reward: { xp: 110, gold: 100, items: [R('head', 1, 1, { warrior: 'Lederhelm des Jägers', archer: 'Jägermütze', mage: 'Kräuterkranz' })] } },
    { id: 'fr_fort', title: 'Plündere die Palisade', text: 'Erobere die Räuberpalisade: Töte den Anführer.', stat: 'forts', n: 1, reward: { xp: 220, gold: 120, items: [R('weapon', 1, 2, { warrior: 'Hackmesser des Anführers', archer: 'Schlitzohrs Bogen', mage: 'Försterstab' })] } },
    { id: 'fr_leshy', title: 'Wenn man vom Teufel spricht', text: 'Töte 4 Waldschrate.', stat: 'k_w_leshy', n: 4, reward: { xp: 260, gold: 150, skillPts: 1 } },
    { id: 'fr_deep', title: 'Tief in die Wildnis', text: 'Erreiche Tiefe 3.', stat: 'depth', n: 3, reward: { xp: 250, gold: 130, potions: 3 } },
    { id: 'fr_boss', title: 'Herr des Dickichts', text: 'Besiege den Herrn des Dickichts (Fort-Boss, Tiefe 12).', stat: 'bosses', n: 1, reward: { xp: 520, gold: 350, items: [{ slot: 'weapon', epic: true }] } },
  ],
};
