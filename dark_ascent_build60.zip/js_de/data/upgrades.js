// Gold upgrades bought from NPCs (endless gold sink, «Разрыв»-style small visible steps).
// сборка 47: дороже (герой к 8-му уровню успевал взять +17 силы удара), Меткость (крит) — только за осколки Бездны ◆
export const UPGRADES = {
  dmg:  { name: 'Schlagkraft', icon: '⚔', step: 4, unit: '%', max: 40, base: 60, mul: 1.24, fmt: l => `+${l * 4} % Schaden (Waffen und Zauber)` },
  hp:   { name: 'Robustheit', icon: '♥', step: 12, unit: '', max: 40, base: 45, mul: 1.22, fmt: l => `+${l * 12} Leben` },
  crit: { name: 'Präzision', icon: '✷', step: 0.6, unit: '%', max: 25, shards: true, fmt: l => `+${(l * 0.6).toFixed(1)} % Krit-Chance` },
  mp:   { name: 'Manavorrat', icon: '✦', step: 10, unit: '', max: 30, base: 50, mul: 1.21, fmt: l => `+${l * 10} Mana und +${(l * 0.1).toFixed(1)} Mana/s` },   // П27: мана за золото, растёт по уровням
  aps:  { name: 'Gewandtheit', icon: '⚡', step: 2, unit: '%', max: 20, base: 150, mul: 1.26, fmt: l => `+${l * 2} % Angriffstempo` },
};
// цена уровня: золото, у Меткости — осколки Бездны (2, 3, 4… за уровень)
export const upgCost = (id, l) => UPGRADES[id].shards ? 2 + l : Math.round(UPGRADES[id].base * Math.pow(UPGRADES[id].mul, l));
export const upgHave = (P, id) => UPGRADES[id].shards ? (P.shards || 0) : P.gold;

// Citadel rooms: unlock with gold + Abyss shards (shards drop randomly from elites, bosses, chests).
export const ROOMS = {
  altar:    { name: 'Goldaltar', lvl: 3, gold: 300, shards: 0, desc: 'Sammelt Gold, während du weg bist (bis 8 Stunden). Je höher die Altarstufe, desto mehr.' },
  trial:    { name: 'Halle der Prüfungen', lvl: 5, gold: 800, shards: 5, desc: 'Kämpfe gegen Wächter, ohne ins Verlies zu steigen. Prüfungssiegel füllen sich von selbst.' },
  treasury: { name: 'Abgrundschatzkammer', lvl: 7, gold: 1500, shards: 10, desc: 'Truhen für Splitter: seltene und epische Items deiner Klasse.' },
  trophy:   { name: 'Trophäenhalle', lvl: 9, gold: 2500, shards: 20, desc: 'Trophäen geben einen dauerhaften Schadens- und Goldbonus.' },
};

// Citadel decor (Sims-lite): buy an item for a glowing socket; every piece gives a small permanent bonus.
export const DECOR = {
  rug:         { name: 'Ordensteppich', spr: 'rug', gold: 120, shards: 0, bonus: { hp: 10 }, txt: '+10 Leben' },
  banner:      { name: 'Ordensbanner', spr: 'banner', gold: 200, shards: 0, bonus: { dmg: 2 }, txt: '+2 % Schaden' },
  bookshelf:   { name: 'Bücherregal', spr: 'bookshelf', gold: 350, shards: 2, bonus: { xp: 4 }, txt: '+4 % EP' },
  weapon_rack: { name: 'Waffenständer', spr: 'weapon_rack', gold: 450, shards: 3, bonus: { critDmg: 6 }, txt: '+6 % Krit-Schaden' },
  crystals:    { name: 'Abgrundkristalle', spr: 'crystals', gold: 600, shards: 6, bonus: { regen: 1 }, txt: '+1 Mana/s' },
  statue:      { name: 'Heldenstatue', spr: 'statue', gold: 900, shards: 5, bonus: { hp: 40 }, txt: '+40 Leben' },
  throne:      { name: 'Thron des Herrschers', spr: 'throne', gold: 1600, shards: 10, bonus: { gold: 6 }, txt: '+6 % Gold' },
};
export const SOCKETS = [
  { id: 'h1', room: 'hall', x: 13.2, y: 22.5 }, { id: 'h2', room: 'hall', x: 20.8, y: 22.5 }, { id: 'h3', room: 'hall', x: 13.2, y: 24.8 }, { id: 'h4', room: 'hall', x: 20.8, y: 24.8 },
  { id: 'a1', room: 'altar', x: 3.2, y: 19.4 }, { id: 'a2', room: 'altar', x: 8.4, y: 25.6 },
  { id: 't1', room: 'trial', x: 30.5, y: 15.8 }, { id: 't2', room: 'trial', x: 30.5, y: 28.2 },
  { id: 'r1', room: 'treasury', x: 4.2, y: 8.8 }, { id: 'r2', room: 'treasury', x: 11.8, y: 8.8 },
  { id: 'p1', room: 'trophy', x: 22.2, y: 8.8 }, { id: 'p2', room: 'trophy', x: 29.8, y: 8.8 },
];
