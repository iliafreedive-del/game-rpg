// Модификаторы этажа Глубин (сборка 49): игрок сам поднимает сложность ради награды (риск окупается: награда растёт вместе с угрозой).
// Применяются в game.js (loadZone 'depths'), множители награды — через season.js rm().
export const FLOOR_MODS = {
  swift:  { name: 'Flinke Schatten', glyph: '»', txt: 'Feinde 25 % schneller', spd: 1.25, gold: 1.3, xp: 1.2 },
  brutes: { name: 'Dickhäuter', glyph: '⛨', txt: 'Feinde zäher ×1,5', hp: 1.5, gold: 1.4, xp: 1.3 },
  fury:   { name: 'Abgrundzorn', glyph: '⚔', txt: 'Feinde schlagen härter ×1,35', dmg: 1.35, gold: 1.4, xp: 1.25 },
  champs: { name: 'Champions', glyph: '♛', txt: 'Jeder vierte Feind ist ein Champion', champ: 0.25, items: 1.6, gold: 1.25, xp: 1.25 },
  dry:    { name: 'Trockene Kehle', glyph: '⚗', txt: 'Tränke wirken nicht', nopot: true, gold: 1.5, xp: 1.4, items: 1.3 },
};
export const FLOOR_MOD_IDS = Object.keys(FLOOR_MODS);
const n = v => String(v).replace('.', ',');
export const modReward = m => `Gold ×${n(m.gold || 1)}${m.xp ? `, EP ×${n(m.xp)}` : ''}${m.items ? `, Items ×${n(m.items)}` : ''}`;
