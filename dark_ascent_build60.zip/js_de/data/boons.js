// «Дары Бездны» — run-only boons chosen during a Depths floor (1 of 3 cards). They reset when the floor ends.
export const BOONS = {
  giant:   { name: 'Titanenkraft', glyph: '⚔', color: '#ff9a5a', desc: '+15 % auf jeden Schaden.' },
  frenzy:  { name: 'Raserei', glyph: '⚡', color: '#ffd24a', desc: '+12 % Angriffstempo.' },
  eagle:   { name: 'Adlerauge', glyph: '◎', color: '#9bd06c', desc: '+5 % Krit-Chance, +20 % Krit-Schaden.' },
  vitality:{ name: 'Drachenblut', glyph: '♥', color: '#ff6b6b', desc: '+15 % Leben, 2 % Heilung pro Kill.' },
  haste:   { name: 'Schattenschwingen', glyph: '»', color: '#b9a4ff', desc: '+12 % Laufgeschw., Ausweichen lädt schneller.' },
  burn:    { name: 'Flammenhand', glyph: '♨', color: '#ff8a3c', desc: 'Jeder Treffer setzt den Feind mit 35 % Chance in Brand.' },
  frost:   { name: 'Frostklinge', glyph: '❄', color: '#8fdcff', desc: 'Treffer verlangsamen und stapeln Kälte – die dritte Ladung friert ein.' },
  storm:   { name: 'Sturmherz', glyph: 'ϟ', color: '#c8b4ff', desc: 'Krits entfesseln Kettenblitze auf 3 Feinde.' },
  boom:    { name: 'Asche zu Asche', glyph: '✹', color: '#ffb06a', desc: 'Getötete Feinde explodieren und verletzen Umstehende.' },
  nova:    { name: 'Abgrundring', glyph: '◌', color: '#c07bff', desc: 'Alle 4 s lodert ein Ring violetten Feuers um den Helden.' },
  blades:  { name: 'Tanzende Klingen', glyph: '✦', color: '#e8e2d4', desc: 'Zwei Geisterklingen kreisen um den Helden und schneiden Feinde.' },
  split:   { name: 'Spaltung', glyph: '⋔', color: '#6ea8ff', desc: 'Schüsse und Geschosse teilen sich in drei; Nahkampftreffer treffen alle nahen Feinde.' },
  greed:   { name: 'Drachengier', glyph: '⛁', color: '#f2cf4a', desc: '+25 % Gold bis zum Ende der Ebene.' },
  // проклятые дары (принцип «сила с ценой»): большой плюс и заметный минус — дилемма, а не бесплатная прибавка
  glass:   { name: 'Glaskanone', glyph: '✧', color: '#ff7ad9', desc: '+40 % auf jeden Schaden.', minus: 'Leben −30 %.' },
  bloodpact:{ name: 'Blutpakt', glyph: '✠', color: '#d0304a', desc: '+25 % Angriffstempo, jeder Kill heilt 4 %.', minus: 'Leben regeneriert nicht, Tränke heilen nur halb so viel.' },
};
export const BOON_IDS = Object.keys(BOONS);
