// Сюжет «Последний страж печати» (сборка 45): осколки памяти и сцены между главами.
// Герой просыпается в склепе без памяти; на шее — пустая оправа амулета на четыре камня.
// Бездну держат четыре печати, у каждой свой страж (боссы, которые уже есть в игре).
// Каждый побеждённый страж возвращает герою кусочек памяти; в конце выясняется, кто его усыпил и зачем.
// Показывает окно W.memory (js/ui/windows.js), флаги — в profile.story.mem.

export const SEALS = [
  { id: 'catacombs', name: 'Das erste Siegel', where: 'Ordenskatakomben', boss: 'Abgrundhenker' },
  { id: 'forest', name: 'Das zweite Siegel', where: 'Alter Wald', boss: 'Herr des Dickichts' },
  { id: 'fjord', name: 'Das dritte Siegel', where: 'Skjolds Fjorde', boss: 'Jötunn Skjold' },
  { id: 'bones', name: 'Das vierte Siegel', where: 'Knochenöde', boss: 'Erwachter Knochenkoloss' },
];

// Осколки памяти: id → сцена. kind: 'mem' — воспоминание, 'turn' — поворот сюжета.
export const MEMORIES = {
  wake: { kind: 'mem', title: 'Erinnerungssplitter', sub: 'Gruft des Erwachens', lines: [
    'Dunkelheit. Kalter Stein im Rücken. Eine Stimme, fern und müde:',
    '„Erwache, Wächter. Das Siegel hat einen Riss. Wir können nicht länger warten.“',
    'Du erinnerst dich nicht an deinen Namen. Um deinen Hals hängt eine Amulettfassung mit vier leeren Mulden.'] },
  seal1: { kind: 'mem', title: 'Erinnerungssplitter: Der erste Stein', sub: 'Der Abgrundhenker fällt', lines: [
    'Der Henker sinkt auf die Knie und sieht dich fast menschlich an:',
    '„Du? … Der Großmeister sagte, du wärst tot.“',
    'Und du erinnerst dich: dieselbe Halle, vor hundert Jahren. Du trägst die Rüstung des Ordens, deine Hände versiegeln den Riss.',
    'Der erste Stein fügt sich ins Amulett.'] },
  seal2: { kind: 'mem', title: 'Erinnerungssplitter: Der zweite Stein', sub: 'Der Herr des Dickichts fällt', lines: [
    'Der Wald verstummt, und ein Gesicht taucht auf: ein älterer Mann mit grauem Bart und sehr ruhigen Augen.',
    '„Großmeister Morven“, sagt jemand neben dir voller Ehrfurcht.',
    'Der zweite Stein fügt sich ins Amulett.'] },
  seal3: { kind: 'mem', title: 'Erinnerungssplitter: Der dritte Stein', sub: 'Jötunn Skjold fällt', lines: [
    'Das Eis unter dir spiegelt nicht dich, sondern wer du warst: Du stehst vor Morven und lehnst ab.',
    '„Der Abgrund schenkt so viele Jahre, wie du willst“, sagt er. „Der Preis ist nur ein Dorf.“',
    '„Nein“, antwortest du. Und du verschließt das erste Siegel selbst, gegen seinen Willen.',
    'Der sterbende Jötunn röchelt: „Das letzte Siegel liegt in der Öde. Er ist schon dort.“'] },
  seal4: { kind: 'turn', title: 'Die Wahrheit', sub: 'Das vierte Siegel', lines: [
    'Der vierte Stein fügt sich ins Amulett, und deine Erinnerung kehrt ganz zurück.',
    'Morven verfluchte dich – nicht mit dem Tod, sondern mit Schlaf: „Du schläfst, bis ich fertig bin.“',
    'Und der dich in der Gruft unter dem Dorf versteckte, war dein Freund und Schüler.',
    'Mentor Elvin. Er ließ dich schlafen, damit Morven dich nicht findet, und wartete hundert Jahre, bis das Siegel riss.'] },
  elvin: { kind: 'turn', title: 'Elvin gesteht', sub: 'Platz von Stillfurt', lines: [
    '„Ja, ich war es.“ Elvin weicht deinem Blick nicht aus. „Du hättest gekämpft und wärst gestorben. Ich wählte den Schlaf.“',
    '„Morven hat die Ordenszitadelle geöffnet. Er erwartet dich dort – und er weiß, dass du dich erinnerst.“',
    '„Geh. Ich habe dich alles gelehrt, was ich wusste. Jetzt wird es dir dienen.“'] },
  final: { kind: 'turn', title: 'Der Abgrund ist versiegelt', sub: 'Ordenszitadelle', lines: [
    'Morven fällt, und das Amulett an deinem Hals erlischt: vier Steine, vier heile Siegel.',
    'Stillfurt schläft ruhig – zum ersten Mal seit hundert Jahren.',
    'Doch aus der Tiefe, wohin kein Licht mehr dringt, ruft dich noch immer etwas beim Namen.',
    'Abgrundkreise freigeschaltet: Je tiefer der Kreis, desto wilder die Feinde und reicher die Beute.'] },
};

// Страницы летописи Ордена: открываются в «Летописи битв» каждые 10 этапов (ui/herospath.js)
export const CODEX = [
  { at: 10, title: 'Ordenschronik, Blatt I', text: 'Der Orden wurde gegründet, um die vier Siegel zu halten. Pro Jahrhundert wurde ein Wächter erwählt.' },
  { at: 20, title: 'Ordenschronik, Blatt II', text: 'Großmeister Morven suchte im Abgrund nicht Macht, sondern Zeit. Er sagte: „Der Tod ist nur eine schlechte Angewohnheit.“' },
  { at: 30, title: 'Ordenschronik, Blatt III', text: 'Der letzte Wächter trug deinen Namen. In der Chronik ist er durchgestrichen und überschrieben: „Verräter“.' },
  { at: 40, title: 'Ordenschronik, Blatt IV', text: 'Morven strich den Namen selbst. Eine andere Hand berichtigte ihn, viel später, und unterschrieb: „Er hatte recht“.' },
];
