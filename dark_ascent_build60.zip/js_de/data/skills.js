// Skills of 5 elements (branches give set bonuses); each class learns them along its own tree below. Node kinds: passive | active.
// Every value here is read by the combat code (see game/combat.js, game/stats.js).
export const BRANCHES = [
  { id: 'sword', name: 'Schwert', color: '#d9b77a', icon: 'sword' },
  { id: 'bow', name: 'Bogen', color: '#9bd06c', icon: 'bow' },
  { id: 'fire', name: 'Feuer', color: '#ff8a3c', icon: 'fire' },
  { id: 'ice', name: 'Eis', color: '#7cd3ff', icon: 'ice' },
  { id: 'light', name: 'Blitz', color: '#b9a4ff', icon: 'light' },
];

// сборка 47: бонусы пассивных навыков −80% (просьба игрока) — все числа пассивок умножаются на PASSIVE_K
export const PASSIVE_K = 0.2;
const k = v => String(+(v * PASSIVE_K).toFixed(2)).replace('.', ',');
export const SKILLS = {
  // ---- Меч
  blade_mastery: { b: 'sword', name: 'Klingenmeisterschaft', max: 5, kind: 'passive',
    desc: r => `+${k(r * 8)} % Nahkampfschaden, +${k(r * 3)} % Nahkampf-Angriffstempo.` },
  whirlwind: { b: 'sword', name: 'Wirbelwind', max: 5, kind: 'active', mana: 12, cd: 4, weapon: 'melee',
    desc: r => `Rundumschlag: ${140 + r * 20} % Waffenschaden an allen Feinden im Umkreis von 2,2 m, plus Rückstoß. Mana 12, Abklingzeit 4 s.` },
  cleave: { b: 'sword', name: 'Spalthieb', max: 3, kind: 'passive',
    desc: r => `Normale Angriffe treffen nahe Feinde im Bogen mit ${k(30 + r * 20)} % Schaden.` },
  bloodletting: { b: 'sword', name: 'Aderlass', max: 3, kind: 'passive',
    desc: r => `Nahkampf-Krits verursachen Blutung: ${k(r * 30)} % des Trefferschadens über 3 s.` },
  crush: { b: 'sword', name: 'Zermalmen', max: 1, kind: 'passive',
    desc: () => `Jeder 4. Nahkampftreffer zermalmt: ${100 + 150 * PASSIVE_K} % Schaden, 2-m-Schockwelle und ${k(1)} s Betäubung.` },
  leap: { b: 'sword', name: 'Zermalmender Sprung', max: 5, kind: 'active', mana: 14, cd: 7, weapon: 'melee',
    desc: r => `Spring zum Feind und schlag auf den Boden: ${180 + r * 30} % Waffenschaden im Umkreis von 2,6 m, 1 s Betäubung. Mana 14, Abklingzeit 7 s.` },
  warcry: { b: 'sword', name: 'Schlachtruf', max: 5, kind: 'active', mana: 10, cd: 14, weapon: 'any',
    desc: r => `+${25 + r * 5} % auf jeden Schaden für 8 s, nahe Feinde verlangsamt. Mana 10, Abklingzeit 14 s.` },
  // ---- Лук
  marksman: { b: 'bow', name: 'Präzision', max: 5, kind: 'passive',
    desc: r => `+${k(r * 8)} % Bogenschaden, +${k(r * 2)} % Bogen-Krit-Chance.` },
  volley: { b: 'bow', name: 'Salve', max: 5, kind: 'active', mana: 10, cd: 3, weapon: 'bow',
    desc: r => `Ein Fächer aus ${5 + (r >> 1)} Pfeilen, je ${60 + r * 10} % Schaden. Mana 10, Abklingzeit 3 s. Bogen nötig.` },
  pierce: { b: 'bow', name: 'Durchbohrende Pfeile', max: 3, kind: 'passive',
    desc: r => `${k(100)} % Chance, dass ein Pfeil ${r} ${r === 1 ? 'Feind' : 'Feinde'} durchbohrt und weiterfliegt.` },
  quickstring: { b: 'bow', name: 'Schnellziehen', max: 3, kind: 'passive',
    desc: r => `+${k(r * 10)} % Bogen-Angriffstempo.` },
  explosive: { b: 'bow', name: 'Explosivpfeil', max: 1, kind: 'passive',
    desc: () => `${k(25)} % Chance, dass ein Pfeil explodiert: 70 % Schaden an allen im Umkreis von 1,8 m.` },
  pierce_shot: { b: 'bow', name: 'Durchschuss', max: 5, kind: 'active', mana: 10, cd: 3, weapon: 'bow',
    desc: r => `Ein strahlender Pfeil durchbohrt alle Feinde in einer Linie: ${220 + r * 30} % Schaden. Mana 10, Abklingzeit 3 s.` },
  arrow_rain: { b: 'bow', name: 'Pfeilregen', max: 5, kind: 'active', mana: 18, cd: 6, weapon: 'bow',
    desc: r => `Pfeile regnen 1,5 s auf 3 m Fläche: 10 Salven zu je ${40 + r * 8} % Schaden. Mana 18, Abklingzeit 6 s.` },
  // ---- Огонь
  heat: { b: 'fire', name: 'Hitze', max: 5, kind: 'passive',
    desc: r => `+${k(r * 10)} % Feuerschaden.` },
  fireball: { b: 'fire', name: 'Feuerball', max: 5, kind: 'active', mana: 12, cd: 1.4, weapon: 'any', elem: 'fire',
    desc: r => `Feuerkugel: ${7 + r * 4} Schaden (× Zauberkraft) und 1,4-m-Explosion. Setzt in Brand: 40 % Zusatzschaden über 3 s. Mana 12, Abklingzeit 1,4 s.` },
  ignite_plus: { b: 'fire', name: 'Sengender Brand', max: 3, kind: 'passive',
    desc: r => `Brandschaden +${k(r * 50)} %, Dauer +${k(r)} s.` },
  fire_spread: { b: 'fire', name: 'Flammenausbreitung', max: 3, kind: 'passive',
    desc: r => `Brennende Feinde entzünden pro Sekunde mit ${k(r * 25)} % Chance andere im Umkreis von 2 m.` },
  burn_explode: { b: 'fire', name: 'Verbrennung', max: 1, kind: 'passive',
    desc: () => `Brennende Feinde explodieren beim Tod: ${k(80)} % Feuerballschaden im Umkreis von 2 m und Brand.` },
  meteor: { b: 'fire', name: 'Meteor', max: 5, kind: 'active', mana: 22, cd: 5, weapon: 'any', elem: 'fire',
    desc: r => `Ein Meteor stürzt vom Himmel: ${22 + r * 10} Schaden im Umkreis von 2,3 m und brennender Boden für 3 s. Mana 22, Abklingzeit 5 s.` },
  // ---- Лёд
  cold: { b: 'ice', name: 'Kälte', max: 5, kind: 'passive',
    desc: r => `+${k(r * 10)} % Eisschaden.` },
  ice_shard: { b: 'ice', name: 'Eisgeschoss', max: 5, kind: 'active', mana: 9, cd: 1.0, weapon: 'any', elem: 'cold',
    desc: r => `Eissplitter: ${6 + r * 3} Schaden, 30 % Verlangsamung und 1 Kälteladung. 3 Ladungen frieren 1,5 s ein. Mana 9, Abklingzeit 1 s.` },
  deep_cold: { b: 'ice', name: 'Tiefkühlung', max: 3, kind: 'passive',
    desc: r => `Verlangsamung +${k(r * 10)} %, Kälteladungen halten ${k(r)} s länger, Einfrieren +${k(r * 0.3)} s.` },
  ice_armor: { b: 'ice', name: 'Eisrüstung', max: 3, kind: 'passive',
    desc: r => `+${k(r * 12)} Abwehr. Feinde, die dich im Nahkampf treffen, erhalten mit ${k(100)} % Chance eine Kälteladung.` },
  shatter: { b: 'ice', name: 'Zersplittern', max: 1, kind: 'passive',
    desc: () => `Gefrorene Feinde erleiden +${k(50)} % Schaden; getötet zerbersten sie in 4 Splitter (${k(100)} % Kraft).` },
  frost_nova: { b: 'ice', name: 'Frostnova', max: 5, kind: 'active', mana: 16, cd: 6, weapon: 'any', elem: 'cold',
    desc: r => `Kälteexplosion um dich: ${8 + r * 4} Schaden im Umkreis von 3,6 m und 2 Kälteladungen (fast Einfrieren). Mana 16, Abklingzeit 6 s.` },
  // ---- Молния
  static: { b: 'light', name: 'Statik', max: 5, kind: 'passive',
    desc: r => `+${k(r * 10)} % Blitzschaden.` },
  chain: { b: 'light', name: 'Kettenblitz', max: 5, kind: 'active', mana: 16, cd: 2.5, weapon: 'any', elem: 'light',
    desc: r => `Blitz: ${8 + r * 4} Schaden, springt auf ${2 + (r >> 1)} nächste Feinde über (−25 % pro Sprung). Mana 16, Abklingzeit 2,5 s.` },
  conduct: { b: 'light', name: 'Leitfähigkeit', max: 3, kind: 'passive',
    desc: r => `Blitze hinterlassen „Schock“: Der Feind erleidet 3 s lang +${k(r * 8)} % Schaden aus allen Quellen.` },
  overload: { b: 'light', name: 'Überladung', max: 3, kind: 'passive',
    desc: r => `${k(r * 10)} % Chance, bei jedem Treffer einen Funken auf den nächsten Feind zu schießen (50 % Blitzschaden).` },
  thunder: { b: 'light', name: 'Donnerschlag', max: 1, kind: 'active', mana: 25, cd: 8, weapon: 'any', elem: 'light',
    desc: () => `Nach 0,4 s treffen Blitze alle Feinde im Umkreis von 5 m: 200 % Kettenblitzschaden. Mana 25, Abklingzeit 8 s.` },
};
// ---- Дерево навыков (сборка 36): у каждого класса одна ветка, как столбик талантов в WoW.
// Активное → два пассивных → активное → … → 4 активных под 4 кнопки боя и завершающий пассивный.
// Каждый узел открывается, когда изучен предыдущий (ранг 1) и герой дорос до уровня узла;
// каждый следующий ранг требует на 1 уровень больше. Навыки вне ветки класса недоступны.
const CLASS_TREE = {
  warrior: [['whirlwind', 1], ['blade_mastery', 2], ['cleave', 3], ['leap', 5], ['bloodletting', 6], ['crush', 8], ['warcry', 10], ['heat', 12], ['ignite_plus', 14], ['meteor', 16], ['burn_explode', 20]],
  archer: [['volley', 1], ['marksman', 2], ['quickstring', 3], ['pierce_shot', 5], ['pierce', 6], ['explosive', 8], ['arrow_rain', 10], ['cold', 12], ['deep_cold', 14], ['frost_nova', 16], ['shatter', 20]],
  mage: [['fireball', 1], ['heat', 2], ['ignite_plus', 3], ['ice_shard', 5], ['cold', 6], ['deep_cold', 8], ['chain', 10], ['static', 12], ['conduct', 14], ['meteor', 16], ['fire_spread', 20]],
};
export const classTree = cls => CLASS_TREE[cls] || CLASS_TREE.warrior;
export const classSkillOrder = cls => classTree(cls).map(([k]) => k);
export const inClassTree = (cls, id) => classTree(cls).some(([k]) => k === id);
export const unlockLevel = (cls, id) => { const e = classTree(cls).find(([k]) => k === id); return e ? e[1] : 99; };
export const prevNode = (cls, id) => { const t = classTree(cls), i = t.findIndex(([k]) => k === id); return i > 0 ? t[i - 1][0] : null; };
// hero level needed for the next rank (rank — current rank, 0 = not learned)
export const rankLevel = (cls, id, rank) => unlockLevel(cls, id) + rank;
export const SKILL_IDS = Object.keys(SKILLS);
export const ACTIVE_IDS = SKILL_IDS.filter(k => SKILLS[k].kind === 'active');
export const branchOf = id => SKILLS[id].b;
