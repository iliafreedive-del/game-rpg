// Item definitions: base types, affix pool, rarities, unique (epic) effects.
// Browser-friendly gear: only 4 slots — weapon, helm, armour, amulet.
export const SLOTS = ['weapon', 'head', 'chest', 'amulet'];
// Hero classes: allowed weapons, skill branches, starting attributes.
export const CLASSES = {
  warrior: { name: 'Ordensritter', desc: 'Schwert und Schild. Robust, kämpft im Nahkampf, setzt Feinde in Brand.', weapons: ['sword'], main: 'sword', branches: ['sword', 'fire'], attrs: { str: 16, dex: 10, int: 7, vit: 14 }, block: 0.12, gift: 'whirlwind', icon: 'sword' },
  archer: { name: 'Rabenwächter', desc: 'Bogenschütze mit Rabenmaske. Trifft aus der Ferne, bremst mit Eis.', weapons: ['bow'], main: 'bow', branches: ['bow', 'ice'], attrs: { str: 9, dex: 17, int: 10, vit: 11 }, block: 0, gift: 'volley', icon: 'bow' },
  mage: { name: 'Sterndeuter', desc: 'Abgrundmagier mit Porzellanmaske: Feuer, Eis und Blitz.', weapons: ['staff'], main: 'staff', branches: ['fire', 'ice', 'light'], attrs: { str: 7, dex: 10, int: 18, vit: 11 }, block: 0, gift: null, icon: 'staff' },
};
// Рост характеристик за уровень (5 очков) — автоматический, по классу.
export const GROWTH = { warrior: { str: 2, vit: 2, dex: 1, int: 0 }, archer: { dex: 3, vit: 1, str: 1, int: 0 }, mage: { int: 3, vit: 1, dex: 1, str: 0 } };
export const SLOT_NAMES = { weapon: 'Waffe', head: 'Helm', chest: 'Rüstung', amulet: 'Amulett' };
export const RARITY = [
  { id: 'white', name: 'Gewöhnlich', color: '#b9b4a6', affixes: [0, 0] },
  { id: 'green', name: 'Ungewöhnlich', color: '#5fd16a', affixes: [1, 1] },
  { id: 'blue', name: 'Selten', color: '#6ea8ff', affixes: [2, 3] },
  { id: 'purple', name: 'Episch', color: '#f2cf4a', affixes: [4, 5] },
  { id: 'red', name: 'Mythisch', color: '#ff5a4a', affixes: [5, 5] },   // сборка 20: только слиянием трёх золотых
];
// Слияние у кузнеца (сборка 20): три вещи одного слота и одной редкости → одна следующей редкости.
// Редкость теперь прямо усиливает вещь: урон оружия и защита × RMUL (вместе с закалкой).
export const RMUL = [1, 1.1, 1.25, 1.45, 1.8];
export const RARITY_SHORT = ['grau', 'grün', 'blau', 'gold', 'mythisch'];
// «Свойство вида»: у каждого вида вещи своё, открывается на синем и растёт с редкостью (×1 синее, ×2 золотое, ×3 мифическое)
export const KIND_PERK = {
  // сборка 47: только усиления, как у наставника Элвина (сила удара, здоровье, проворство, защита, мана); крита, ловкости и прочего на вещах нет
  sword: { k: 'ias', v: 5, txt: 'Schwert: schnellere Hiebe' }, greatsword: { k: 'ias', v: 5, txt: 'Schnellere Hiebe' }, axe: { k: 'ias', v: 5, txt: 'Schnellere Hiebe' },
  bow: { k: 'ias', v: 5, txt: 'Bogen: schnellere Schüsse' }, staff: { k: 'mp', v: 15, txt: 'Stab: mehr Mana' },
  head: { k: 'hp', v: 20, txt: 'Helm: mehr Leben' }, chest: { k: 'armor', v: 8, txt: 'Rüstung: mehr Abwehr' }, amulet: { k: 'dmgPct', v: 4, txt: 'Amulett: stärkere Treffer' },
};

// Weapon profiles — differ in speed, range, animation and ability, not only damage.
export const WEAPONS = {
  sword: { name: 'Einhandschwert', icon: 'sword', dmg: [5, 10], aps: 1.5, range: 1.35, arc: 100, hands: 1, clips: ['slash1', 'slash2'], impact: 0.5, scale: 'str', note: 'Schnelle Hiebe, Kombo aus zwei Schwüngen; Schild möglich.' },
  greatsword: { name: 'Zweihandschwert', icon: 'greatsword', dmg: [13, 23], aps: 0.9, range: 1.75, arc: 150, hands: 2, clips: ['chop2', 'sweep2'], impact: 0.58, scale: 'str', cleave: 1, note: 'Langsam, trifft aber alle Feinde in weitem Bogen.' },
  axe: { name: 'Axt', icon: 'axe', dmg: [7, 13], aps: 1.2, range: 1.3, arc: 90, hands: 1, clips: ['slash1', 'slash2'], impact: 0.5, scale: 'str', pierce: 0.35, bleed: 0.25, note: 'Ignoriert 35 % Rüstung und verursacht Blutung.' },
  bow: { name: 'Bogen', icon: 'bow', dmg: [5, 11], aps: 1.1, range: 9, hands: 2, clips: ['bowdraw', 'bowrel'], impact: 0, scale: 'dex', projectile: 'arrow', note: 'Pfeile fliegen 9 m. Schaden steigt mit Geschick.' },
  staff: { name: 'Stab', icon: 'staff', dmg: [3, 7], aps: 1.0, range: 7, hands: 2, clips: ['cast'], impact: 0.5, scale: 'int', projectile: 'bolt', spell: 0.25, note: 'Magiegeschoss; +25 % Zauberschaden.' },
};

// Base items: [key, slot, weaponType|null, name, minLevel, armor/dmgMult, reqs]
export const BASES = [
  // weapons
  { k: 'short_sword', slot: 'weapon', wt: 'sword', name: 'Kurzschwert', lvl: 1, mult: 1.0 },
  { k: 'long_sword', slot: 'weapon', wt: 'sword', name: 'Langschwert', lvl: 3, mult: 1.3, req: { str: 14 } },
  { k: 'knight_sword', slot: 'weapon', wt: 'sword', name: 'Ritterklinge', lvl: 6, mult: 1.65, req: { str: 20 } },
  { k: 'claymore', slot: 'weapon', wt: 'greatsword', name: 'Claymore', lvl: 2, mult: 1.0, req: { str: 16 } },
  { k: 'zweihander', slot: 'weapon', wt: 'greatsword', name: 'Zweihänder', lvl: 5, mult: 1.35, req: { str: 22 } },
  { k: 'hand_axe', slot: 'weapon', wt: 'axe', name: 'Handaxt', lvl: 1, mult: 1.0 },
  { k: 'war_axe', slot: 'weapon', wt: 'axe', name: 'Streitaxt', lvl: 4, mult: 1.35, req: { str: 17 } },
  { k: 'short_bow', slot: 'weapon', wt: 'bow', name: 'Kurzbogen', lvl: 1, mult: 1.0 },
  { k: 'hunter_bow', slot: 'weapon', wt: 'bow', name: 'Jagdbogen', lvl: 3, mult: 1.3, req: { dex: 15 } },
  { k: 'long_bow', slot: 'weapon', wt: 'bow', name: 'Langbogen', lvl: 5, mult: 1.6, req: { dex: 21 } },
  { k: 'oak_staff', slot: 'weapon', wt: 'staff', name: 'Eichenstab', lvl: 1, mult: 1.0 },
  { k: 'rune_staff', slot: 'weapon', wt: 'staff', name: 'Runenstab', lvl: 4, mult: 1.4, req: { int: 17 } },
  // offhand
  { k: 'buckler', slot: 'offhand', name: 'Buckler', icon: 'shield', lvl: 1, armor: 6, block: 0.10 },
  { k: 'kite_shield', slot: 'offhand', name: 'Drachenschild', icon: 'shield', lvl: 4, armor: 12, block: 0.15, req: { str: 16 } },
  // armor
  { k: 'cap', slot: 'head', name: 'Lederhelm', icon: 'head', lvl: 1, armor: 3 },
  { k: 'helm', slot: 'head', name: 'Hörnerhelm', icon: 'head', lvl: 4, armor: 7, req: { str: 14 } },
  { k: 'pads', slot: 'shoulders', name: 'Schulterplatten', icon: 'shoulders', lvl: 1, armor: 2 },
  { k: 'pauldrons', slot: 'shoulders', name: 'Stahl-Schulterplatten', icon: 'shoulders', lvl: 4, armor: 6 },
  { k: 'jerkin', slot: 'chest', name: 'Gambeson', icon: 'chest', lvl: 1, armor: 5 },
  { k: 'mail', slot: 'chest', name: 'Kettenhemd', icon: 'chest', lvl: 3, armor: 10, req: { str: 13 } },
  { k: 'plate', slot: 'chest', name: 'Plattenrüstung', icon: 'chest', lvl: 6, armor: 17, req: { str: 20 } },
  { k: 'gloves', slot: 'hands', name: 'Handschuhe', icon: 'hands', lvl: 1, armor: 2 },
  { k: 'gauntlets', slot: 'hands', name: 'Plattenhandschuhe', icon: 'hands', lvl: 4, armor: 5 },
  { k: 'trousers', slot: 'legs', name: 'Hose', icon: 'legs', lvl: 1, armor: 3 },
  { k: 'greaves', slot: 'legs', name: 'Beinschienen', icon: 'legs', lvl: 4, armor: 7 },
  { k: 'boots', slot: 'feet', name: 'Stiefel', icon: 'feet', lvl: 1, armor: 2 },
  { k: 'sabatons', slot: 'feet', name: 'Eisenschuhe', icon: 'feet', lvl: 4, armor: 5 },
  // jewellery
  { k: 'amulet', slot: 'amulet', name: 'Amulett', icon: 'amulet', lvl: 1 },
  { k: 'ring', slot: 'ring', name: 'Ring', icon: 'ring', lvl: 1 },
];
export const BASE = Object.fromEntries(BASES.map(b => [b.k, b]));

// Affixes. v(ilvl) → rolled value range. kinds: allowed slot groups.
// groups: W weapon, A armor(any), O offhand, J jewellery
// сборка 47: на вещах только те же усиления, что продаёт наставник Элвин — сила удара, здоровье, проворство, защита, мана.
// Крит, ловкость, сила, стихии, вампиризм и т. п. с вещей убраны (крит качается только у Элвина за осколки Бездны).
export const AFFIXES = {
  dmgPct:   { name: v => `+${v} % Schlagkraft`, g: 'WJ', r: l => [3 + (l >> 1), 6 + l], w: 10 },
  hp:       { name: v => `+${v} Leben`, g: 'AOJ', r: l => [6 + l * 2, 12 + l * 4], w: 10 },
  ias:      { name: v => `+${v} % Angriffstempo`, g: 'WJ', r: l => [3, 5 + (l >> 2)], w: 7 },
  armor:    { name: v => `+${v} Abwehr`, g: 'AO', r: l => [2 + l, 5 + l * 2], w: 10 },
  mp:       { name: v => `+${v} Mana`, g: 'AJW', r: l => [5 + l * 2, 12 + l * 4], w: 6 },
  // С35 (правки 2): свойства «под билд» — для одной ветви навыков героя (b), только с синей редкости (minR). Ветвь выбирается из веток класса
  brDmg:    { name: (v, bn) => `+${v}% Schaden der «${bn}»-Fertigkeiten`, g: 'WJ', r: l => [6 + (l >> 1), 10 + l], w: 4, branch: true, minR: 2 },
  brCd:     { name: (v, bn) => `−${v}% Abklingzeit der «${bn}»-Fertigkeiten`, g: 'AJ', r: l => [6, 12 + (l >> 2)], w: 3, branch: true, minR: 2 },
  brMana:   { name: (v, bn) => `−${v}% Manakosten der «${bn}»-Fertigkeiten`, g: 'AOJ', r: l => [8, 15 + (l >> 2)], w: 3, branch: true, minR: 2 },
};
export const BR_CAP = { brDmg: 60, brCd: 40, brMana: 50 };   // предел суммы по ветви, %
// ключи старых свойств — вычищаются из сохранений (save.js, v6→v7) и не учитываются в характеристиках
export const OLD_AFFIXES = ['dmgFlat', 'crit', 'critDmg', 'armorPct', 'str', 'dex', 'int', 'vit', 'fire', 'cold', 'light', 'regen', 'leech', 'goldFind', 'skill'];
export const AFFIX_GROUP = slot => slot === 'weapon' ? 'W' : slot === 'offhand' ? 'O' : (slot === 'amulet' || slot === 'ring') ? 'J' : 'A';

// Epic (purple) items — boss only. Each has a unique mechanic that the combat code checks.
export const EPICS = [
  { id: 'e_bow', base: 'long_bow', name: 'Flüstern des Abgrunds', effect: 'splitArrow', desc: 'Jeder Pfeil spaltet sich im Flug in 3.', fixed: { dmgPct: 10, ias: 6 } },
  { id: 'e_sword', base: 'knight_sword', name: 'Eid des Henkers', effect: 'execute', desc: 'Treffer gegen Feinde unter 30 % Leben verursachen doppelten Schaden.', fixed: { dmgPct: 12, hp: 30 } },
  { id: 'e_staff', base: 'rune_staff', name: 'Stab des Erloschenen Sterns', effect: 'echo', desc: '25 % Chance, einen Zauber gratis zu wiederholen.', fixed: { dmgPct: 10, mp: 30 } },
  { id: 'e_axe', base: 'war_axe', name: 'Kettenspalter', effect: 'chainHit', desc: 'Treffer springen auf den nächsten Feind über (50 % Schaden).', fixed: { dmgPct: 10, ias: 6 } },
  { id: 'e_amulet', base: 'amulet', name: 'Herz des Henkers', effect: 'bloodShield', desc: 'Ein Kill gewährt einen Schild von 10 % max. Leben.', fixed: { hp: 40, mp: 20 } },
  { id: 'e_chest', base: 'plate', name: 'Abgrundrüstung', effect: 'thorns', desc: 'Nahkampfangreifer erleiden 30 % reflektierten Schaden.', fixed: { armor: 20, hp: 30 } },
];

export const CONSUMABLES = {
  potion_hp: { name: 'Heiltrank', icon: 'potion_hp', desc: 'Stellt in 1 Sek. 45 % Leben wieder her.' },
  potion_mp: { name: 'Manatrank', icon: 'potion_mp', desc: 'Stellt in 1 Sek. 50 % Mana wieder her.' },
  scroll: { name: 'Rückkehrrolle', icon: 'scroll', desc: 'Öffnet ein Portal aus dem Verlies ins Dorf.' },
};
