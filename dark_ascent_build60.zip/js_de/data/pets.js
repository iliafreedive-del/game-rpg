// Питомцы каравана (сборка 58): продаёт Караванщик Кофи за осколки Бездны ◆. С героем ходит один питомец.
// Бьют слабо (k — доля среднего удара героя), зато у каждого свой эффект (fx, см. js/game/pets.js).
// tier: 0 обычный / 1 редкий / 2 эпический — цена, уровень героя и цена улучшения. Уровень питомца 1..PET_MAX: +15% силы за уровень.
export const PET_MAX = 5;
export const TIERS = [
  { name: 'Gewöhnlich', price: 6, lvl: 1, up: 3, color: '#cfd6dc' },
  { name: 'Selten', price: 12, lvl: 5, up: 5, color: '#6ab4ff' },
  { name: 'Episch', price: 20, lvl: 9, up: 8, color: '#f0b030' },
];
export const PETS = {
  fennec:   { name: 'Feuerfennek', icon: '🦊', tier: 0, k: 0.12, cd: 1.2, reach: 0.9, fx: 'burn', desc: 'Setzt den Gegner in Brand: Der Schaden hält 3 Sekunden an.' },
  crow:     { name: 'Spähkrähe', icon: '🐦', tier: 0, k: 0.10, cd: 1.4, reach: 1.0, fx: 'loot', desc: 'Findet verstecktes Gold bei Gefallenen und bringt manchmal einen Abgrundsplitter.' },
  scorpid:  { name: 'Skorpidjunges', icon: '🦂', tier: 1, k: 0.10, cd: 1.2, reach: 0.9, fx: 'poison', desc: 'Vergiftet: Das Gift stapelt sich bis zu 5-mal.' },
  wisp:     { name: 'Irrlicht', icon: '✨', tier: 1, k: 0.08, cd: 1.5, reach: 5, ranged: true, fx: 'heal', desc: 'Heilt den Helden alle 5 Sekunden und schießt Funken.' },
  skull:    { name: 'Knochenschädel', icon: '💀', tier: 2, k: 0.15, cd: 1.4, reach: 7, ranged: true, fx: 'needle', desc: 'Schwebt in der Nähe und schießt Nadeln auf ferne Ziele.' },
  basilisk: { name: 'Basilisk', icon: '🦎', tier: 2, k: 0.12, cd: 1.3, reach: 1.0, fx: 'stun', desc: 'Sein Blick betäubt den Gegner eine halbe Sekunde lang.' },
  bat:      { name: 'Abgrundfledermaus', icon: '🦇', tier: 2, k: 0.12, cd: 1.1, reach: 1.0, fx: 'leech', desc: 'Beißt, und ein Teil des Schadens heilt den Helden.' },
  golem:    { name: 'Sandsteingolem', icon: '🗿', tier: 2, k: 0.07, cd: 1.8, reach: 1.1, fx: 'shield', speed: 0.85, desc: 'Schlägt schwach zu, schützt den Helden aber alle 8 Sekunden mit einem Steinschild.' },
};
export const petPrice = id => TIERS[PETS[id].tier].price;
export const petUpCost = (id, lvl) => TIERS[PETS[id].tier].up * lvl;
export const petReqLevel = id => TIERS[PETS[id].tier].lvl;
export const GIFT_PET = 'fennec';
// П29 (правки 2): дрессировка у Кофи за золото — общая для всех питомцев (сменили зверька — выучка остаётся).
// Физический урон: удар и иглы (+10% за уровень). Магический: огонь, яд, искры, лечение, щит и вампиризм (+10% за уровень).
export const TRAIN_MAX = 20;
export const TRAIN = {
  phys: { name: 'Physischer Schaden', icon: '🗡', txt: 'Biss und Krallen, Schädelnadeln' },
  mag: { name: 'Magischer Schaden', icon: '✦', txt: 'Feuer, Gift, Funken, Heilung, Schild, Lebensraub' },
};
export const TRAIN_STEP = 0.1;
export const trainCost = l => Math.round(120 * Math.pow(1.22, l));   // первого зверька Кофи дарит
